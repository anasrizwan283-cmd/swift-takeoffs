document.addEventListener('DOMContentLoaded', function() {

    /* ─────────────────────────────────────────
       STICKY HEADER (High-Performance Scroll)
    ───────────────────────────────────────── */
    const header = document.querySelector('header');
    if (header) {
        let scrollTick = false;
        window.addEventListener('scroll', () => {
            if (!scrollTick) {
                window.requestAnimationFrame(() => {
                    header.classList.toggle(
                        'scrolled',
                        !header.classList.contains('st-landing-header') && window.scrollY > 40
                    );
                    scrollTick = false;
                });
                scrollTick = true;
            }
        }, { passive: true });
    }

    /* ─────────────────────────────────────────
       MOBILE MENU TOGGLE
    ───────────────────────────────────────── */
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (mobileMenuToggle && navMenu) {
        const icon = mobileMenuToggle.querySelector('i');
        mobileMenuToggle.addEventListener('click', () => {
            const isActive = navMenu.classList.toggle('active');
            mobileMenuToggle.setAttribute('aria-expanded', isActive);
            if (icon) {
                if (isActive) {
                    icon.classList.remove('fa-bars');
                    icon.classList.add('fa-xmark');
                } else {
                    icon.classList.remove('fa-xmark');
                    icon.classList.add('fa-bars');
                }
            }
        });
    }

    /* ─────────────────────────────────────────
       MEGA DROPDOWNS (Services + Trades)
       Desktop : CSS hover handles show/hide
       Mobile  : click trigger toggles accordion
                 — does NOT redirect on first tap
    ───────────────────────────────────────── */
    const megaTriggers = document.querySelectorAll('.nav-dropdown-trigger');

    megaTriggers.forEach(trigger => {
        trigger.addEventListener('click', function(e) {
            if (window.innerWidth <= 992) {
                // On mobile — toggle accordion, prevent navigation
                e.preventDefault();
                const parentLi = this.closest('.nav-has-dropdown');
                if (!parentLi) return;

                const isOpen = parentLi.classList.contains('mobile-open');

                // Close all other open dropdowns
                document.querySelectorAll('.nav-has-dropdown.mobile-open').forEach(el => {
                    if (el !== parentLi) el.classList.remove('mobile-open');
                });

                // Toggle this one
                parentLi.classList.toggle('mobile-open', !isOpen);
            }
            // Desktop: allow normal link navigation (CSS hover handles panel)
        });
    });

    /* ─────────────────────────────────────────
       DESKTOP HOVER — trigger only on parent <a>
       Panel uses position:fixed aligned to 1440px
       container width. Top set dynamically.
    ───────────────────────────────────────── */
    function setPanelTop(panel) {
        const navbar = document.querySelector('.main-navbar');
        if (!navbar || !panel) return;
        const rect = navbar.getBoundingClientRect();
        panel.style.top = (rect.bottom) + 'px';
    }

    if (window.innerWidth > 992) {
        document.querySelectorAll('.nav-has-dropdown').forEach(li => {
            const trigger = li.querySelector('.nav-dropdown-trigger');
            const panel   = li.querySelector('.nav-dropdown-panel');
            if (!trigger || !panel) return;

            let leaveTimer;

            trigger.addEventListener('mouseenter', () => {
                clearTimeout(leaveTimer);
                setPanelTop(panel);
                li.classList.add('is-open');
            });

            panel.addEventListener('mouseenter', () => {
                clearTimeout(leaveTimer);
            });

            trigger.addEventListener('mouseleave', () => {
                leaveTimer = setTimeout(() => {
                    if (!panel.matches(':hover')) li.classList.remove('is-open');
                }, 100);
            });

            panel.addEventListener('mouseleave', () => {
                leaveTimer = setTimeout(() => {
                    li.classList.remove('is-open');
                }, 100);
            });
        });

        // Update panel top on scroll with requestAnimationFrame to prevent layout thrashing
        let megaScrollTick = false;
        window.addEventListener('scroll', () => {
            if (!megaScrollTick) {
                window.requestAnimationFrame(() => {
                    document.querySelectorAll('.nav-has-dropdown.is-open').forEach(li => {
                        const panel = li.querySelector('.nav-dropdown-panel');
                        setPanelTop(panel);
                    });
                    megaScrollTick = false;
                });
                megaScrollTick = true;
            }
        }, { passive: true });
    }

    /* ─────────────────────────────────────────
       CLOSE ALL MENUS ON OUTSIDE CLICK (Optimized)
    ───────────────────────────────────────── */
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.main-navbar')) {
            if (navMenu && navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
                if (mobileMenuToggle) {
                    mobileMenuToggle.setAttribute('aria-expanded', 'false');
                    const icon = mobileMenuToggle.querySelector('i');
                    if (icon) {
                        icon.classList.remove('fa-xmark');
                        icon.classList.add('fa-bars');
                    }
                }
            }
            
            // Only search and modify DOM if open menus/dropdowns actually exist
            const openMobile = document.querySelectorAll('.nav-has-dropdown.mobile-open');
            if (openMobile.length > 0) {
                openMobile.forEach(el => el.classList.remove('mobile-open'));
            }
            
            const openDesktop = document.querySelectorAll('.nav-has-dropdown.is-open');
            if (openDesktop.length > 0) {
                openDesktop.forEach(el => el.classList.remove('is-open'));
            }
        }
    });

    /* ─────────────────────────────────────────
       BACK TO TOP (High-Performance Scroll)
    ───────────────────────────────────────── */
    const backToTopBtn = document.getElementById('backToTopBtn');
    if (backToTopBtn) {
        let backToTopTick = false;
        window.addEventListener('scroll', () => {
            if (!backToTopTick) {
                window.requestAnimationFrame(() => {
                    backToTopBtn.classList.toggle('show', window.scrollY > 300);
                    backToTopTick = false;
                });
                backToTopTick = true;
            }
        }, { passive: true });

        backToTopBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ─────────────────────────────────────────
       HOMEPAGE TRADES TAB SWITCHER (rAF Optimized)
    ───────────────────────────────────────── */
    const tradeSidebar    = document.getElementById('tradeSidebar');
    const tradeContentBox = document.getElementById('tradeContentBox');
    const tradesData      = (typeof swiftTradesData  !== 'undefined') ? swiftTradesData  : {};
    const servicesUrl     = (typeof swiftThemeData   !== 'undefined') ? swiftThemeData.siteUrl + '/services/' : '#';

    if (tradeSidebar && tradeContentBox) {
        const tradeItems  = tradeSidebar.querySelectorAll('.trade-item');
        const contentTitle = tradeContentBox.querySelector('h3');
        const contentDesc  = tradeContentBox.querySelectorAll('p')[0];
        const contentExtra = tradeContentBox.querySelectorAll('p')[1];
        const contentImg   = tradeContentBox.querySelector('.trade-image img');

        tradeItems.forEach(item => {
            item.addEventListener('click', function() {
                const data = tradesData[this.getAttribute('data-trade')];
                if (!data) return;

                window.requestAnimationFrame(() => {
                    tradeItems.forEach(i => i.classList.remove('active'));
                    this.classList.add('active');

                    tradeContentBox.style.opacity = '0';
                    setTimeout(() => {
                        contentTitle.innerHTML  = data.title;
                        contentDesc.textContent = data.desc;
                        contentExtra.innerHTML  = `${data.extra} <a href="${servicesUrl}" class="view-more">View More</a>`;
                        contentImg.src = data.img;
                        contentImg.alt = data.title.replace(/<[^>]+>/g, '');
                        tradeContentBox.style.opacity = '1';
                        tradeContentBox.classList.add('fade-in');
                    }, 300);
                });
            });
        });
    }

    /* ─────────────────────────────────────────
       FAQ ACCORDION
    ───────────────────────────────────────── */
    const faqAccordion = document.getElementById('faqAccordion');
    if (faqAccordion) {
        faqAccordion.querySelectorAll('.faq-item').forEach(item => {
            item.querySelector('.faq-question').addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                faqAccordion.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
                if (!isActive) item.classList.add('active');
            });
        });
    }

    /* ─────────────────────────────────────────
       TESTIMONIAL SLIDER (High-Performance rAF)
    ───────────────────────────────────────── */
    const track   = document.getElementById('testimonialTrack');
    const prevBtn = document.getElementById('prevTestimonial');
    const nextBtn = document.getElementById('nextTestimonial');
    const dots    = document.querySelectorAll('.testimonials-about .dot');

    if (track && prevBtn && nextBtn) {
        const cards     = track.children;
        let currentIndex = 0;
        const totalCards = cards.length;

        function updateSlider(index) {
            const cardWidth  = cards[0].offsetWidth + 20;
            const visibleNum = window.innerWidth > 1200 ? 3 : window.innerWidth > 768 ? 2 : 1;
            const maxIndex   = totalCards - visibleNum;

            currentIndex = Math.max(0, Math.min(index, maxIndex));
            track.style.transform = `translateX(${-currentIndex * cardWidth}px)`;

            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === Math.round(currentIndex / (totalCards / dots.length)));
            });
        }

        nextBtn.addEventListener('click', () => {
            window.requestAnimationFrame(() => {
                updateSlider(currentIndex + 1);
            });
        });

        prevBtn.addEventListener('click', () => {
            window.requestAnimationFrame(() => {
                updateSlider(currentIndex - 1);
            });
        });

        let resizeTick = false;
        window.addEventListener('resize', () => {
            if (!resizeTick) {
                window.requestAnimationFrame(() => {
                    updateSlider(currentIndex);
                    resizeTick = false;
                });
                resizeTick = true;
            }
        }, { passive: true });

        dots.forEach((dot, i) => {
            dot.addEventListener('click', () => {
                window.requestAnimationFrame(() => {
                    updateSlider(Math.floor(i * (totalCards / dots.length)));
                });
            });
        });
    }

    /* ─────────────────────────────────────────
       LEGAL PAGES — sticky TOC + scroll spy
    ───────────────────────────────────────── */
    document.querySelectorAll('.privacy-toc').forEach((legalToc) => {
        const tocLinks = legalToc.querySelectorAll('.privacy-toc__list a');
        const tocToggle = legalToc.querySelector('.privacy-toc__toggle');
        const tocCurrent = legalToc.querySelector('.privacy-toc__current');
        const sections = [];

        const setActive = (link) => {
            tocLinks.forEach((item) => item.classList.remove('is-active'));
            if (!link) return;
            link.classList.add('is-active');
            if (tocCurrent) tocCurrent.textContent = link.textContent.trim();
        };

        tocLinks.forEach((link) => {
            const id = link.getAttribute('href');
            const target = id ? document.querySelector(id) : null;
            if (target) {
                sections.push({ id, target, link });
            }
            link.addEventListener('click', () => {
                setActive(link);
                legalToc.classList.remove('is-open');
                if (tocToggle) tocToggle.setAttribute('aria-expanded', 'false');
            });
        });

        if (tocToggle) {
            tocToggle.addEventListener('click', () => {
                const open = legalToc.classList.toggle('is-open');
                tocToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            });
        }

        if (sections.length && 'IntersectionObserver' in window) {
            const observer = new IntersectionObserver(
                (entries) => {
                    const visible = entries
                        .filter((entry) => entry.isIntersecting)
                        .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
                    if (!visible.length) return;
                    const match = sections.find((section) => section.target === visible[0].target);
                    if (match) setActive(match.link);
                },
                { rootMargin: '-20% 0px -65% 0px', threshold: [0, 0.25, 0.5, 1] }
            );
            sections.forEach((section) => observer.observe(section.target));
            setActive(sections[0].link);
        }
    });

});