(function () {
	'use strict';

	var zone = document.getElementById('swift-rm-dropzone');
	var input = document.getElementById('swift_rm_csv');
	var chip = document.getElementById('swift-rm-file-chip');
	var nameEl = document.getElementById('swift-rm-file-name');

	if (!zone || !input) {
		return;
	}

	function setFileLabel(file) {
		if (!file || !chip || !nameEl) {
			return;
		}
		nameEl.textContent = file.name;
		zone.classList.add('is-ready');
		chip.style.display = 'inline-flex';
	}

	input.addEventListener('change', function () {
		if (input.files && input.files[0]) {
			setFileLabel(input.files[0]);
		}
	});

	['dragenter', 'dragover'].forEach(function (evt) {
		zone.addEventListener(evt, function (e) {
			e.preventDefault();
			e.stopPropagation();
			zone.classList.add('is-dragover');
		});
	});

	['dragleave', 'drop'].forEach(function (evt) {
		zone.addEventListener(evt, function (e) {
			e.preventDefault();
			e.stopPropagation();
			zone.classList.remove('is-dragover');
		});
	});

	zone.addEventListener('drop', function (e) {
		var files = e.dataTransfer && e.dataTransfer.files;
		if (!files || !files.length) {
			return;
		}
		input.files = files;
		setFileLabel(files[0]);
	});
})();
