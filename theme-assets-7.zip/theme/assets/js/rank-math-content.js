/**
 * Feed Trade/Service SCF field HTML into Rank Math content analysis.
 *
 * Depends on: wp-hooks, rank-math-analyzer
 * Localized: window.swiftRankMathContent
 */
(function () {
  'use strict';

  if (typeof wp === 'undefined' || !wp.hooks || typeof swiftRankMathContent === 'undefined') {
    return;
  }

  var state = {
    html: swiftRankMathContent.html || '',
  };

  function appendScfContent(content) {
    if (!state.html) {
      return content;
    }
    return (content || '') + '\n' + state.html;
  }

  wp.hooks.addFilter('rank_math_content', 'swift-takeoffs/scf-content', appendScfContent);

  function refreshAnalyzer() {
    if (typeof rankMathEditor !== 'undefined' && rankMathEditor.refresh) {
      rankMathEditor.refresh('content');
      return;
    }
    if (typeof rankMathAPI !== 'undefined' && rankMathAPI.refreshContent) {
      rankMathAPI.refreshContent();
    }
  }

  function reloadFromServer() {
    if (!swiftRankMathContent.postId || !swiftRankMathContent.ajaxUrl) {
      refreshAnalyzer();
      return;
    }

    var body = new FormData();
    body.append('action', 'swift_rm_refresh_content');
    body.append('nonce', swiftRankMathContent.nonce);
    body.append('post_id', String(swiftRankMathContent.postId));

    fetch(swiftRankMathContent.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      body: body,
    })
      .then(function (res) {
        return res.json();
      })
      .then(function (json) {
        if (json && json.success && json.data && json.data.html) {
          state.html = json.data.html;
        }
        refreshAnalyzer();
      })
      .catch(function () {
        refreshAnalyzer();
      });
  }

  // After save of ACF/SCF fields in the editor, refresh analysis.
  if (typeof jQuery !== 'undefined') {
    jQuery(document).on('acf/save_success', function () {
      window.setTimeout(reloadFromServer, 400);
    });

    // Live-ish refresh when textareas/inputs inside ACF fields change.
    jQuery(document).on(
      'change input',
      '.acf-field textarea, .acf-field input[type="text"], .acf-field .wp-editor-area',
      function () {
        window.clearTimeout(window._swiftRmTimer);
        window._swiftRmTimer = window.setTimeout(refreshAnalyzer, 800);
      }
    );
  }

  // Initial pass once Rank Math is ready.
  window.setTimeout(refreshAnalyzer, 1200);
})();
