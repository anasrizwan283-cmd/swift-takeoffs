/**
 * Get a Free Quote — client validation, honeypot, AJAX submit, lead pixels.
 *
 * Endpoint + nonce + reCAPTCHA site key: window.swiftFreeQuote (wp_localize).
 */
(function () {
  'use strict';

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var PHONE_RE = /^\+?[\d\s().-]{7,22}$/;

  var MESSAGES = {
    name: 'Name is required',
    phone: 'Enter a valid phone number',
    email: 'Enter a valid email',
    service: 'Service is required',
    sms_consent: 'Please agree to SMS updates to continue',
  };

  function cfg() {
    return window.swiftFreeQuote || {};
  }

  function digitCount(value) {
    return String(value || '').replace(/\D/g, '').length;
  }

  function fillTracking(form) {
    try {
      var params = new URLSearchParams(window.location.search);
      ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'gclid'].forEach(function (key) {
        var el = form.querySelector('[name="' + key + '"]');
        if (el && params.has(key)) {
          el.value = params.get(key) || '';
        }
      });
      var landing = form.querySelector('[name="landing_page"]');
      if (landing) {
        landing.value = window.location.href;
      }
    } catch (err) {
      /* ignore */
    }
  }

  function setError(form, field, message) {
    var wrap = form.querySelector('[data-fq-field="' + field + '"]');
    var err = form.querySelector('[data-fq-error="' + field + '"]');
    var control = wrap && wrap.querySelector('input:not([type="checkbox"]):not(.st-native-select-sr), textarea');
    var custom = wrap && wrap.querySelector('.st-custom-select');
    var trigger = custom && custom.querySelector('.st-custom-select-trigger');
    var box = wrap && wrap.classList.contains('st-free-quote__consent') ? wrap : null;

    if (message) {
      if (control) {
        control.classList.add('is-invalid');
        control.setAttribute('aria-invalid', 'true');
      }
      if (custom) {
        custom.classList.add('is-error');
      }
      if (trigger) {
        trigger.setAttribute('aria-invalid', 'true');
      }
      if (box) {
        box.classList.add('is-invalid');
      }
      if (err) {
        err.textContent = message;
        err.hidden = false;
      }
    } else {
      if (control) {
        control.classList.remove('is-invalid');
        control.removeAttribute('aria-invalid');
      }
      if (custom) {
        custom.classList.remove('is-error');
      }
      if (trigger) {
        trigger.removeAttribute('aria-invalid');
      }
      if (box) {
        box.classList.remove('is-invalid');
      }
      if (err) {
        err.textContent = '';
        err.hidden = true;
      }
    }
  }

  function resetCustomSelect(form) {
    form.querySelectorAll('[data-st-select]').forEach(function (wrap) {
      var select = wrap.querySelector('select');
      var label = wrap.querySelector('.st-custom-select-label');
      var menu = wrap.querySelector('.st-custom-select-menu');
      var trigger = wrap.querySelector('.st-custom-select-trigger');
      var placeholder = wrap.getAttribute('data-placeholder') || 'Select a service';
      if (select) {
        select.value = '';
        select.selectedIndex = 0;
      }
      wrap.classList.remove('is-open', 'is-filled', 'is-error');
      if (label) {
        label.textContent = placeholder;
      }
      if (menu) {
        menu.hidden = true;
        menu.querySelectorAll('[role="option"]').forEach(function (opt) {
          opt.setAttribute('aria-selected', 'false');
        });
      }
      if (trigger) {
        trigger.setAttribute('aria-expanded', 'false');
        trigger.removeAttribute('aria-invalid');
      }
    });
  }

  function initCustomSelects(form) {
    form.querySelectorAll('[data-st-select]').forEach(function (wrap) {
      if (wrap.dataset.stSelectReady === '1') {
        return;
      }
      wrap.dataset.stSelectReady = '1';

      var select = wrap.querySelector('select');
      var trigger = wrap.querySelector('.st-custom-select-trigger');
      var label = wrap.querySelector('.st-custom-select-label');
      var menu = wrap.querySelector('.st-custom-select-menu');
      if (!select || !trigger || !label || !menu) {
        return;
      }

      var options = Array.prototype.slice.call(menu.querySelectorAll('[role="option"]'));

      function setOpen(open) {
        wrap.classList.toggle('is-open', open);
        trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
        menu.hidden = !open;
      }

      function selectValue(value, optionEl) {
        select.value = value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
        wrap.classList.toggle('is-filled', !!value);
        wrap.classList.remove('is-error');
        options.forEach(function (opt) {
          opt.setAttribute('aria-selected', opt === optionEl ? 'true' : 'false');
        });
        if (optionEl) {
          label.textContent = optionEl.textContent.trim();
        }
        setOpen(false);
        trigger.focus();
      }

      trigger.addEventListener('click', function (e) {
        e.preventDefault();
        setOpen(menu.hidden);
      });

      options.forEach(function (opt) {
        opt.addEventListener('click', function () {
          selectValue(opt.getAttribute('data-value') || '', opt);
        });
      });

      trigger.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          setOpen(true);
          var current = options.filter(function (o) {
            return o.getAttribute('aria-selected') === 'true';
          })[0] || options[0];
          if (current) {
            current.focus();
          }
        } else if (e.key === 'Escape') {
          setOpen(false);
        }
      });

      menu.addEventListener('keydown', function (e) {
        var current = document.activeElement;
        var idx = options.indexOf(current);
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          (options[Math.min(idx + 1, options.length - 1)] || options[0]).focus();
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          (options[Math.max(idx - 1, 0)] || options[0]).focus();
        } else if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          if (current && current.getAttribute('data-value')) {
            selectValue(current.getAttribute('data-value'), current);
          }
        } else if (e.key === 'Escape') {
          e.preventDefault();
          setOpen(false);
          trigger.focus();
        }
      });

      document.addEventListener('click', function (e) {
        if (!wrap.contains(e.target)) {
          setOpen(false);
        }
      });
    });
  }

  function readState(form) {
    var consent = form.querySelector('[name="sms_consent"]');
    return {
      name: (form.querySelector('[name="name"]') || {}).value || '',
      phone: (form.querySelector('[name="phone"]') || {}).value || '',
      email: (form.querySelector('[name="email"]') || {}).value || '',
      service: (form.querySelector('[name="service"]') || {}).value || '',
      message: (form.querySelector('[name="message"]') || {}).value || '',
      sms_consent: !!(consent && consent.checked),
      website: (form.querySelector('[name="website"]') || {}).value || '',
    };
  }

  function validateField(form, field, state) {
    var value = state[field];
    var msg = '';

    if (field === 'name' && !String(value).trim()) {
      msg = MESSAGES.name;
    } else if (field === 'email') {
      var email = String(value).trim();
      if (!email || !EMAIL_RE.test(email)) {
        msg = MESSAGES.email;
      }
    } else if (field === 'phone') {
      var phone = String(value).trim();
      if (!phone || !PHONE_RE.test(phone) || digitCount(phone) < 10) {
        msg = MESSAGES.phone;
      }
    } else if (field === 'service' && !String(value).trim()) {
      msg = MESSAGES.service;
    } else if (field === 'sms_consent' && !value) {
      msg = MESSAGES.sms_consent;
    }

    setError(form, field, msg);
    return !msg;
  }

  function validateForm(form, onSubmit) {
    var state = readState(form);
    var fields = ['name', 'phone', 'email', 'service'];
    if (onSubmit) {
      fields.push('sms_consent');
    }
    var ok = true;
    fields.forEach(function (field) {
      if (!validateField(form, field, state)) {
        ok = false;
      }
    });
    if (!onSubmit) {
      setError(form, 'sms_consent', '');
    }
    return ok ? state : null;
  }

  function showBanner(form, type, text) {
    var section = form.closest('.st-free-quote');
    if (!section) {
      return;
    }
    var success = section.querySelector('[data-fq-banner="success"]');
    var error = section.querySelector('[data-fq-banner="error"]');
    if (success) {
      success.hidden = type !== 'success';
    }
    if (error) {
      if (text && type === 'error') {
        error.textContent = text;
      }
      error.hidden = type !== 'error';
    }
  }

  function hideBanners(form) {
    showBanner(form, '', '');
  }

  function setLoading(form, loading) {
    var btn = form.querySelector('[data-fq-submit]');
    var label = form.querySelector('.st-free-quote__submit-label');
    var spinner = form.querySelector('.st-free-quote__spinner');
    if (!btn) {
      return;
    }
    btn.disabled = loading;
    btn.setAttribute('aria-busy', loading ? 'true' : 'false');
    if (label) {
      label.hidden = loading;
    }
    if (spinner) {
      spinner.hidden = !loading;
    }
  }

  /**
   * reCAPTCHA v3 — site key from wp_localize (theme / env).
   * Loads the Google script on demand if it is not already present.
   */
  function getRecaptchaToken() {
    var siteKey = cfg().recaptchaSiteKey;
    if (!siteKey) {
      return Promise.resolve('');
    }

    function execute(grecaptcha) {
      return new Promise(function (resolve) {
        grecaptcha.ready(function () {
          grecaptcha
            .execute(siteKey, { action: 'quote_request' })
            .then(resolve)
            .catch(function () {
              resolve('');
            });
        });
      });
    }

    if (typeof window.grecaptcha !== 'undefined') {
      return execute(window.grecaptcha);
    }

    return new Promise(function (resolve) {
      var existing = document.querySelector('script[src*="recaptcha/api.js"]');
      function onLoad() {
        if (window.grecaptcha) {
          execute(window.grecaptcha).then(resolve);
        } else {
          resolve('');
        }
      }
      if (existing) {
        existing.addEventListener('load', onLoad);
        window.setTimeout(onLoad, 2500);
        return;
      }
      var s = document.createElement('script');
      s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(siteKey);
      s.async = true;
      s.onload = onLoad;
      s.onerror = function () {
        resolve('');
      };
      document.head.appendChild(s);
    });
  }

  function fireLeadEvents(state) {
    if (typeof window === 'undefined') {
      return;
    }
    try {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: 'generate_lead',
        form_name: 'free_quote',
        service: state.service || '',
      });
    } catch (err) {
      /* ignore */
    }
    try {
      if (typeof window.fbq === 'function') {
        window.fbq('track', 'Lead', {
          content_name: 'Free Quote',
          content_category: state.service || '',
        });
      }
    } catch (err2) {
      /* ignore */
    }
  }

  /**
   * POST JSON to the WP REST stub (`swift/v1/quote-request`).
   * Swap cfg().endpoint later if you move this to an external CRM webhook proxy.
   */
  async function handleSubmit(form, event) {
    event.preventDefault();
    hideBanners(form);
    fillTracking(form);

    var state = validateForm(form, true);
    if (!state) {
      var firstInvalid = form.querySelector('.st-custom-select.is-error .st-custom-select-trigger, .is-invalid, [aria-invalid="true"]');
      if (firstInvalid && typeof firstInvalid.focus === 'function') {
        firstInvalid.focus();
      }
      return;
    }

    // Honeypot filled → silent no-op (pretend success, do not POST).
    if (String(state.website).trim()) {
      form.reset();
      resetCustomSelect(form);
      showBanner(form, 'success');
      return;
    }

    setLoading(form, true);

    var tokenField = form.querySelector('[name="recaptcha_token"]');
    var recaptchaToken = '';
    try {
      recaptchaToken = await getRecaptchaToken();
      if (tokenField) {
        tokenField.value = recaptchaToken;
      }
    } catch (recaptchaErr) {
      recaptchaToken = '';
    }

    var nonceField = form.querySelector('[name="form_nonce"]');
    var payload = {
      name: String(state.name).trim(),
      phone: String(state.phone).trim(),
      email: String(state.email).trim(),
      service: String(state.service).trim(),
      message: String(state.message).trim(),
      sms_consent: state.sms_consent ? '1' : '',
      website: '',
      form_nonce: nonceField ? nonceField.value : '',
      recaptcha_token: recaptchaToken,
      lead_funnel: (form.querySelector('[name="lead_funnel"]') || {}).value || '',
      utm_source: (form.querySelector('[name="utm_source"]') || {}).value || '',
      utm_medium: (form.querySelector('[name="utm_medium"]') || {}).value || '',
      utm_campaign: (form.querySelector('[name="utm_campaign"]') || {}).value || '',
      utm_content: (form.querySelector('[name="utm_content"]') || {}).value || '',
      utm_term: (form.querySelector('[name="utm_term"]') || {}).value || '',
      gclid: (form.querySelector('[name="gclid"]') || {}).value || '',
      landing_page: (form.querySelector('[name="landing_page"]') || {}).value || window.location.href,
    };

    try {
      var res = await fetch(cfg().endpoint || form.action, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': cfg().nonce || '',
        },
        body: JSON.stringify(payload),
      });

      var json = null;
      try {
        json = await res.json();
      } catch (parseErr) {
        json = null;
      }

      var ok = !!(res.ok && json && json.success === true);

      if (!ok) {
        var message =
          (json && (json.message || (json.data && json.data.message))) ||
          'Something went wrong. Please try again.';
        showBanner(form, 'error', message);
        setLoading(form, false);
        return;
      }

      fireLeadEvents(state);
      form.reset();
      resetCustomSelect(form);
      ['name', 'phone', 'email', 'service', 'sms_consent'].forEach(function (field) {
        setError(form, field, '');
      });
      showBanner(form, 'success');
      setLoading(form, false);
    } catch (err) {
      showBanner(form, 'error', 'Something went wrong. Please try again.');
      setLoading(form, false);
    }
  }

  function bindForm(form) {
    if (form.dataset.fqBound === '1') {
      return;
    }
    form.dataset.fqBound = '1';
    fillTracking(form);
    initCustomSelects(form);

    form.addEventListener('blur', function (event) {
      var target = event.target;
      if (!target || !target.name) {
        return;
      }
      var field = target.name === 'sms_consent' ? 'sms_consent' : target.name;
      if (['name', 'phone', 'email', 'service'].indexOf(field) === -1) {
        return;
      }
      validateField(form, field, readState(form));
    }, true);

    form.addEventListener('change', function (event) {
      if (event.target && event.target.name === 'service') {
        validateField(form, 'service', readState(form));
      }
      if (event.target && event.target.name === 'sms_consent' && event.target.checked) {
        setError(form, 'sms_consent', '');
      }
    });

    form.addEventListener('submit', function (event) {
      handleSubmit(form, event);
    });
  }

  function init() {
    document.querySelectorAll('[data-fq-form]').forEach(bindForm);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
