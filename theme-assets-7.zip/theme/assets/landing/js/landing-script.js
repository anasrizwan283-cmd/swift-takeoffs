// DOM Content Loaded - Initialize all components when page loads
const SWIFT_RECAPTCHA_SITE_KEY =
  (typeof ST_LANDING_FORM !== 'undefined' && ST_LANDING_FORM.siteKey) ||
  '';

function withRecaptchaToken(form, callback) {
  const run = function (token) {
    let tokenField = form.querySelector('input[name="recaptcha_token"]');
    if (!tokenField) {
      tokenField = document.createElement('input');
      tokenField.type = 'hidden';
      tokenField.name = 'recaptcha_token';
      form.appendChild(tokenField);
    }
    tokenField.value = token || '';
    callback();
  };

  if (typeof grecaptcha === 'undefined') {
    const start = Date.now();
    const wait = setInterval(function () {
      if (typeof grecaptcha !== 'undefined') {
        clearInterval(wait);
        grecaptcha.ready(function () {
          grecaptcha
            .execute(SWIFT_RECAPTCHA_SITE_KEY, { action: 'submit' })
            .then(run)
            .catch(function () {
              run('');
            });
        });
      } else if (Date.now() - start > 4000) {
        clearInterval(wait);
        run('');
      }
    }, 150);
    return;
  }

  grecaptcha.ready(function () {
    grecaptcha
      .execute(SWIFT_RECAPTCHA_SITE_KEY, { action: 'submit' })
      .then(run)
      .catch(function () {
        run('');
      });
  });
}

function fillLandingTracking(form) {
  const params = new URLSearchParams(window.location.search);
  ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'gclid'].forEach(
    function (key) {
      const el = form.querySelector('[name="' + key + '"]');
      if (el && params.has(key)) el.value = params.get(key) || '';
    }
  );
  const landing = form.querySelector('[name="landing_page"]');
  if (landing) landing.value = window.location.href;
}

function prepareHeroExtras(form) {
  const trades = form.querySelector('#tradesInput');
  const level = form.querySelector('#levelSelect');
  const scope = form.querySelector('#hero_fq_scope');
  const message = form.querySelector('#hero_fq_message');
  if (scope && trades) scope.value = trades.value.trim();
  if (message) {
    const bits = [];
    if (trades && trades.value.trim()) bits.push('Trades: ' + trades.value.trim());
    if (level && level.value) bits.push('Level: ' + level.value);
    bits.push('Source: Swift Takeoffs landing hero');
    message.value = bits.join(' | ');
  }
}

function submitLeadAjax(form) {
  const ajaxUrl =
    (typeof ST_LANDING_FORM !== 'undefined' && ST_LANDING_FORM.ajaxUrl) ||
    '/wp-admin/admin-ajax.php';
  const body = new FormData(form);
  body.set('action', 'swift_lead_submission');

  return fetch(ajaxUrl, {
    method: 'POST',
    credentials: 'same-origin',
    body: body,
  }).then(function (res) {
    return res.json().then(function (json) {
      if (!res.ok || !json || !json.success) {
        const msg =
          (json && json.data && json.data.message) ||
          (typeof ST_LANDING_FORM !== 'undefined' && ST_LANDING_FORM.errorGeneric) ||
          'Something went wrong. Please try again.';
        throw new Error(msg);
      }
      return json;
    });
  });
}

function openThanksModal() {
  const modal = document.getElementById('stLeadThanksModal');
  if (!modal) {
    showNotification('Thank you! Your request has been sent.');
    return;
  }
  modal.hidden = false;
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('st-thanks-open');
  requestAnimationFrame(function () {
    modal.classList.add('is-open');
  });
  const closeBtn = modal.querySelector('.st-thanks-btn, .st-thanks-close');
  if (closeBtn) closeBtn.focus();
}

function closeThanksModal() {
  const modal = document.getElementById('stLeadThanksModal');
  if (!modal) return;
  modal.classList.remove('is-open');
  document.body.classList.remove('st-thanks-open');
  setTimeout(function () {
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
  }, 280);
}

function initThanksModal() {
  const modal = document.getElementById('stLeadThanksModal');
  if (!modal) return;
  modal.querySelectorAll('[data-st-thanks-close]').forEach(function (el) {
    el.addEventListener('click', closeThanksModal);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && modal.classList.contains('is-open')) {
      closeThanksModal();
    }
  });
}

document.addEventListener('DOMContentLoaded', function () {
  initFAQAccordion();
  initFormHandlers();
  initThanksModal();
  initSmoothScrolling();
  initCounterAnimation();
  initLazyLoading();

  if (new URLSearchParams(window.location.search).get('form_success') === '1') {
    openThanksModal();
  }
});

function initFAQAccordion() {
  const faqQuestions = document.querySelectorAll('.faq-question');
  faqQuestions.forEach((question) => {
    question.addEventListener('click', function () {
      const answer = this.nextElementSibling;
      this.classList.toggle('active');
      answer.classList.toggle('active');
      faqQuestions.forEach((q) => {
        if (q !== this && q.classList.contains('active')) {
          q.classList.remove('active');
          q.nextElementSibling.classList.remove('active');
        }
      });
    });
  });
}

function initFormHandlers() {
  const landingRoot = document.getElementById('swift-takeoffs-landing');
  if (!landingRoot) {
    return;
  }

  const heroForm = landingRoot.querySelector('#heroForm');
  const contactForm = landingRoot.querySelector('#contactForm');

  landingRoot.querySelectorAll('.st-lead-form').forEach(function (form) {
    fillLandingTracking(form);
  });

  function bindLeadForm(form, isHero) {
    if (!form) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const valid = isHero ? validateHeroForm(form) : validateForm(form);
      if (!valid) return;

      setButtonLoading(form, true);
      if (isHero) prepareHeroExtras(form);
      fillLandingTracking(form);

      withRecaptchaToken(form, function () {
        submitLeadAjax(form)
          .then(function (json) {
            const redirect =
              (json && json.data && json.data.redirect) ||
              (typeof ST_LANDING_FORM !== 'undefined' && ST_LANDING_FORM.thankYouUrl) ||
              '';
            if (redirect) {
              window.location.href = redirect;
              return;
            }
            form.reset();
            resetBorders(form);
            setButtonLoading(form, false);
            openThanksModal();
          })
          .catch(function (err) {
            console.error(err);
            setButtonLoading(form, false);
            showNotification(err.message || 'Failed to send request.', 'error');
          });
      });
    });
  }

  bindLeadForm(heroForm, true);
  bindLeadForm(contactForm, false);
  if (heroForm) enhanceHeroForm();

  landingRoot
    .querySelectorAll('form input, form select, form textarea')
    .forEach((input) => {
      input.addEventListener('blur', () => runFieldValidation(input));
      input.addEventListener('input', () => runFieldValidation(input));
    });
}

function setButtonLoading(form, isLoading) {
  const btn = form.querySelector("button[type='submit']");
  const btnText = btn ? btn.querySelector('.btn-text') : null;
  const btnSpinner = btn ? btn.querySelector('.btn-spinner') : null;

  if (!btn) return;

  if (isLoading) {
    btn.disabled = true;
    if (btnText) btnText.textContent = 'Sending...';
    if (btnSpinner) {
      btnSpinner.classList.remove('hidden');
      btnSpinner.style.display = 'inline-block';
    }
  } else {
    btn.disabled = false;
    if (btnText) {
      btnText.textContent =
        form.id === 'contactForm' ? 'Request Quote' : 'Submit Request';
    }
    if (btnSpinner) {
      btnSpinner.classList.add('hidden');
      btnSpinner.style.display = 'none';
    }
  }
}

function validateHeroForm(form) {
  let isValid = true;

  const nameInput = form.querySelector('#nameInput, input[name="fq_name"]');
  const emailInput = form.querySelector('#emailInput, input[name="fq_email"]');
  const tradesInput = form.querySelector('#tradesInput');
  const levelSelect = form.querySelector('#levelSelect');

  if (nameInput && !nameInput.value.trim()) {
    highlightError(nameInput, 'Name is required');
    isValid = false;
  } else if (nameInput) removeErrorHighlight(nameInput);

  if (
    emailInput &&
    (!emailInput.value.trim() || !isValidEmail(emailInput.value))
  ) {
    highlightError(emailInput, 'Valid email is required');
    isValid = false;
  } else if (emailInput) removeErrorHighlight(emailInput);

  if (tradesInput && !tradesInput.value.trim()) {
    highlightError(tradesInput, 'Please enter at least one trade');
    isValid = false;
  } else if (tradesInput) removeErrorHighlight(tradesInput);

  if (levelSelect && !levelSelect.value) {
    highlightError(levelSelect, 'Please select a level type');
    isValid = false;
  } else if (levelSelect) removeErrorHighlight(levelSelect);

  return isValid;
}

function validateForm(form) {
  let isValid = true;
  form
    .querySelectorAll('input[required], select[required], textarea[required]')
    .forEach((input) => {
      if (!input.value.trim()) {
        highlightError(input, 'This field is required');
        isValid = false;
      } else if (input.type === 'email' && !isValidEmail(input.value)) {
        highlightError(input, 'Please enter a valid email address');
        isValid = false;
      } else {
        removeErrorHighlight(input);
      }
    });
  return isValid;
}

function runFieldValidation(input) {
  if (input.hasAttribute('required') && !input.value.trim()) {
    highlightError(input, 'This field is required');
  } else if (
    input.type === 'email' &&
    input.value &&
    !isValidEmail(input.value)
  ) {
    highlightError(input, 'Please enter a valid email address');
  } else {
    removeErrorHighlight(input);
  }
}

function enhanceHeroForm() {
  const landingRoot = document.getElementById('swift-takeoffs-landing');
  const tradesInput = landingRoot
    ? landingRoot.querySelector('#tradesInput')
    : null;

  if (tradesInput) {
    tradesInput.addEventListener('input', function () {
      this.style.borderColor = this.value.trim() ? 'var(--primary)' : '';
      if (this.value.trim()) removeErrorHighlight(this);
    });
  }

  initCustomSelects(landingRoot);
}

function initCustomSelects(root) {
  if (!root) return;
  root.querySelectorAll('[data-st-select]').forEach(function (wrap) {
    if (wrap.dataset.stSelectReady === '1') return;
    wrap.dataset.stSelectReady = '1';

    const select = wrap.querySelector('select');
    const trigger = wrap.querySelector('.st-custom-select-trigger');
    const label = wrap.querySelector('.st-custom-select-label');
    const menu = wrap.querySelector('.st-custom-select-menu');
    if (!select || !trigger || !label || !menu) return;

    const options = Array.from(menu.querySelectorAll('[role="option"]'));

    function setOpen(open) {
      wrap.classList.toggle('is-open', open);
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
      menu.hidden = !open;
    }

    function selectValue(value, optionEl) {
      select.value = value;
      select.dispatchEvent(new Event('change', { bubbles: true }));
      wrap.classList.toggle('is-filled', !!value);
      wrap.classList.remove('is-error');
      options.forEach(function (opt) {
        const selected = opt === optionEl || opt.getAttribute('data-value') === value;
        opt.setAttribute('aria-selected', selected ? 'true' : 'false');
      });
      if (optionEl) {
        const title = optionEl.querySelector('.st-option-title');
        label.textContent = title ? title.textContent : optionEl.textContent.trim();
      }
      removeErrorHighlight(select);
      setOpen(false);
      trigger.focus();
    }

    trigger.addEventListener('click', function (e) {
      e.preventDefault();
      setOpen(menu.hidden);
    });

    options.forEach(function (opt) {
      opt.addEventListener('click', function () {
        selectValue(opt.getAttribute('data-value') || '', opt);
      });
    });

    trigger.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        setOpen(true);
        const current =
          options.find(function (o) {
            return o.getAttribute('aria-selected') === 'true';
          }) || options[0];
        if (current) current.focus();
      } else if (e.key === 'Escape') {
        setOpen(false);
      }
    });

    menu.addEventListener('keydown', function (e) {
      const current = document.activeElement;
      const idx = options.indexOf(current);
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        const next = options[Math.min(idx + 1, options.length - 1)] || options[0];
        next.focus();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        const prev = options[Math.max(idx - 1, 0)] || options[0];
        prev.focus();
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        if (current && current.getAttribute('data-value')) {
          selectValue(current.getAttribute('data-value'), current);
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setOpen(false);
        trigger.focus();
      }
    });

    document.addEventListener('click', function (e) {
      if (!wrap.contains(e.target)) setOpen(false);
    });
  });
}

function resetBorders(form) {
  form.querySelectorAll('input, select, textarea').forEach((input) => {
    input.style.borderColor = '';
    removeErrorHighlight(input);
  });
  form.querySelectorAll('.st-custom-select').forEach(function (wrap) {
    wrap.classList.remove('is-error', 'is-open', 'is-filled');
    const label = wrap.querySelector('.st-custom-select-label');
    const menu = wrap.querySelector('.st-custom-select-menu');
    const trigger = wrap.querySelector('.st-custom-select-trigger');
    if (label) label.textContent = 'Select Level Type';
    if (menu) {
      menu.hidden = true;
      menu.querySelectorAll('[role="option"]').forEach(function (opt) {
        opt.setAttribute('aria-selected', 'false');
      });
    }
    if (trigger) trigger.setAttribute('aria-expanded', 'false');
  });
}

const isValidEmail = (email) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).toLowerCase());

function highlightError(input, message = 'This field is required') {
  const wrap = input.closest('.st-custom-select');
  if (wrap) {
    wrap.classList.add('is-error');
  } else {
    input.style.borderColor = '#E53E3E';
  }
  const host = wrap || input.parentNode;
  const existingError = host.querySelector('.error-message');
  if (existingError) existingError.remove();

  const error = document.createElement('div');
  error.className = 'error-message';
  error.style.color = '#E53E3E';
  error.style.fontSize = '14px';
  error.style.marginTop = '5px';
  error.textContent = message;
  host.appendChild(error);
}
function removeErrorHighlight(input) {
  const wrap = input.closest('.st-custom-select');
  if (wrap) wrap.classList.remove('is-error');
  input.style.borderColor = '';
  const host = wrap || input.parentNode;
  const error = host.querySelector('.error-message');
  if (error) error.remove();
}

function initSmoothScrolling() {
  const landingRoot = document.getElementById('swift-takeoffs-landing');
  if (!landingRoot) {
    return;
  }

  const siteHeader =
    document.querySelector('#masthead') ||
    document.querySelector('header.site-header') ||
    document.querySelector('header');

  landingRoot.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        const headerHeight = siteHeader ? siteHeader.offsetHeight : 0;
        window.scrollTo({
          top: targetElement.offsetTop - headerHeight,
          behavior: 'smooth',
        });
        history.pushState(null, null, targetId);
      }
    });
  });
}

function initCounterAnimation() {
  const statNumbers = document.querySelectorAll('.stat-number');
  const statsSection = document.querySelector('.stats');
  let counted = false;
  if (!statNumbers.length || !statsSection) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && !counted) {
          counted = true;
          statNumbers.forEach((stat) => animateCounter(stat));
        }
      });
    },
    { threshold: 0.5 }
  );

  observer.observe(statsSection);
}
function animateCounter(stat) {
  const target = parseInt(stat.getAttribute('data-count'));
  const duration = 2000;
  const increment = target / (duration / 16);
  let current = 0;
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      clearInterval(timer);
      stat.textContent =
        target + (stat.getAttribute('data-count') === '60' ? '%' : '+');
    } else {
      stat.textContent =
        Math.floor(current) +
        (stat.getAttribute('data-count') === '60' ? '%' : '+');
    }
  }, 16);
}

function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.innerHTML = `<span>${message}</span><button class="notification-close" type="button">&times;</button>`;
  if (!document.getElementById('notification-styles')) {
    const styles = document.createElement('style');
    styles.id = 'notification-styles';
    styles.textContent = `
            .notification {
                position: fixed; bottom: 20px; right: 20px;
                padding: 15px 20px; border-radius: 6px;
                color: white; background: #0284c7;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 10000; display: flex;
                align-items: center; justify-content: space-between;
                min-width: 300px; transform: translateY(100px);
                opacity: 0; transition: all 0.3s ease;
            }
            .notification.success { background: #059669; }
            .notification.error { background: #E53E3E; }
            .notification.show { transform: translateY(0); opacity: 1; }
            .notification-close {
                background: none; border: none; color: white;
                font-size: 20px; cursor: pointer; margin-left: 15px;
            }
        `;
    document.head.appendChild(styles);
  }
  document.body.appendChild(notification);
  setTimeout(() => notification.classList.add('show'), 10);
  notification
    .querySelector('.notification-close')
    .addEventListener('click', () => hideNotification(notification));
  setTimeout(() => hideNotification(notification), 5000);
}
function hideNotification(notification) {
  notification.classList.remove('show');
  setTimeout(() => notification.remove(), 300);
}

function initLazyLoading() {
  if ('IntersectionObserver' in window) {
    const lazyImages = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          imageObserver.unobserve(img);
        }
      });
    });
    lazyImages.forEach((img) => imageObserver.observe(img));
  }
}

const slider = document.getElementById('softwareSlider');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');

let autoSlide;
const slideAmount = 160;

function startAutoSlide() {
  if (!slider) return;
  autoSlide = setInterval(() => {
    slider.scrollBy({ left: slideAmount, behavior: 'smooth' });
    if (slider.scrollLeft + slider.clientWidth >= slider.scrollWidth) {
      slider.scrollTo({ left: 0, behavior: 'smooth' });
    }
  }, 2500);
}

function stopAutoSlide() {
  clearInterval(autoSlide);
}

if (prevBtn && nextBtn && slider) {
  prevBtn.addEventListener('click', () => {
    stopAutoSlide();
    slider.scrollBy({ left: -slideAmount, behavior: 'smooth' });
    startAutoSlide();
  });

  nextBtn.addEventListener('click', () => {
    stopAutoSlide();
    slider.scrollBy({ left: slideAmount, behavior: 'smooth' });
    startAutoSlide();
  });

  if (window.innerWidth <= 576) {
    startAutoSlide();
  }
}
