(() => {
  const root = document.querySelector('#st-drywall-landing');
  if (!root) return;

  const form = root.querySelector('#quoteForm');
  const fileInput = root.querySelector('#plans');
  const fileName = root.querySelector('#fileName');
  const message = root.querySelector('#formMessage');
  const messageField = root.querySelector('#fq_message');

  const fillTracking = () => {
    if (!form) return;
    const params = new URLSearchParams(window.location.search);
    const keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'gclid'];
    keys.forEach((key) => {
      const el = form.querySelector(`[name="${key}"]`);
      if (el && params.has(key)) el.value = params.get(key) || '';
    });
    const landing = form.querySelector('[name="landing_page"]');
    if (landing) landing.value = window.location.href;
  };

  fillTracking();

  if (fileInput && fileName) {
    fileInput.addEventListener('change', () => {
      fileName.textContent = fileInput.files.length ? fileInput.files[0].name : 'Choose files';
    });
  }

  if (form) {
    const fields = [...form.querySelectorAll('[required]')];
    fields.forEach((field) =>
      field.addEventListener('input', () => field.classList.remove('invalid'))
    );

    form.addEventListener('submit', (event) => {
      let valid = true;
      fields.forEach((field) => {
        const invalid =
          !field.value.trim() || (field.type === 'email' && !field.validity.valid);
        field.classList.toggle('invalid', invalid);
        valid = valid && !invalid;
      });

      if (!valid) {
        event.preventDefault();
        if (message) message.textContent = 'Please complete the highlighted fields.';
        const firstInvalid = form.querySelector('.invalid');
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      if (messageField) {
        const scope = form.querySelector('[name="fq_scope"]');
        const company = form.querySelector('[name="fq_company"]');
        const bits = [];
        if (scope && scope.value) bits.push('Project type: ' + scope.value.trim());
        if (company && company.value) bits.push('Company: ' + company.value.trim());
        bits.push('Source: Drywall estimating landing');
        messageField.value = bits.join(' | ');
      }

      if (message) message.textContent = 'Submitting your request…';
      // Allow native submit so WP admin-post + reCAPTCHA handlers run.
    });
  }

  const observer = new IntersectionObserver(
    (entries) =>
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      }),
    { threshold: 0.12 }
  );
  root.querySelectorAll('.reveal').forEach((element) => observer.observe(element));

  root.querySelectorAll('.marquee-track').forEach((track) => {
    const originalSet = track.querySelector('.logo-set');
    if (!originalSet) return;
    const duplicateSet = originalSet.cloneNode(true);
    duplicateSet.setAttribute('aria-hidden', 'true');
    track.appendChild(duplicateSet);
  });
})();
