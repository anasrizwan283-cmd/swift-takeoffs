(() => {
  const root = document.querySelector('#st-campaign-lander');
  if (!root) return;

  const form = root.querySelector('#quote-form-el');
  const fileInput = root.querySelector('#cl-file-upload');
  const uploadBox = root.querySelector('#upload-box');
  const uploadTitle = uploadBox ? uploadBox.querySelector('.upload-title') : null;
  const status = root.querySelector('#cl-form-status');
  const defaultUploadTitle = uploadTitle ? uploadTitle.textContent : '';

  if (fileInput && uploadBox && uploadTitle) {
    fileInput.addEventListener('change', () => {
      uploadTitle.textContent = fileInput.files.length
        ? fileInput.files[0].name
        : defaultUploadTitle;
    });

    ['dragover', 'dragleave', 'drop'].forEach((eventName) => {
      uploadBox.addEventListener(eventName, (e) => e.preventDefault());
    });

    uploadBox.addEventListener('dragover', () => uploadBox.classList.add('is-dragover'));
    uploadBox.addEventListener('dragleave', () => uploadBox.classList.remove('is-dragover'));
    uploadBox.addEventListener('drop', (e) => {
      uploadBox.classList.remove('is-dragover');
      if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        fileInput.dispatchEvent(new Event('change'));
      }
    });
  }

  root.querySelectorAll('.faq-item .faq-summary').forEach((trigger) => {
    trigger.addEventListener('click', () => {
      const item = trigger.closest('.faq-item');
      if (!item) return;
      const open = !item.classList.contains('is-open');
      item.classList.toggle('is-open', open);
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  if (form) {
    const fields = [...form.querySelectorAll('[required]')];
    fields.forEach((field) =>
      field.addEventListener('input', () => field.classList.remove('invalid'))
    );

    form.addEventListener('submit', (event) => {
      let valid = true;
      fields.forEach((field) => {
        const invalid =
          !field.value.trim() || (field.type === 'email' && !field.validity.valid);
        field.classList.toggle('invalid', invalid);
        valid = valid && !invalid;
      });

      if (!valid) {
        event.preventDefault();
        if (status) {
          status.hidden = false;
          status.textContent = 'Please complete the highlighted fields.';
        }
        const firstInvalid = form.querySelector('.invalid');
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      if (status) {
        status.hidden = false;
        status.textContent = 'Submitting your request…';
      }
    });
  }
})();
