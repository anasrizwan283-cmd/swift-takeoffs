<?php
/**
 * Trade Archive Template
 *
 * 4-column icon card grid layout.
 * URL: yourdomain.com/trades/
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
swift_takeoffs_page_banner( __( 'Trade Services', 'swift-takeoffs' ), 'trade-archive-banner' );
?>

<!-- ===== TRADE ARCHIVE SECTION ===== -->
<section class="trade-archive-sec">
	<div class="container container-column">

		<!-- Section heading -->
		<div class="trade-archive-header">
			<h2 class="trade-archive-heading">
				<?php esc_html_e( 'Comprehensive', 'swift-takeoffs' ); ?>
				<span><?php esc_html_e( 'Trades Coverage', 'swift-takeoffs' ); ?></span>
			</h2>
			<p><?php esc_html_e( 'We provide specialized estimating and takeoff services that support contractors in accurately estimating costs and quantities across all trades, ensuring accuracy and detail for every aspect of your project.', 'swift-takeoffs' ); ?></p>
		</div>

		<?php if ( have_posts() ) : ?>

			<div class="trade-archive-grid">
				<?php while ( have_posts() ) : the_post();
					$icon    = get_field( 'trade_icon' );
					$excerpt = get_the_excerpt();
				?>
					<article id="trade-<?php the_ID(); ?>" <?php post_class( 'trade-archive-card' ); ?>>

						<!-- Icon -->
						<?php if ( $icon ) : ?>
							<div class="trade-card-icon">
								<i class="<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i>
							</div>
						<?php else : ?>
							<div class="trade-card-icon">
								<i class="fa-solid fa-helmet-safety" aria-hidden="true"></i>
							</div>
						<?php endif; ?>

						<!-- Title -->
						<h3 class="trade-card-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h3>

						<!-- Excerpt -->
						<?php if ( $excerpt ) : ?>
							<p class="trade-card-desc"><?php echo esc_html( $excerpt ); ?></p>
						<?php endif; ?>

						<!-- CTA -->
						<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="trade-card-cta">
							<?php esc_html_e( 'Request Quote', 'swift-takeoffs' ); ?>
						</a>

					</article>
				<?php endwhile; ?>
			</div>

			<!-- Bottom note -->
			<p class="trade-archive-note">
				<?php
				printf(
					wp_kses(
						/* translators: %s: contact us link */
						__( 'Need a specialized trade estimate? <a href="%s">Contact Us</a> to speak with our trade experts.', 'swift-takeoffs' ),
						array( 'a' => array( 'href' => array() ) )
					),
					esc_url( home_url( '/contact/' ) )
				);
				?>
			</p>

		<?php else : ?>
			<p class="no-posts-message"><?php esc_html_e( 'No trade services found. Check back soon!', 'swift-takeoffs' ); ?></p>
		<?php endif; ?>

	</div>
</section>

<!-- ===== BOTTOM CTA BANNER ===== -->
<section class="trade-archive-cta-banner">
	<div class="container">
		<div class="trade-cta-banner-content">
			<h2><?php esc_html_e( 'Accurate Estimates for Every Trade', 'swift-takeoffs' ); ?></h2>
			<p><?php esc_html_e( 'Our team of specialized estimators ensures that every trade is covered with the highest level of detail and accuracy. We empower contractors with accurate data to win more bids and manage projects effectively.', 'swift-takeoffs' ); ?></p>
		</div>
		<div class="trade-cta-banner-action">
			<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-quote btn-quote-white">
				<?php esc_html_e( 'Request a Custom Quote', 'swift-takeoffs' ); ?>
				<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
			</a>
		</div>
	</div>
</section>

<?php get_footer(); ?>