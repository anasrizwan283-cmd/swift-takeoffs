<?php
/**
 * 404 Error Page Template
 *
 * @package SwiftTakeoffs
 */

get_header();
?>

	<section class="error-404-sec">
		<div class="container container-column" style="text-align:center; padding: 100px 20px;">
			<h1 style="font-size:8rem; color:#0163be; margin-bottom:0;">404</h1>
			<h2 style="font-size:2rem; margin-bottom:20px;"><?php esc_html_e( 'Page Not Found', 'swift-takeoffs' ); ?></h2>
			<p style="max-width:500px; margin:0 auto 30px;"><?php esc_html_e( "Sorry, the page you're looking for doesn't exist or has been moved.", 'swift-takeoffs' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-primary" style="display:inline-flex;align-items:center;gap:8px;">
				<?php esc_html_e( 'Back to Home', 'swift-takeoffs' ); ?>
				<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
			</a>
		</div>
	</section>

<?php get_footer(); ?>
