<?php
/**
 * Template Name: Drywall Thank You
 * Description: Legacy drywall thank-you URL — redirects to the generic Thank You page.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$target = function_exists( 'swift_get_thank_you_url' )
	? swift_get_thank_you_url( 'drywall-estimating' )
	: home_url( '/thank-you/?from=drywall-estimating' );

wp_safe_redirect( $target, 301 );
exit;
