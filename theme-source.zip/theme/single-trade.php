<?php
/**
 * Single Trade Template
 *
 * Renders every individual Trade post (CPT: trade).
 * Template hierarchy: single-trade.php → single.php → index.php
 *
 * Required SCF Fields (attached to 'trade' post type):
 *   trade_banner_image      Image (URL)
 *   trade_main_image        Image (URL)
 *   trade_intro_text        Wysiwyg
 *   trade_cost_factors      Repeater → cost_title (Text), cost_desc (Textarea)
 *   trade_takeoff_text      Wysiwyg
 *   trade_why_choose_items  Repeater → why_title (Text), why_desc (Textarea)
 *   trade_why_choose_image  Image (URL)
 *   trade_cta_text          Text
 *
 * @package SwiftTakeoffs
 */

get_header();

// ── Bail early if no post found ──────────────────────────────
if ( ! have_posts() ) {
	get_footer();
	return;
}

the_post();

// ── Pull all SCF custom fields ───────────────────────────────
$banner_image     = function_exists( 'swift_takeoffs_singular_banner_image' ) ? swift_takeoffs_singular_banner_image( get_the_ID() ) : array();
$main_image       = function_exists( 'swift_takeoffs_image' ) ? swift_takeoffs_image( get_field( 'trade_main_image' ), 'large' ) : array();
$intro_text       = get_field( 'trade_intro_text' );
$cost_factors     = get_field( 'trade_cost_factors' );      // repeater
$takeoff_text     = get_field( 'trade_takeoff_text' );
$why_choose_items = get_field( 'trade_why_choose_items' );  // repeater
$why_choose_image = function_exists( 'swift_takeoffs_image' ) ? swift_takeoffs_image( get_field( 'trade_why_choose_image' ), 'medium_large' ) : array();
$cta_text         = get_field( 'trade_cta_text' ) ?: __( 'Within 24/48 Hours', 'swift-takeoffs' );

// ── Sidebar: fetch up to 6 published trades ──────────────────
$sidebar_trades = swift_takeoffs_get_all_trades( 6 );
?>

<!-- ===== PAGE BANNER ===== -->
<section class="page-banner trade-page-banner<?php echo ! empty( $banner_image['url'] ) ? ' has-banner-img' : ''; ?>">
	<?php
	if ( ! empty( $banner_image['url'] ) && function_exists( 'swift_takeoffs_the_image' ) ) {
		swift_takeoffs_the_image(
			$banner_image,
			array(
				'alt'           => get_the_title(),
				'class'         => 'page-banner__img',
				'fetchpriority' => 'high',
				'sizes'         => '100vw',
				'width'         => ! empty( $banner_image['width'] ) ? $banner_image['width'] : 1600,
				'height'        => ! empty( $banner_image['height'] ) ? $banner_image['height'] : 160,
			)
		);
	}
	?>
	<div class="page-banner-overlay"></div>
	<div class="container">
		<div class="page-banner-content">
			<h1><?php the_title(); ?></h1>
			<div class="breadcrumbs">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php esc_html_e( 'Home', 'swift-takeoffs' ); ?>
				</a>
				<i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i>
				<span><?php the_title(); ?></span>
			</div>
		</div>
	</div>
</section>

<!-- ===== TRADE MAIN CONTENT ===== -->
<section class="trade-single-sec">
	<div class="container trade-single-container">

		<!-- ════════════════════════════════
		     LEFT: MAIN CONTENT COLUMN
		     ════════════════════════════════ -->
		<div class="trade-main-col">

			<!-- Main Image -->
			<?php if ( ! empty( $main_image['url'] ) && function_exists( 'swift_takeoffs_the_image' ) ) : ?>
				<div class="trade-main-image">
					<?php
					swift_takeoffs_the_image(
						$main_image,
						array(
							'alt'     => get_the_title(),
							'loading' => 'lazy',
							'sizes'   => '(max-width: 768px) 100vw, 800px',
							'width'   => $main_image['width'] ? $main_image['width'] : 800,
							'height'  => $main_image['height'] ? $main_image['height'] : 500,
						)
					);
					?>
				</div>
			<?php endif; ?>

<!-- Post Title Above Intro -->
<div class="single-post-title">
    <?php
    $words = explode( ' ', get_the_title() );
    $last  = array_pop( $words );
    echo esc_html( implode( ' ', $words ) ) . ' <span>' . esc_html( $last ) . '</span>';
    ?>
</div>

<!-- Intro Text -->
<?php if ( $intro_text ) : ?>
    <div class="trade-intro-text">
        <?php echo wp_kses_post( function_exists( 'wp_filter_content_tags' ) ? wp_filter_content_tags( $intro_text ) : $intro_text ); ?>
    </div>
<?php endif; ?>

			<!-- Cost Factors Section -->
			<?php if ( $cost_factors ) : ?>
				<div class="trade-cost-factors">
					<h2 class="trade-section-title">
						<?php esc_html_e( 'Cost Factors', 'swift-takeoffs' ); ?>
					</h2>
					<ul class="trade-factors-list">
						<?php foreach ( $cost_factors as $factor ) : ?>
							<li>
								<strong><?php echo esc_html( $factor['cost_title'] ); ?>:</strong>
								<?php echo wp_kses_post( $factor['cost_desc'] ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<!-- Takeoff Services Section -->
			<?php if ( $takeoff_text ) : ?>
				<div class="trade-takeoff-text">
					<h2 class="trade-section-title">
						<?php esc_html_e( 'Takeoff Services', 'swift-takeoffs' ); ?>
					</h2>
					<?php echo wp_kses_post( function_exists( 'wp_filter_content_tags' ) ? wp_filter_content_tags( $takeoff_text ) : $takeoff_text ); ?>
				</div>
			<?php endif; ?>

			<!-- Why Choose Section -->
			<?php if ( $why_choose_items ) : ?>
				<div class="trade-why-choose">
					<h2 class="trade-section-title">
						<?php
						printf(
							/* translators: %s: Site name */
							esc_html__( 'Why Choose %s?', 'swift-takeoffs' ),
							'<span>' . esc_html( get_bloginfo( 'name' ) ) . '</span>'
						);
						?>
					</h2>

					<div class="trade-why-layout">
						<!-- Why Choose List -->
						<ul class="trade-why-list">
							<?php foreach ( $why_choose_items as $item ) : ?>
								<li>
									<strong><?php echo esc_html( $item['why_title'] ); ?>:</strong>
									<?php echo wp_kses_post( $item['why_desc'] ); ?>
								</li>
							<?php endforeach; ?>
						</ul>

						<!-- Why Choose Image -->
						<?php if ( ! empty( $why_choose_image['url'] ) && function_exists( 'swift_takeoffs_the_image' ) ) : ?>
							<div class="trade-why-image">
								<?php
								swift_takeoffs_the_image(
									$why_choose_image,
									array(
										'alt'     => get_the_title(),
										'loading' => 'lazy',
										'sizes'   => '(max-width: 768px) 100vw, 260px',
										'width'   => $why_choose_image['width'] ? $why_choose_image['width'] : 400,
										'height'  => $why_choose_image['height'] ? $why_choose_image['height'] : 300,
									)
								);
								?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<!-- Request a Quote CTA -->
			<div class="trade-bottom-cta">
				<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-outline-rounded">
					<?php esc_html_e( 'Request a Quote Now', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>

		</div><!-- .trade-main-col -->


		<!-- ════════════════════════════════
		     RIGHT: SIDEBAR COLUMN
		     ════════════════════════════════ -->
		<aside class="trade-sidebar-col" role="complementary">

			<!-- Search Widget -->
			<div class="trade-sidebar-widget trade-search-widget">
				<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="trade-search-form">
					<input
						type="search"
						name="s"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Search....', 'swift-takeoffs' ); ?>"
						class="trade-search-input"
						aria-label="<?php esc_attr_e( 'Search', 'swift-takeoffs' ); ?>"
					>
					<input type="hidden" name="post_type" value="trade">
					<button type="submit" class="trade-search-btn" aria-label="<?php esc_attr_e( 'Submit search', 'swift-takeoffs' ); ?>">
						<i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
					</button>
				</form>
			</div>

			<!-- Popular Trades Widget (dynamic — WP_Query, max 6) -->
			<?php if ( $sidebar_trades ) : ?>
				<div class="trade-sidebar-widget trade-popular-widget">
					<h3 class="sidebar-widget-title">
						<?php esc_html_e( 'Popular Trades', 'swift-takeoffs' ); ?>
					</h3>
					<ul class="popular-trades-list">
						<?php foreach ( $sidebar_trades as $sidebar_trade ) :
							$is_current = ( $sidebar_trade->ID === get_the_ID() );
						?>
							<li class="<?php echo $is_current ? 'current-trade' : ''; ?>">
								<a href="<?php echo esc_url( get_permalink( $sidebar_trade->ID ) ); ?>">
									<i class="fa-solid fa-square-check" aria-hidden="true"></i>
									<?php echo esc_html( get_the_title( $sidebar_trade->ID ) ); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<!-- CTA Widget -->
			<div class="trade-sidebar-widget trade-cta-widget">
				<p class="cta-widget-heading">
					<?php esc_html_e( 'Experience The Construction Estimate with', 'swift-takeoffs' ); ?>
					<span><?php echo esc_html( get_bloginfo( 'name' ) ) ; ?></span>
				</p>
				<p class="cta-widget-time"><?php echo esc_html( $cta_text ); ?></p>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-primary cta-widget-btn">
					<?php esc_html_e( 'Contact Now', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>

		</aside><!-- .trade-sidebar-col -->

	</div><!-- .trade-single-container -->
</section>

<?php get_footer(); ?>
