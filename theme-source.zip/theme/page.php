<?php
/**
 * Generic Page Template
 * Used for generic WordPress pages that do not have a dedicated template.
 *
 * @package SwiftTakeoffs
 */

get_header();

// Generate the page banner from the page title
if ( have_posts() ) :
	the_post();
	swift_takeoffs_page_banner( get_the_title() );
	?>

	<!-- ===== PAGE CONTENT ===== -->
	<section class="page-content-sec">
		<div class="container container-column">
			<div class="page-content-inner">
				<?php the_content(); ?>
			</div>
		</div>
	</section>

<?php endif; ?>

<?php get_footer(); ?>
