<?php
/**
 * Front Page Template
 * Used when a static front page is set in Settings > Reading.
 *
 * @package SwiftTakeoffs
 */

get_header();
$theme_uri = get_template_directory_uri();
?>

	<!-- ===== HERO SECTION ===== -->
	<section class="hero">
		<div class="hero-bg-solid"></div>
		<div class="hero-bg-gradient"></div>
		<div class="hero-bg">
			<div class="grid-overlay"></div>
			<?php
			$hero_svg  = $theme_uri . '/assets/images/heroimage.svg';
			$hero_webp = get_template_directory() . '/assets/images/heroimage.webp';
			if ( file_exists( $hero_webp ) ) :
				?>
			<picture>
				<source srcset="<?php echo esc_url( $theme_uri . '/assets/images/heroimage.webp' ); ?>" type="image/webp">
				<img
					src="<?php echo esc_url( $hero_svg ); ?>"
					alt="<?php esc_attr_e( 'Construction estimating takeoff plans', 'swift-takeoffs' ); ?>"
					fetchpriority="high"
					loading="eager"
					decoding="async"
					width="926"
					height="674"
				>
			</picture>
			<?php else : ?>
			<img
				src="<?php echo esc_url( $hero_svg ); ?>"
				alt="<?php esc_attr_e( 'Precision Estimating', 'swift-takeoffs' ); ?>"
				fetchpriority="high"
				loading="eager"
				decoding="async"
				width="926"
				height="674"
			>
			<?php endif; ?>
		</div>
		<div class="container">
			<div class="hero-content">
				<h1>
					<?php esc_html_e( 'Precision', 'swift-takeoffs' ); ?>
					<span><?php esc_html_e( 'Estimating', 'swift-takeoffs' ); ?></span><br>
					<?php esc_html_e( 'Services For Seamless', 'swift-takeoffs' ); ?><br>
					<?php esc_html_e( 'Project Success', 'swift-takeoffs' ); ?>
				</h1>
				<p>
					<?php esc_html_e( 'At Swift Takeoffs, we deliver construction estimating services that keep your projects on time and within budget.', 'swift-takeoffs' ); ?>
				</p>
				<div class="hero-btns">
					<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-primary">
						<?php esc_html_e( 'Get a Free Quote', 'swift-takeoffs' ); ?>
						<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
					</a>
					<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-outline">
						<?php esc_html_e( 'Contact Us', 'swift-takeoffs' ); ?>
						<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
					</a>
				</div>
			</div>
		</div>
		<div class="hero-vector">
			<img src="<?php echo esc_url( $theme_uri . '/assets/images/Vector.svg' ); ?>" alt="" aria-hidden="true" loading="lazy" width="200" height="200">
		</div>
		<div class="hero-bottom-bar"></div>
	</section>

	<!-- ===== FEATURES SECTION ===== -->
	<section class="features">
		<div class="container flex-wrap">
			<div class="feature-card">
				<div class="feature-icon"><i class="fa-solid fa-certificate" aria-hidden="true"></i></div>
				<h3><?php esc_html_e( 'Registered', 'swift-takeoffs' ); ?></h3>
				<p><?php esc_html_e( 'We are a registered company in the USA, operating for the past 7 years.', 'swift-takeoffs' ); ?></p>
			</div>
			<div class="feature-card">
				<div class="feature-icon"><i class="fa-solid fa-bolt" aria-hidden="true"></i></div>
				<h3><?php esc_html_e( 'Fast Turnaround', 'swift-takeoffs' ); ?></h3>
				<p><?php esc_html_e( 'Our rapid turnaround ensures you have ample time before the bid deadline.', 'swift-takeoffs' ); ?></p>
			</div>
			<div class="feature-card">
				<div class="feature-icon"><i class="fa-solid fa-headset" aria-hidden="true"></i></div>
				<h3><?php esc_html_e( 'Technical Support', 'swift-takeoffs' ); ?></h3>
				<p><?php esc_html_e( 'Our team is fully equipped to address and resolve any inquiries you may have.', 'swift-takeoffs' ); ?></p>
			</div>
			<div class="feature-card">
				<div class="feature-icon"><i class="fa-solid fa-dollar-sign" aria-hidden="true"></i></div>
				<h3><?php esc_html_e( 'Accurate Pricing', 'swift-takeoffs' ); ?></h3>
				<p><?php esc_html_e( 'We consider current market volatility and price fluctuations to provide estimates.', 'swift-takeoffs' ); ?></p>
			</div>
		</div>
	</section>

	<!-- ===== ABOUT US SECTION ===== -->
	<section class="about">
		<div class="container">
			<div class="about-image-col">
				<div class="about-main-img">
					<img src="<?php echo esc_url( $theme_uri . '/assets/images/team-multi-ethnic-architects-designing-blueprint-plan.svg' ); ?>" alt="<?php esc_attr_e( 'Our Team', 'swift-takeoffs' ); ?>" loading="lazy" width="528" height="495">
				</div>
			</div>
			<div class="about-content-col">
				<span class="sub-title"><?php esc_html_e( 'About Us', 'swift-takeoffs' ); ?></span>
				<h2><?php esc_html_e( 'Excellence In Construction And Estimating', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Takeoff Services', 'swift-takeoffs' ); ?></span></h2>
				<p><?php esc_html_e( 'At Swift Takeoffs, we are passionate about providing unparalleled construction estimating and takeoff services that empower your projects to succeed. With over 7 years of industry experience, we combine precision, expertise, and cutting-edge technology to deliver accurate cost estimates and comprehensive takeoff solutions tailored to your unique needs.', 'swift-takeoffs' ); ?></p>
				<div class="stats-row">
					<div class="stat-item">
						<h4>1200<span>+</span></h4>
						<p><?php esc_html_e( 'Project Completed', 'swift-takeoffs' ); ?></p>
					</div>
					<div class="stat-item">
						<h4>417<span>+</span></h4>
						<p><?php esc_html_e( 'Happy Clients', 'swift-takeoffs' ); ?></p>
					</div>
					<div class="stat-item">
						<h4>50<span>+</span></h4>
						<p><?php esc_html_e( 'Highly Qualified Estimators', 'swift-takeoffs' ); ?></p>
					</div>
					<div class="stat-item">
						<h4>07<span>+</span></h4>
						<p><?php esc_html_e( 'Years Of Experience', 'swift-takeoffs' ); ?></p>
					</div>
				</div>
				<a href="<?php echo esc_url( home_url( '/about/' ) ); ?>" class="btn-outline-rounded">
					<?php esc_html_e( 'Learn More About us', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>
		</div>
	</section>

	<!-- ===== SERVICES SECTION ===== -->
	<section class="services">
		<div class="container container-column">
			<div class="services-header">
				<h2><?php esc_html_e( 'Our Swift Takeoffs', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Services', 'swift-takeoffs' ); ?></span></h2>
				<p><?php esc_html_e( 'Explore our professional construction estimating and material takeoff services designed to improve bid accuracy, reduce costs, and support successful projects.', 'swift-takeoffs' ); ?></p>
			</div>
			<div class="services-grid">
				<?php
				$home_services = function_exists( 'swift_takeoffs_get_all_services' )
					? swift_takeoffs_get_all_services( 8 )
					: array();

				$service_icons = array(
					'gc-estimating-services'              => 'fa-helmet-safety',
					'general-contractor-estimating'       => 'fa-helmet-safety',
					'subcontractor-estimating-services'   => 'fa-people-group',
					'cost-estimating-services'            => 'fa-calculator',
					'material-takeoff-services'           => 'fa-clipboard-list',
					'commercial-estimating-services'      => 'fa-building',
					'residential-estimating-services'     => 'fa-house',
					'preliminary-estimating-services'     => 'fa-file-lines',
					'industrial-estimating-services'      => 'fa-industry',
				);

				if ( $home_services ) :
					foreach ( $home_services as $svc ) :
						$slug = $svc->post_name;
						$icon = isset( $service_icons[ $slug ] ) ? $service_icons[ $slug ] : 'fa-clipboard-check';
						$desc = $svc->post_excerpt ? $svc->post_excerpt : wp_strip_all_tags( $svc->post_content );
						$desc = wp_trim_words( $desc, 28, '…' );
						$title = get_the_title( $svc );
						// Split last word for blue span styling when title ends with "Services" / "Service"
						$title_main = $title;
						$title_span = '';
						if ( preg_match( '/^(.*)\s+(Services?)$/i', $title, $m ) ) {
							$title_main = trim( $m[1] );
							$title_span = $m[2];
						}
						?>
						<div class="service-card">
							<div class="service-icon"><i class="fa-solid <?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i></div>
							<h3>
								<?php echo esc_html( $title_main ); ?>
								<?php if ( $title_span ) : ?>
									<span><?php echo esc_html( $title_span ); ?></span>
								<?php endif; ?>
							</h3>
							<p>
								<?php echo esc_html( $desc ); ?>
								<a href="<?php echo esc_url( get_permalink( $svc ) ); ?>" class="view-more"><?php esc_html_e( 'View More', 'swift-takeoffs' ); ?></a>
							</p>
						</div>
						<?php
					endforeach;
				else :
					?>
					<p><?php esc_html_e( 'Services coming soon.', 'swift-takeoffs' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<!-- ===== CTA BANNER SECTION ===== -->
	<section class="cta-banner-sec">
		<div class="container">
			<div class="cta-banner">
				<div class="cta-content">
					<h2><?php esc_html_e( 'Are You Ready To Take The Next Step?', 'swift-takeoffs' ); ?></h2>
					<p><?php esc_html_e( 'Contact Us Today To Get Started On Your Construction Projects And Experience The Difference Of Working With Swift Takeoffs.', 'swift-takeoffs' ); ?></p>
					<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-white">
						<?php esc_html_e( 'Request now for Bid', 'swift-takeoffs' ); ?>
						<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
					</a>
				</div>
				<div class="cta-image">
					<img src="<?php echo esc_url( $theme_uri . '/assets/images/laptop.svg' ); ?>" alt="<?php esc_attr_e( 'Laptop', 'swift-takeoffs' ); ?>" loading="lazy" width="480" height="350">
				</div>
			</div>
		</div>
	</section>

	<!-- ===== WHY HIRE SECTION ===== -->
	<section class="why-hire">
		<div class="container">
			<div class="why-hire-content">
				<h2 class="section-title">
					<?php esc_html_e( 'Why Hire', 'swift-takeoffs' ); ?>
					<span><?php esc_html_e( 'Swift Takeoffs', 'swift-takeoffs' ); ?></span>?
				</h2>
				<p class="section-desc"><?php esc_html_e( 'At Swift Takeoffs, we understand that accurate, reliable cost estimates are the foundation of any successful construction project. Whether you\'re managing a large-scale commercial development or a residential build, our expert team is here to ensure that your project stays on track, on budget, and within scope.', 'swift-takeoffs' ); ?></p>
				<ul class="why-hire-list">
					<?php
					$reasons = array(
						array( 'title' => 'Accurate Estimates',             'desc' => 'Advanced tools ensure precise, data-driven estimates that keep your project on budget.' ),
						array( 'title' => 'Expertise Across Trades',        'desc' => 'Extensive experience in multiple construction trades for tailored, reliable estimates.' ),
						array( 'title' => 'Cost-Effective Solutions',       'desc' => 'We help you save costs by reducing waste and optimizing resource allocation.' ),
						array( 'title' => 'Transparent And Collaborative',  'desc' => 'Clear communication and easy-to-understand reports for full project alignment.' ),
					);
					foreach ( $reasons as $reason ) : ?>
						<li>
							<div class="list-icon"><i class="fa-solid fa-check" aria-hidden="true"></i></div>
							<div class="list-text">
								<h3><?php echo esc_html( $reason['title'] ); ?></h3>
								<p><?php echo esc_html( $reason['desc'] ); ?></p>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-primary">
					<?php esc_html_e( 'Contact Now', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>
			<div class="why-hire-media">
				<img
					src="<?php echo esc_url( $theme_uri . '/assets/images/group-smiling-engineers.svg' ); ?>"
					alt="<?php esc_attr_e( 'Swift Takeoffs engineering team', 'swift-takeoffs' ); ?>"
					loading="lazy"
					width="560"
					height="400"
					decoding="async"
				>
			</div>
		</div>
	</section>

	<!-- ===== SOFTWARE USE SECTION ===== -->
	<section class="software-use">
		<div class="section-vector right software-vector">
			<img src="<?php echo esc_url( $theme_uri . '/assets/images/Vector.svg' ); ?>" alt="" aria-hidden="true" loading="lazy" width="200" height="200">
		</div>
		<div class="container container-column">
			<div class="software-header">
				<h2><?php esc_html_e( "Software's", 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Swift Takeoffs', 'swift-takeoffs' ); ?></span> <?php esc_html_e( 'Use', 'swift-takeoffs' ); ?></h2>
			</div>
			<div class="software-container">
				<div class="logo-row">
					<?php
					$software = array( 'planswift', 'classic', 'xactimate', 'rsmean', 'bluebeam', 'proest', 'costx', 'kubla' );
					$software_names = array( 'PlanSwift', 'On-Screen Takeoff', 'Xactimate', 'RSMeans', 'Bluebeam', 'ProEst', 'CostX', 'Kubla' );
					// Output twice for infinite CSS scroll animation
					for ( $i = 0; $i < 2; $i++ ) :
						foreach ( $software as $idx => $slug ) : ?>
							<img src="<?php echo esc_url( $theme_uri . '/assets/images/' . $slug . '.svg' ); ?>" alt="<?php echo esc_attr( $software_names[ $idx ] ); ?>" class="software-logo" loading="lazy" width="120" height="45">
						<?php endforeach;
					endfor; ?>
				</div>
			</div>
		</div>
	</section>



	<!-- ===== SECONDARY CTA BANNER ===== -->
	<section class="cta-banner-slim-sec">
		<div class="container">
			<div class="cta-banner-slim">
				<div class="cta-slim-content">
					<h2><?php esc_html_e( 'Struggling To Stay Ahead With Your Bids?', 'swift-takeoffs' ); ?></h2>
					<p><?php esc_html_e( 'Leave The Stress Of Managing Bids Behind! With Swift Takeoffs, Our Precise And Reliable Services Empower You To Win More Projects Effortlessly', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="cta-slim-action">
					<img src="<?php echo esc_url( $theme_uri . '/assets/images/Arrow 1.svg' ); ?>" alt="" class="cta-arrow-svg" aria-hidden="true" loading="lazy" width="80" height="40">
					<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-white">
						<?php esc_html_e( 'Get A Free Quote', 'swift-takeoffs' ); ?>
						<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
					</a>
				</div>
			</div>
		</div>
	</section>

	<!-- ===== HOW TO GET STARTED SECTION ===== -->
	<section class="get-started">
		<div class="container container-column">
			<div class="get-started-header">
				<h2><?php esc_html_e( 'How To', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Get Started', 'swift-takeoffs' ); ?></span> <?php esc_html_e( 'With Us', 'swift-takeoffs' ); ?></h2>
				<p><?php esc_html_e( 'Share your project plans, and we\'ll handle the rest—from providing a detailed quote to delivering precise cost estimates in record time.', 'swift-takeoffs' ); ?></p>
			</div>
			<div class="get-started-steps">
				<div class="step-card">
					<div class="step-icon"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i></div>
					<h3><?php esc_html_e( 'Send Us Your Plans', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Upload your plans here or email them to info@swifttakeoffs.com whichever is more convenient for you. Be sure to include details about your project and scope of work.', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="step-card">
					<div class="step-icon"><i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i></div>
					<h3><?php esc_html_e( 'Receive a Quote', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'We\'ll provide you with a detailed quote for our services before we begin. Since every project is unique, we carefully review each situation, considering factors such as project scope, complexity, trades involved.', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="step-card">
					<div class="step-icon"><i class="fa-solid fa-calculator" aria-hidden="true"></i></div>
					<h3><?php esc_html_e( 'Receive Your Cost Estimate', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Our team will perform the takeoff and estimate for your project. You\'ll receive both a PDF and an Excel file of your estimate.', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="step-connector connector-1" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></div>
				<div class="step-connector connector-2" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></div>
			</div>
		</div>
	</section>

	<!-- ===== QUOTE FORM SECTION ===== -->
	<?php get_template_part( 'template-parts/form-free-quote' ); ?>

	<!-- ===== FAQ SECTION ===== -->
	<section class="faq-sec">
		<div class="container container-column">
			<div class="faq-header">
				<h2><?php esc_html_e( 'Your', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Constructed', 'swift-takeoffs' ); ?></span> <?php esc_html_e( 'Question Answers', 'swift-takeoffs' ); ?></h2>
				<p><?php esc_html_e( 'Find answers to all your construction estimating queries in one place. Our comprehensive FAQ section addresses your concerns with clarity and detail.', 'swift-takeoffs' ); ?></p>
			</div>
			<div class="faq-accordion" id="faqAccordion">
				<?php
				$faqs = array(
					array(
						'q' => 'What Do Your Material Takeoffs Include?',
						'a' => 'Our material takeoffs provide a comprehensive breakdown of all necessary materials for your project. This includes detailed quantities, specifications, and descriptions for items such as concrete, lumber, steel, drywall, and other essential materials.',
					),
					array(
						'q' => 'What Do You Need In Order To Do A Takeoff Or Estimate?',
						'a' => 'To provide an accurate estimate, we typically require your project blueprints (plans), specifications, and any specific trade instructions you may have. Digital formats like PDF are preferred.',
					),
					array(
						'q' => 'Do You Charge For Reviewing Plans Before Placing An Order?',
						'a' => 'No, we offer a free initial plan review to understand the scope of your project and provide a detailed quote for our estimating services.',
					),
					array(
						'q' => 'What Is Your Average Turnaround Time?',
						'a' => 'Our standard turnaround time is 24 to 48 hours for most projects. Larger or more complex projects may take slightly longer, which we will specify in your quote.',
					),
					array(
						'q' => 'Do You Offer Pre-Bid And Post-Bid Meetings To Discuss The Projects?',
						'a' => 'Yes, we value collaboration. We are available for meetings to discuss the details of our takeoffs and help you prepare for your final bid submission.',
					),
				);

				// Generate JSON-LD for FAQ Schema
				$schema_faqs = array();
				foreach ( $faqs as $schema_faq ) {
					$schema_faqs[] = array(
						'@type'          => 'Question',
						'name'           => $schema_faq['q'],
						'acceptedAnswer' => array(
							'@type' => 'Answer',
							'text'  => $schema_faq['a']
						)
					);
				}
				$faq_schema = array(
					'@context'   => 'https://schema.org',
					'@type'      => 'FAQPage',
					'mainEntity' => $schema_faqs
				);
				echo '<script type="application/ld+json">' . wp_json_encode( $faq_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';

				foreach ( $faqs as $index => $faq ) : ?>
					<div class="faq-item <?php echo $index === 0 ? 'active' : ''; ?>">
						<div class="faq-question">
							<span><?php echo esc_html( $faq['q'] ); ?></span>
							<i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
						</div>
						<div class="faq-answer">
							<p><?php echo esc_html( $faq['a'] ); ?></p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="faq-footer">
				<p>
					<?php esc_html_e( 'If You still have question about us or our services?', 'swift-takeoffs' ); ?>
					<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'swift-takeoffs' ); ?></a>
					<?php esc_html_e( 'we will help you to get started with confidence.', 'swift-takeoffs' ); ?>
				</p>
			</div>
		</div>
	</section>

	<!-- ===== LATEST BLOGS SECTION (DYNAMIC) ===== -->
	<section class="blogs-sec">
		<div class="container container-column">
			<div class="blogs-header">
				<div class="blogs-title-area">
					<h2><?php esc_html_e( 'Check Our', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Latest Blogs', 'swift-takeoffs' ); ?></span></h2>
					<p><?php esc_html_e( 'Stay informed with our latest blogs, covering industry insights, tips, and trends in construction estimating. Discover valuable knowledge to elevate your projects!', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="blogs-action">
					<a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="btn-outline">
						<?php esc_html_e( 'Explore All Blogs', 'swift-takeoffs' ); ?>
						<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
					</a>
				</div>
			</div>

			<div class="blogs-grid">
				<?php
				// Query the latest 3 blog posts dynamically
				$blog_query = new WP_Query(
					array(
						'post_type'      => 'post',
						'post_status'    => 'publish',
						'posts_per_page' => 3,
						'orderby'        => 'date',
						'order'          => 'DESC',
					)
				);

				if ( $blog_query->have_posts() ) :
					while ( $blog_query->have_posts() ) :
						$blog_query->the_post();
						get_template_part( 'template-parts/card', 'blog' );
					endwhile;
					wp_reset_postdata();
				else : ?>
					<p class="no-posts"><?php esc_html_e( 'No blog posts found. Start publishing posts to show them here.', 'swift-takeoffs' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</section>

<?php get_footer(); ?>
