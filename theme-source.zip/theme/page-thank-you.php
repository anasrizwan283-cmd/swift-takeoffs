<?php
/**
 * Template Name: Thank You
 * Description: Generic post-submit thank-you page (noindex). Used by landing and campaign forms.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$from = isset( $_GET['from'] ) ? sanitize_title( wp_unslash( $_GET['from'] ) ) : '';
$home = home_url( '/' );

if ( 'drywall-estimating' === $from ) {
	$back_url   = home_url( '/drywall-estimating/' );
	$back_label = __( 'Back to Drywall Estimating', 'swift-takeoffs' );
} elseif ( 0 === strpos( $from, 'swift-takeoffs-landing' ) ) {
	$landing = get_page_by_path( 'swift-takeoffs' );
	if ( ! $landing ) {
		$landing_pages = get_posts(
			array(
				'post_type'      => 'page',
				'meta_key'       => '_wp_page_template',
				'meta_value'     => 'page-swift-takeoffs-landing.php',
				'posts_per_page' => 1,
				'post_status'    => 'publish',
			)
		);
		$landing = $landing_pages ? $landing_pages[0] : null;
	}
	$back_url   = $landing ? get_permalink( $landing ) : $home;
	$back_label = __( 'Back to landing page', 'swift-takeoffs' );
} else {
	$back_url   = $home;
	$back_label = __( 'Back to home', 'swift-takeoffs' );
}

get_header();
?>
<style>
.st-thanks-page {
	--st-blue: #0163be;
	--st-navy: #10233d;
	--st-muted: #65758b;
	--st-line: #dfe7f0;
	--st-pale: #f5f8fc;
	background:
		radial-gradient(ellipse 80% 60% at 50% -10%, rgba(1, 99, 190, 0.12), transparent 55%),
		linear-gradient(180deg, #f8fbff 0%, #ffffff 45%, #f5f8fc 100%);
	min-height: 62vh;
	display: flex;
	align-items: center;
	padding: 72px 20px;
}
.st-thanks-page__inner {
	width: min(560px, 100%);
	margin: 0 auto;
	text-align: center;
}
.st-thanks-page__icon {
	width: 72px;
	height: 72px;
	margin: 0 auto 22px;
	border-radius: 50%;
	background: #e8f3fc;
	color: var(--st-blue);
	display: grid;
	place-items: center;
}
.st-thanks-page__icon svg {
	display: block;
}
.st-thanks-page__eyebrow {
	margin: 0 0 10px;
	font-size: 0.8rem;
	font-weight: 700;
	letter-spacing: 0.14em;
	text-transform: uppercase;
	color: var(--st-blue);
}
.st-thanks-page h1 {
	margin: 0 0 14px;
	font-size: clamp(1.75rem, 4vw, 2.5rem);
	line-height: 1.15;
	letter-spacing: -0.03em;
	color: var(--st-navy);
}
.st-thanks-page__lead {
	margin: 0 auto 28px;
	max-width: 42ch;
	font-size: 1.05rem;
	line-height: 1.65;
	color: var(--st-muted);
}
.st-thanks-page__actions {
	display: flex;
	flex-wrap: wrap;
	gap: 12px;
	justify-content: center;
}
.st-thanks-page__btn {
	display: inline-flex;
	align-items: center;
	gap: 8px;
	padding: 14px 22px;
	border-radius: 999px;
	font-weight: 600;
	font-size: 0.95rem;
	text-decoration: none;
	transition: background 0.2s ease, color 0.2s ease, border-color 0.2s ease;
}
.st-thanks-page__btn--primary {
	background: var(--st-blue);
	color: #fff;
}
.st-thanks-page__btn--primary:hover {
	background: #004b91;
	color: #fff;
}
.st-thanks-page__btn--ghost {
	background: #fff;
	color: var(--st-navy);
	border: 1px solid var(--st-line);
}
.st-thanks-page__btn--ghost:hover {
	border-color: var(--st-blue);
	color: var(--st-blue);
}
</style>
<div class="st-thanks-page">
	<div class="st-thanks-page__inner">
		<div class="st-thanks-page__icon" aria-hidden="true">
			<svg viewBox="0 0 52 52" width="40" height="40" fill="none">
				<circle cx="26" cy="26" r="24" stroke="currentColor" stroke-width="3"/>
				<path d="M14.1 27.2l7.1 7.2 16.7-16.8" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
			</svg>
		</div>
		<p class="st-thanks-page__eyebrow"><?php esc_html_e( 'Request received', 'swift-takeoffs' ); ?></p>
		<h1><?php esc_html_e( 'Thank you — we got your request.', 'swift-takeoffs' ); ?></h1>
		<p class="st-thanks-page__lead">
			<?php esc_html_e( 'Our estimating team will follow up shortly. Keep your plans handy so we can move fast.', 'swift-takeoffs' ); ?>
		</p>
		<div class="st-thanks-page__actions">
			<a class="st-thanks-page__btn st-thanks-page__btn--primary" href="<?php echo esc_url( $back_url ); ?>">
				<?php echo esc_html( $back_label ); ?>
				<span aria-hidden="true">→</span>
			</a>
			<?php if ( $back_url !== $home ) : ?>
				<a class="st-thanks-page__btn st-thanks-page__btn--ghost" href="<?php echo esc_url( $home ); ?>">
					<?php esc_html_e( 'Go to homepage', 'swift-takeoffs' ); ?>
				</a>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php
get_footer();
