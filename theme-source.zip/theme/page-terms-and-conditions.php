<?php
/**
 * Template Name: Terms and Conditions
 * Dedicated Website Policies page — content lives in this template (not the WP editor).
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

swift_takeoffs_page_banner( __( 'Terms and Conditions', 'swift-takeoffs' ), 'terms-banner' );
?>

<section class="privacy-page" aria-labelledby="terms-heading">
	<div class="container container-column">
		<div class="privacy-layout">

			<nav class="privacy-toc" id="termsToc" aria-label="<?php esc_attr_e( 'Terms and Conditions sections', 'swift-takeoffs' ); ?>">
				<button type="button" class="privacy-toc__toggle" aria-expanded="false" aria-controls="termsTocList">
					<span class="privacy-toc__toggle-label"><?php esc_html_e( 'On this page', 'swift-takeoffs' ); ?></span>
					<span class="privacy-toc__current"><?php esc_html_e( 'Services agreement', 'swift-takeoffs' ); ?></span>
					<i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
				</button>
				<p class="privacy-toc__heading"><?php esc_html_e( 'On this page', 'swift-takeoffs' ); ?></p>
				<ul class="privacy-toc__list" id="termsTocList">
					<li><a href="#services-agreement"><?php esc_html_e( 'Services agreement', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#payment-terms"><?php esc_html_e( 'Payment terms', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#refund-policy"><?php esc_html_e( 'Refund policy', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#confidentiality"><?php esc_html_e( 'Confidentiality', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#estimates-disclaimer"><?php esc_html_e( 'Estimates disclaimer', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#limitation-of-liability"><?php esc_html_e( 'Limitation of liability', 'swift-takeoffs' ); ?></a></li>
				</ul>
			</nav>

			<article class="privacy-doc">

				<header class="privacy-doc__intro">
					<p class="privacy-doc__kicker"><?php esc_html_e( 'Swift Takeoffs Inc.', 'swift-takeoffs' ); ?></p>
					<h2 id="terms-heading"><?php esc_html_e( 'Terms & Conditions', 'swift-takeoffs' ); ?></h2>
					<p class="privacy-doc__updated">
						<i class="fa-regular fa-file-lines" aria-hidden="true"></i>
						<?php esc_html_e( 'Website Policies', 'swift-takeoffs' ); ?>
					</p>
					<div class="privacy-doc__lede">
						<p><?php esc_html_e( 'These terms govern use of the Swift Takeoffs Inc. website and estimating services. Please review them before submitting a project or making a payment.', 'swift-takeoffs' ); ?></p>
					</div>
				</header>

				<section class="privacy-section" id="services-agreement">
					<h3><?php esc_html_e( 'Services Agreement', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'The standard turnaround time for estimates is typically 2–3 business days after acceptance of the quotation and receipt of payment. Delivery times may vary depending on the project scope, complexity, volume of drawings, and specific client requirements. In certain cases, additional time may be required to ensure accuracy and completeness.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="payment-terms">
					<h3><?php esc_html_e( 'Payment Terms', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. utilizes secure online payment platforms to protect the privacy and security of our clients’ financial information. Payments may be made via Credit Card, Debit Card, ACH Transfer, Wire Transfer, PayPal, or other approved payment methods.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'Upon receiving project plans, specifications, and relevant documentation, our team will review the scope of work and issue a formal quotation along with an invoice and estimated delivery date. Work will commence once payment has been received and confirmed.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="refund-policy">
					<h3><?php esc_html_e( 'Refund Policy', 'swift-takeoffs' ); ?></h3>
					<p class="privacy-inline-note"><strong><?php esc_html_e( 'Due to the professional nature of our estimating services, all sales are considered final once work has commenced.', 'swift-takeoffs' ); ?></strong></p>
					<ul class="privacy-list">
						<li><?php esc_html_e( 'Clients may request cancellation and receive a full refund within 2 hours of payment, provided that work has not yet started.', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Once the estimating process has begun, no refunds will be issued.', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'No refunds will be provided after delivery of the completed estimate, regardless of whether the estimate is used for bidding or project execution.', 'swift-takeoffs' ); ?></li>
					</ul>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. shall not be held liable for missed bid submissions, bid deadlines, or lost business opportunities resulting from delays caused by client-side factors, incomplete information, unforeseen circumstances, or any other reason beyond our reasonable control.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="confidentiality">
					<h3><?php esc_html_e( 'Confidentiality & Non-Disclosure', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. respects the confidentiality of client information. Upon request, we are willing to execute a mutually agreed Non-Disclosure Agreement (NDA) prior to project commencement.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'Unless otherwise specified through a signed NDA, Swift Takeoffs Inc. reserves the right to reference completed projects for marketing and portfolio purposes, including but not limited to:', 'swift-takeoffs' ); ?></p>
					<ul class="privacy-list privacy-list--cols">
						<li><?php esc_html_e( 'Client testimonials', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Company names and logos', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Project names and descriptions', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Sample takeoffs and estimates', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Drawings and plans (where permitted)', 'swift-takeoffs' ); ?></li>
					</ul>
					<p><?php esc_html_e( 'No sensitive or proprietary information will be disclosed without prior authorization.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="estimates-disclaimer">
					<h3><?php esc_html_e( 'Estimates Disclaimer', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'All estimates, takeoffs, and cost analyses provided by Swift Takeoffs Inc. are intended solely as professional budgeting and bidding tools. They should be considered guidelines and not final project pricing.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'Material, labor, equipment, subcontractor, and market pricing are subject to change based on location, supplier availability, economic conditions, project schedules, and contractor-specific factors. While we utilize industry-recognized pricing databases and current market information whenever applicable, actual project costs may vary.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. does not provide warranties, guarantees, bonding assurances, insurance coverage, or financial guarantees regarding project costs, bid outcomes, profitability, or contract awards.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'We remain committed to supporting our clients and are available to review estimates, answer questions, provide clarifications, and make reasonable revisions when necessary to assist with project pricing and bidding decisions.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="limitation-of-liability">
					<h3><?php esc_html_e( 'Limitation of Liability', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Under no circumstances shall Swift Takeoffs Inc. be liable for indirect, incidental, consequential, special, or punitive damages arising from the use of our estimates, reports, or consulting services. The client’s use of our services constitutes acceptance of these terms and acknowledgment that final pricing and bidding decisions remain the sole responsibility of the client.', 'swift-takeoffs' ); ?></p>
				</section>

			</article>
		</div>
	</div>
</section>

<?php
get_footer();
