<?php
/**
 * Template Name: About Us
 * Template for the About Us page.
 *
 * @package SwiftTakeoffs
 */

get_header();
$theme_uri = get_template_directory_uri();
swift_takeoffs_page_banner( __( 'About Us', 'swift-takeoffs' ), 'about-banner' );
?>

	<!-- ===== ABOUT PARTNER SECTION ===== -->
	<section class="about-partner">
		<div class="about-partner-vector">
			<img src="<?php echo esc_url( $theme_uri . '/assets/images/Vector.svg' ); ?>" alt="" aria-hidden="true" loading="lazy" width="200" height="200">
		</div>
		<div class="container flex-row">
			<div class="about-partner-image">
				<img src="<?php echo esc_url( $theme_uri . '/assets/images/group-architect-discussing-layout-plan-blueprint-office.svg' ); ?>" alt="<?php esc_attr_e( 'Construction Experts', 'swift-takeoffs' ); ?>" fetchpriority="high" loading="eager" width="600" height="450">
			</div>
			<div class="about-partner-content">
				<h2><?php esc_html_e( 'About Swift Takeoffs — your trusted partner in construction', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'estimating', 'swift-takeoffs' ); ?></span></h2>
				<p><?php esc_html_e( 'About Swift Takeoffs: we combine precision, expertise, and takeoff technology to help your projects succeed. From planning to completion, we support your vision every step of the way.', 'swift-takeoffs' ); ?></p>
				<div class="feature-grid">
					<?php
					$features = array(
						'Fast Turnaround Times', 'Accurate Material Estimates',
						'On-Time Project Delivery', 'Reduce Material Waste',
						'Budget-Friendly Solutions', 'Comprehensive Data Analysis',
						'Your All-In-One Partner', 'Expert Support and Guidance',
					);
					foreach ( $features as $feature ) : ?>
						<div class="feature-item">
							<i class="fa-solid fa-square-check" aria-hidden="true"></i>
							<span><?php echo esc_html( $feature ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-pill">
					<?php esc_html_e( 'Contact us now and get 30% off', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>
		</div>
	</section>

	<!-- ===== MILESTONES SECTION ===== -->
	<section class="milestones">
		<div class="milestones-vector">
			<img src="<?php echo esc_url( $theme_uri . '/assets/images/Vector.svg' ); ?>" alt="" aria-hidden="true" loading="lazy" width="200" height="200">
		</div>
		<div class="container container-column">
			<div class="milestones-header">
				<h2><?php esc_html_e( 'Milestones And', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Achievements', 'swift-takeoffs' ); ?></span></h2>
				<p><?php esc_html_e( "At Swift Takeoffs, we're proud of the journey that has shaped us into a trusted name in construction cost estimation. Each milestone reflects our commitment to excellence.", 'swift-takeoffs' ); ?></p>
			</div>
			<div class="milestones-grid">
				<?php
				$milestones = array(
					array( 'icon' => 'fa-trophy',           'style' => 'card-up',   'title' => '98% Bid-Winning Rate',         'desc' => 'Our clients consistently secure project approvals thanks to the accuracy and efficiency of our estimates.' ),
					array( 'icon' => 'fa-circle-check',     'style' => 'card-down', 'title' => 'Hundreds Of Projects Done',    'desc' => 'From residential to commercial, industrial, and civil projects, we provide tailored solutions to meet the unique needs of each project.' ),
					array( 'icon' => 'fa-desktop',          'style' => 'card-up',   'title' => 'Advanced Technology',          'desc' => 'We leverage cutting-edge software tools like PlanSwift, Bluebeam, and CostX to deliver state-of-the-art estimating solutions.' ),
					array( 'icon' => 'fa-handshake-angle',  'style' => 'card-down', 'title' => 'Trusted By Clients Nationwide','desc' => 'Our reputation for precision and reliability has earned us the trust of clients across the country.' ),
				);
				foreach ( $milestones as $milestone ) : ?>
					<div class="milestone-card <?php echo esc_attr( $milestone['style'] ); ?>">
						<div class="milestone-icon">
							<i class="fa-solid <?php echo esc_attr( $milestone['icon'] ); ?>" aria-hidden="true"></i>
						</div>
						<h3><?php echo esc_html( $milestone['title'] ); ?></h3>
						<p><?php echo esc_html( $milestone['desc'] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- ===== WHY CHOOSE US SECTION ===== -->
	<section class="why-choose-about">
		<div class="container flex-row">
			<div class="why-choose-content">
				<h2><?php esc_html_e( 'Why', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Choose', 'swift-takeoffs' ); ?></span> <?php esc_html_e( 'Us?', 'swift-takeoffs' ); ?></h2>
				<p><?php esc_html_e( "At Swift Takeoffs, we don't just provide cost estimates—we build strong, lasting partnerships that set you up for success. Here's why we are the right choice for your next construction project:", 'swift-takeoffs' ); ?></p>
				<ul class="why-choose-list">
					<?php
					$reasons = array(
						array( 'title' => 'Precision-First Approach',             'desc' => 'From material takeoffs to labor costs, our attention to detail ensures that every estimate is as accurate.' ),
						array( 'title' => 'Tailored Solutions For Every Project',  'desc' => 'We treat each one with the personalized attention it deserves. Whether it\'s a small residential build or a large-scale commercial project.' ),
						array( 'title' => 'Proactive Risk Mitigation',             'desc' => 'Our team proactively identifies potential risks—be it material shortages, design conflicts, or scope uncertainties.' ),
						array( 'title' => 'Technology-Driven Accuracy',            'desc' => 'Clear communication and easy-to-understand reports for full project alignment.' ),
					);
					foreach ( $reasons as $reason ) : ?>
						<li>
							<i class="fa-solid fa-square-check" aria-hidden="true"></i>
							<div class="list-item-content">
								<h4><?php echo esc_html( $reason['title'] ); ?></h4>
								<p><?php echo esc_html( $reason['desc'] ); ?></p>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
				<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-outline-pill">
					<?php esc_html_e( 'Get a free quote', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>
			<div class="why-choose-image">
				<img src="<?php echo esc_url( $theme_uri . '/assets/images/laptop.svg' ); ?>" alt="<?php esc_attr_e( 'Construction Planning Laptop', 'swift-takeoffs' ); ?>" loading="lazy" width="480" height="350">
			</div>
		</div>
	</section>

	<!-- ===== CALL ACTION BANNER ===== -->
	<section class="call-action-banner">
		<div class="banner-circle banner-circle-1"></div>
		<div class="banner-circle banner-circle-2"></div>
		<div class="container container-column">
			<h2><?php esc_html_e( 'Call Us Today For A Quick Quote', 'swift-takeoffs' ); ?></h2>
			<div class="phone-number">
				<i class="fa-solid fa-phone" aria-hidden="true"></i>
				<span><?php echo esc_html( get_theme_mod( 'swift_phone', '678-825-6967' ) ); ?></span>
			</div>
			<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-white-pill">
				<?php esc_html_e( 'Contact us Now', 'swift-takeoffs' ); ?>
				<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
			</a>
		</div>
	</section>

	<!-- ===== TESTIMONIALS SECTION ===== -->
	<section class="testimonials-about">
		<div class="container container-column">
			<div class="section-header">
				<h2><?php esc_html_e( 'Feedback From', 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'Our Clients', 'swift-takeoffs' ); ?></span></h2>
			</div>
			<div class="testimonials-slider-wrapper">
				<button class="slider-arrow arrow-left" id="prevTestimonial" aria-label="<?php esc_attr_e( 'Previous testimonial', 'swift-takeoffs' ); ?>">
					<i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
				</button>
				<div class="testimonials-viewport">
					<div class="testimonials-track" id="testimonialTrack">
						<?php
						$testimonial_query = new WP_Query( array(
							'post_type'      => 'testimonial',
							'posts_per_page' => -1,
							'post_status'    => 'publish',
						) );

						$testimonials_data = array();

						if ( $testimonial_query->have_posts() ) {
							while ( $testimonial_query->have_posts() ) {
								$testimonial_query->the_post();
								$testimonials_data[] = array(
									'name'  => get_the_title(),
									'date'  => get_the_date( 'm/d/y' ),
									'img'   => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ) : esc_url( $theme_uri . '/assets/images/group-smiling-engineers.svg' ),
									'quote' => get_the_content(),
								);
							}
							wp_reset_postdata();
						} else {
							// Fallback to static data
							$testimonials_data = array(
								array( 'name' => 'Saara D',  'date' => '08/10/24', 'img' => esc_url( $theme_uri . '/assets/images/engineer-builder-woman-uniform-waistcoat-orange-protective-helmet-hold-business-layout-plan-paper-sitting-pavement.svg' ), 'quote' => 'Lorem Ipsum Dolor Sit Amet Consect Bibendum Nulla Neque Aliquet Consec Orci Cursus Pretium Ornare Mi. Diam Suspendisse Morbi Aliquam Laoreet Nisi Quam Ut Dis. Augue Arcu Gravida Ac In Varius Arcu.' ),
								array( 'name' => 'John K.',  'date' => '08/10/24', 'img' => esc_url( $theme_uri . '/assets/images/group-smiling-engineers.svg' ), 'quote' => 'Lorem Ipsum Dolor Sit Amet Consect Bibendum Nulla Neque Aliquet Consec Orci Cursus Pretium Ornare Mi. Diam Suspendisse Morbi Aliquam Laoreet Nisi Quam Ut Dis. Augue Arcu Gravida Ac In Varius Arcu.' ),
								array( 'name' => 'Anaika',   'date' => '08/10/24', 'img' => esc_url( $theme_uri . '/assets/images/team-multi-ethnic-architects-designing-blueprint-plan.svg' ), 'quote' => 'Lorem Ipsum Dolor Sit Amet Consect Bibendum Nulla Neque Aliquet Consec Orci Cursus Pretium Ornare Mi. Diam Suspendisse Morbi Aliquam Laoreet Nisi Quam Ut Dis. Augue Arcu Gravida Ac In Varius Arcu.' ),
								array( 'name' => 'Anaika',   'date' => '08/10/24', 'img' => esc_url( $theme_uri . '/assets/images/team-multi-ethnic-architects-designing-blueprint-plan.svg' ), 'quote' => 'Lorem Ipsum Dolor Sit Amet Consect Bibendum Nulla Neque Aliquet Consec Orci Cursus Pretium Ornare Mi. Diam Suspendisse Morbi Aliquam Laoreet Nisi Quam Ut Dis. Augue Arcu Gravida Ac In Varius Arcu.' ),
							);
						}

						foreach ( $testimonials_data as $testimonial ) : ?>
							<div class="testimonial-card">
								<div class="card-header">
									<div class="client-avatar">
										<img src="<?php echo esc_url( $testimonial['img'] ); ?>" alt="<?php echo esc_attr( $testimonial['name'] ); ?>" loading="lazy">
									</div>
									<div class="client-info">
										<h4><?php echo esc_html( $testimonial['name'] ); ?></h4>
										<span><?php echo esc_html( $testimonial['date'] ); ?></span>
									</div>
								</div>
								<div class="quote-icon"><i class="fa-solid fa-quote-left" aria-hidden="true"></i></div>
								<div class="testimonial-text">
									<?php echo wp_kses_post( $testimonial['quote'] ); ?>
								</div>
								<div class="quote-icon quote-right"><i class="fa-solid fa-quote-right" aria-hidden="true"></i></div>
								<div class="client-rating" aria-label="<?php esc_attr_e( '5 stars', 'swift-takeoffs' ); ?>">
									<?php for ( $s = 0; $s < 5; $s++ ) : ?>
										<i class="fa-solid fa-star" aria-hidden="true"></i>
									<?php endfor; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<button class="slider-arrow arrow-right" id="nextTestimonial" aria-label="<?php esc_attr_e( 'Next testimonial', 'swift-takeoffs' ); ?>">
					<i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
				</button>
			</div>
			<div class="slider-dots" aria-label="<?php esc_attr_e( 'Testimonial navigation dots', 'swift-takeoffs' ); ?>">
				<span class="dot" aria-label="1"></span>
				<span class="dot active" aria-label="2"></span>
				<span class="dot" aria-label="3"></span>
				<span class="dot" aria-label="4"></span>
			</div>
		</div>
	</section>

<?php get_footer(); ?>
