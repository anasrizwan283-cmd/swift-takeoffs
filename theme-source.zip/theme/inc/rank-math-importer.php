<?php
/**
 * Rank Math SEO Importer — CSV upload from WP Admin.
 *
 * Tools → Rank Math SEO Import
 * Client uploads a CSV (URLs, Meta Title, Meta Description) and applies
 * values into Rank Math. Optional fallback: theme seo-meta-data.php map.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether Rank Math is available.
 *
 * @return bool
 */
function swift_rm_importer_ready() {
	return class_exists( 'RankMath' ) || defined( 'RANK_MATH_VERSION' );
}

/**
 * Register admin page under Tools.
 */
function swift_rm_importer_menu() {
	add_management_page(
		__( 'Rank Math SEO Import', 'swift-takeoffs' ),
		__( 'Rank Math SEO Import', 'swift-takeoffs' ),
		'manage_options',
		'swift-rank-math-import',
		'swift_rm_importer_render_page'
	);
}
add_action( 'admin_menu', 'swift_rm_importer_menu' );

/**
 * Enqueue premium admin UI assets on the importer page only.
 *
 * @param string $hook Current admin page hook.
 */
function swift_rm_importer_assets( $hook ) {
	if ( 'tools_page_swift-rank-math-import' !== $hook ) {
		return;
	}

	$theme_uri = get_template_directory_uri();
	$theme_dir = get_template_directory();
	$ver_css   = (string) filemtime( $theme_dir . '/assets/css/admin-seo-import.css' );
	$ver_js    = (string) filemtime( $theme_dir . '/assets/js/admin-seo-import.js' );

	wp_enqueue_style(
		'swift-rm-seo-import',
		$theme_uri . '/assets/css/admin-seo-import.css',
		array(),
		$ver_css
	);

	wp_enqueue_script(
		'swift-rm-seo-import',
		$theme_uri . '/assets/js/admin-seo-import.js',
		array(),
		$ver_js,
		true
	);
}
add_action( 'admin_enqueue_scripts', 'swift_rm_importer_assets' );

/**
 * Turn a full URL or path into a normalised relative path.
 *
 * @param string $url_or_path Absolute URL or path.
 * @return string e.g. /about-us/ or /
 */
function swift_rm_url_to_path( $url_or_path ) {
	$url_or_path = trim( $url_or_path );
	if ( '' === $url_or_path ) {
		return '';
	}

	// Absolute URL → path only
	if ( preg_match( '#^https?://#i', $url_or_path ) ) {
		$parsed = wp_parse_url( $url_or_path );
		$path   = isset( $parsed['path'] ) ? $parsed['path'] : '/';
	} else {
		$path = $url_or_path;
	}

	$path = '/' . trim( strtolower( $path ), '/' ) . '/';
	if ( '//' === $path ) {
		$path = '/';
	}

	return $path;
}

/**
 * Parse uploaded / local CSV into path => meta map.
 *
 * Expected headers (case-insensitive): URL(s), Meta Title, Meta Description
 *
 * @param string $file_path Absolute path to CSV file.
 * @return array{data?: array<string, array{title: string, desc: string}>, error?: string}
 */
function swift_rm_parse_csv_file( $file_path ) {
	if ( ! is_readable( $file_path ) ) {
		return array( 'error' => __( 'CSV file could not be read.', 'swift-takeoffs' ) );
	}

	$handle = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
	if ( ! $handle ) {
		return array( 'error' => __( 'Unable to open CSV file.', 'swift-takeoffs' ) );
	}

	// Strip UTF-8 BOM if present
	$bom = fread( $handle, 3 );
	if ( "\xEF\xBB\xBF" !== $bom ) {
		rewind( $handle );
	}

	$header = fgetcsv( $handle );
	if ( ! $header || count( $header ) < 2 ) {
		fclose( $handle );
		return array( 'error' => __( 'CSV must have a header row: URLs, Meta Title, Meta Description.', 'swift-takeoffs' ) );
	}

	$cols = array();
	foreach ( $header as $i => $label ) {
		$key = strtolower( trim( (string) $label ) );
		$key = preg_replace( '/\s+/', ' ', $key );
		if ( in_array( $key, array( 'url', 'urls', 'link', 'permalink', 'page url' ), true ) ) {
			$cols['url'] = $i;
		} elseif ( in_array( $key, array( 'meta title', 'title', 'seo title', 'metatitle' ), true ) ) {
			$cols['title'] = $i;
		} elseif ( in_array( $key, array( 'meta description', 'description', 'seo description', 'metadescription', 'meta desc' ), true ) ) {
			$cols['desc'] = $i;
		}
	}

	if ( ! isset( $cols['url'], $cols['title'] ) ) {
		fclose( $handle );
		return array(
			'error' => __( 'CSV headers must include URL and Meta Title columns (optional: Meta Description).', 'swift-takeoffs' ),
		);
	}

	$data  = array();
	$row_n = 1;

	while ( ( $row = fgetcsv( $handle ) ) !== false ) {
		++$row_n;
		if ( ! is_array( $row ) || ! isset( $row[ $cols['url'] ] ) ) {
			continue;
		}

		$raw_url = trim( (string) $row[ $cols['url'] ] );
		if ( '' === $raw_url ) {
			continue;
		}

		$path  = swift_rm_url_to_path( $raw_url );
		$title = isset( $row[ $cols['title'] ] ) ? trim( (string) $row[ $cols['title'] ] ) : '';
		$desc  = ( isset( $cols['desc'], $row[ $cols['desc'] ] ) ) ? trim( (string) $row[ $cols['desc'] ] ) : '';

		if ( '' === $path || '' === $title ) {
			continue;
		}

		$data[ $path ] = array(
			'title' => $title,
			'desc'  => $desc,
		);
	}

	fclose( $handle );

	if ( empty( $data ) ) {
		return array( 'error' => __( 'No valid rows found in the CSV.', 'swift-takeoffs' ) );
	}

	return array( 'data' => $data );
}

/**
 * Resolve a relative URL path to a WordPress object.
 *
 * @param string $path Path with leading/trailing slash, e.g. /about-us/.
 * @return array{type: string, id?: int, label: string, cpt?: string}|null
 */
function swift_rm_resolve_path( $path ) {
	$path = swift_rm_url_to_path( $path );
	if ( '' === $path ) {
		return null;
	}

	// Homepage — write page meta AND Rank Math Titles homepage fields
	if ( '/' === $path ) {
		$front_id = (int) get_option( 'page_on_front' );
		if ( $front_id ) {
			return array(
				'type'  => 'homepage_static',
				'id'    => $front_id,
				'label' => 'Homepage (page_on_front + Rank Math Titles)',
			);
		}
		return array(
			'type'  => 'homepage_option',
			'label' => 'Homepage (Rank Math Titles settings)',
		);
	}

	// CPT archives
	if ( '/services/' === $path ) {
		return array(
			'type'  => 'cpt_archive',
			'id'    => 0,
			'label' => 'Services archive (Rank Math Titles)',
			'cpt'   => 'service',
		);
	}
	if ( '/trades/' === $path ) {
		return array(
			'type'  => 'cpt_archive',
			'id'    => 0,
			'label' => 'Trades archive (Rank Math Titles)',
			'cpt'   => 'trade',
		);
	}

	// Blog index (posts page)
	if ( '/blog/' === $path ) {
		$blog_id = (int) get_option( 'page_for_posts' );
		if ( $blog_id ) {
			return array(
				'type'  => 'post',
				'id'    => $blog_id,
				'label' => 'Blog page (page_for_posts)',
			);
		}
		return array(
			'type'  => 'posts_archive',
			'label' => 'Posts archive (Rank Math Titles)',
		);
	}

	// Category archive
	if ( 0 === strpos( $path, '/category/' ) ) {
		$slug = trim( str_replace( '/category/', '', $path ), '/' );
		$term = get_term_by( 'slug', $slug, 'category' );
		if ( $term && ! is_wp_error( $term ) ) {
			return array(
				'type'  => 'term',
				'id'    => (int) $term->term_id,
				'label' => 'Category: ' . $term->name,
			);
		}
		return null;
	}

	$url     = home_url( $path );
	$post_id = url_to_postid( $url );

	if ( ! $post_id ) {
		$slug       = trim( $path, '/' );
		$post_types = array( 'page', 'post', 'service', 'trade' );

		if ( false !== strpos( $slug, '/' ) ) {
			$parts      = explode( '/', $slug );
			$leaf       = end( $parts );
			$parent     = $parts[0];
			$candidates = array();

			if ( 'trades' === $parent ) {
				$candidates[] = array( 'trade', $leaf );
			} elseif ( 'services' === $parent ) {
				$candidates[] = array( 'service', $leaf );
			}

			foreach ( $candidates as $pair ) {
				$found = get_posts(
					array(
						'name'           => $pair[1],
						'post_type'      => $pair[0],
						'post_status'    => 'publish',
						'posts_per_page' => 1,
						'fields'         => 'ids',
					)
				);
				if ( ! empty( $found ) ) {
					$post_id = (int) $found[0];
					break;
				}
			}
		} else {
			foreach ( $post_types as $pt ) {
				$found = get_posts(
					array(
						'name'           => $slug,
						'post_type'      => $pt,
						'post_status'    => 'publish',
						'posts_per_page' => 1,
						'fields'         => 'ids',
					)
				);
				if ( ! empty( $found ) ) {
					$post_id = (int) $found[0];
					break;
				}
			}
		}
	}

	if ( $post_id ) {
		$post = get_post( $post_id );
		return array(
			'type'  => 'post',
			'id'    => $post_id,
			'label' => sprintf( '%s #%d — %s', $post->post_type, $post_id, $post->post_title ),
		);
	}

	return null;
}

/**
 * Update Rank Math Titles & Meta option keys.
 *
 * @param array $updates Key => value pairs inside rank-math-options-titles.
 */
function swift_rm_update_titles_option( $updates ) {
	$option_key = 'rank-math-options-titles';
	$opts       = get_option( $option_key, array() );
	if ( ! is_array( $opts ) ) {
		$opts = array();
	}
	foreach ( $updates as $key => $value ) {
		$opts[ $key ] = $value;
	}
	update_option( $option_key, $opts, false );
}

/**
 * Write title/desc to post or term Rank Math fields (incl. social overrides).
 *
 * @param string $object_type post|term.
 * @param int    $object_id   ID.
 * @param string $title       SEO title.
 * @param string $desc        Meta description.
 */
function swift_rm_write_object_meta( $object_type, $object_id, $title, $desc ) {
	$pairs = array(
		'rank_math_title'                => $title,
		'rank_math_description'          => $desc,
		'rank_math_facebook_title'       => $title,
		'rank_math_facebook_description' => $desc,
		'rank_math_twitter_title'        => $title,
		'rank_math_twitter_description'  => $desc,
	);

	foreach ( $pairs as $key => $value ) {
		if ( 'post' === $object_type ) {
			update_post_meta( $object_id, $key, $value );
		} else {
			update_term_meta( $object_id, $key, $value );
		}
	}
}

/**
 * Write Rank Math title + description for a resolved target.
 *
 * @param array  $target Resolved target from swift_rm_resolve_path().
 * @param string $title  SEO title.
 * @param string $desc   Meta description.
 * @return string Result message.
 */
function swift_rm_apply_meta( $target, $title, $desc ) {
	$type = $target['type'];

	if ( 'post' === $type && ! empty( $target['id'] ) ) {
		swift_rm_write_object_meta( 'post', $target['id'], $title, $desc );
		return 'updated post meta';
	}

	if ( 'homepage_static' === $type && ! empty( $target['id'] ) ) {
		swift_rm_write_object_meta( 'post', $target['id'], $title, $desc );
		swift_rm_update_titles_option(
			array(
				'homepage_title'       => $title,
				'homepage_description' => $desc,
			)
		);
		return 'updated homepage page meta + Rank Math Titles';
	}

	if ( 'term' === $type && ! empty( $target['id'] ) ) {
		swift_rm_write_object_meta( 'term', $target['id'], $title, $desc );
		return 'updated term meta';
	}

	$option_key = 'rank-math-options-titles';
	$opts       = get_option( $option_key, array() );
	if ( ! is_array( $opts ) ) {
		$opts = array();
	}

	if ( 'homepage_option' === $type ) {
		swift_rm_update_titles_option(
			array(
				'homepage_title'       => $title,
				'homepage_description' => $desc,
			)
		);
		return 'updated Rank Math homepage titles';
	}

	if ( 'cpt_archive' === $type && ! empty( $target['cpt'] ) ) {
		$cpt = $target['cpt'];
		$opts[ 'pt_' . $cpt . '_archive_title' ]       = $title;
		$opts[ 'pt_' . $cpt . '_archive_description' ] = $desc;
		update_option( $option_key, $opts, false );
		return 'updated Rank Math CPT archive titles';
	}

	if ( 'posts_archive' === $type ) {
		$opts['pt_post_title']       = $title;
		$opts['pt_post_description'] = $desc;
		update_option( $option_key, $opts, false );
		return 'updated Rank Math posts archive titles';
	}

	return 'skipped — unknown target type';
}

/**
 * Run import against a data map.
 *
 * @param array<string, array{title: string, desc: string}> $data    Path => meta.
 * @param bool                                               $dry_run Preview only.
 * @param string                                             $source  Label for results.
 * @return array{ok: array, fail: array, dry: bool, source: string, count: int}
 */
function swift_rm_run_import_data( $data, $dry_run = false, $source = 'csv' ) {
	$ok   = array();
	$fail = array();

	foreach ( $data as $path => $meta ) {
		$title  = isset( $meta['title'] ) ? $meta['title'] : '';
		$desc   = isset( $meta['desc'] ) ? $meta['desc'] : '';
		$target = swift_rm_resolve_path( $path );

		if ( ! $target ) {
			$fail[] = array(
				'path'   => $path,
				'reason' => 'No matching page/post/term found',
			);
			continue;
		}

		if ( $dry_run ) {
			$ok[] = array(
				'path'   => $path,
				'label'  => $target['label'],
				'title'  => $title,
				'action' => 'would apply',
			);
			continue;
		}

		$action = swift_rm_apply_meta( $target, $title, $desc );
		$ok[]   = array(
			'path'   => $path,
			'label'  => $target['label'],
			'title'  => $title,
			'action' => $action,
		);
	}

	return array(
		'ok'     => $ok,
		'fail'   => $fail,
		'dry'    => $dry_run,
		'source' => $source,
		'count'  => count( $data ),
	);
}

/**
 * Handle form submit (CSV upload or theme fallback).
 */
function swift_rm_importer_handle_post() {
	if ( ! isset( $_POST['swift_rm_import_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['swift_rm_import_nonce'] ) ), 'swift_rm_import' ) ) {
		return;
	}

	$dry    = isset( $_POST['swift_rm_dry_run'] );
	$source = isset( $_POST['swift_rm_source'] ) ? sanitize_key( wp_unslash( $_POST['swift_rm_source'] ) ) : 'csv';
	$data   = array();
	$label  = 'csv';

	if ( 'theme' === $source ) {
		if ( ! function_exists( 'swift_seo_get_expert_data' ) ) {
			require_once get_template_directory() . '/inc/seo-meta-data.php';
		}
		$data  = function_exists( 'swift_seo_get_expert_data' ) ? swift_seo_get_expert_data() : array();
		$label = 'theme seo-meta-data.php';
	} else {
		if ( empty( $_FILES['swift_rm_csv']['tmp_name'] ) ) {
			set_transient(
				'swift_rm_import_result',
				array(
					'ok'     => array(),
					'fail'   => array(),
					'dry'    => $dry,
					'source' => 'csv',
					'count'  => 0,
					'error'  => __( 'Please choose a CSV file to upload.', 'swift-takeoffs' ),
				),
				5 * MINUTE_IN_SECONDS
			);
			wp_safe_redirect( admin_url( 'tools.php?page=swift-rank-math-import&imported=error' ) );
			exit;
		}

		$file = $_FILES['swift_rm_csv']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( ! empty( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) {
			set_transient(
				'swift_rm_import_result',
				array(
					'ok'     => array(),
					'fail'   => array(),
					'dry'    => $dry,
					'source' => 'csv',
					'count'  => 0,
					'error'  => __( 'File upload failed. Try again.', 'swift-takeoffs' ),
				),
				5 * MINUTE_IN_SECONDS
			);
			wp_safe_redirect( admin_url( 'tools.php?page=swift-rank-math-import&imported=error' ) );
			exit;
		}

		$check = wp_check_filetype_and_ext(
			$file['tmp_name'],
			isset( $file['name'] ) ? $file['name'] : 'seo.csv',
			array(
				'csv' => 'text/csv',
				'txt' => 'text/plain',
			)
		);

		$name_ok = ! empty( $file['name'] ) && preg_match( '/\.(csv|txt)$/i', $file['name'] );
		if ( ! $name_ok && empty( $check['ext'] ) ) {
			set_transient(
				'swift_rm_import_result',
				array(
					'ok'     => array(),
					'fail'   => array(),
					'dry'    => $dry,
					'source' => 'csv',
					'count'  => 0,
					'error'  => __( 'Only .csv files are allowed.', 'swift-takeoffs' ),
				),
				5 * MINUTE_IN_SECONDS
			);
			wp_safe_redirect( admin_url( 'tools.php?page=swift-rank-math-import&imported=error' ) );
			exit;
		}

		$parsed = swift_rm_parse_csv_file( $file['tmp_name'] );
		if ( ! empty( $parsed['error'] ) ) {
			set_transient(
				'swift_rm_import_result',
				array(
					'ok'     => array(),
					'fail'   => array(),
					'dry'    => $dry,
					'source' => 'csv',
					'count'  => 0,
					'error'  => $parsed['error'],
				),
				5 * MINUTE_IN_SECONDS
			);
			wp_safe_redirect( admin_url( 'tools.php?page=swift-rank-math-import&imported=error' ) );
			exit;
		}

		$data  = $parsed['data'];
		$label = isset( $file['name'] ) ? sanitize_file_name( $file['name'] ) : 'csv';
	}

	$result = swift_rm_run_import_data( $data, $dry, $label );
	set_transient( 'swift_rm_import_result', $result, 5 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( 'imported', $dry ? 'preview' : '1', admin_url( 'tools.php?page=swift-rank-math-import' ) ) );
	exit;
}
add_action( 'admin_init', 'swift_rm_importer_handle_post' );

/**
 * Render Tools page.
 */
function swift_rm_importer_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$result = get_transient( 'swift_rm_import_result' );
	if ( $result ) {
		delete_transient( 'swift_rm_import_result' );
	}

	$ready       = swift_rm_importer_ready();
	$theme_count = 0;
	if ( function_exists( 'swift_seo_get_expert_data' ) ) {
		$theme_count = count( swift_seo_get_expert_data() );
	} elseif ( file_exists( get_template_directory() . '/inc/seo-meta-data.php' ) ) {
		require_once get_template_directory() . '/inc/seo-meta-data.php';
		$theme_count = function_exists( 'swift_seo_get_expert_data' ) ? count( swift_seo_get_expert_data() ) : 0;
	}

	$ok_count   = ( is_array( $result ) && ! empty( $result['ok'] ) ) ? count( $result['ok'] ) : 0;
	$fail_count = ( is_array( $result ) && ! empty( $result['fail'] ) ) ? count( $result['fail'] ) : 0;
	$is_dry     = ! empty( $result['dry'] );
	?>
	<div class="swift-rm-app">

		<section class="swift-rm-hero">
			<div class="swift-rm-hero-inner">
				<div>
					<div class="swift-rm-kicker">
						<?php esc_html_e( 'Swift Takeoffs · SEO Ops', 'swift-takeoffs' ); ?>
					</div>
					<h1><?php esc_html_e( 'Rank Math SEO Import', 'swift-takeoffs' ); ?></h1>
					<p><?php esc_html_e( 'Upload the client meta sheet and push titles & descriptions into Rank Math in one pass — preview first, then apply.', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="swift-rm-status <?php echo $ready ? '' : 'is-off'; ?>">
					<span class="swift-rm-status-dot" aria-hidden="true"></span>
					<?php
					echo $ready
						? esc_html__( 'Rank Math connected', 'swift-takeoffs' )
						: esc_html__( 'Rank Math offline', 'swift-takeoffs' );
					?>
				</div>
			</div>
		</section>

		<div class="swift-rm-steps" aria-label="<?php esc_attr_e( 'Import workflow', 'swift-takeoffs' ); ?>">
			<div class="swift-rm-step">
				<div class="swift-rm-step-num">1</div>
				<div>
					<strong><?php esc_html_e( 'Upload CSV', 'swift-takeoffs' ); ?></strong>
					<span><?php esc_html_e( 'Client meta sheet', 'swift-takeoffs' ); ?></span>
				</div>
			</div>
			<div class="swift-rm-step">
				<div class="swift-rm-step-num">2</div>
				<div>
					<strong><?php esc_html_e( 'Preview', 'swift-takeoffs' ); ?></strong>
					<span><?php esc_html_e( 'Match URLs safely', 'swift-takeoffs' ); ?></span>
				</div>
			</div>
			<div class="swift-rm-step">
				<div class="swift-rm-step-num">3</div>
				<div>
					<strong><?php esc_html_e( 'Apply', 'swift-takeoffs' ); ?></strong>
					<span><?php esc_html_e( 'Write to Rank Math', 'swift-takeoffs' ); ?></span>
				</div>
			</div>
			<div class="swift-rm-step">
				<div class="swift-rm-step-num">4</div>
				<div>
					<strong><?php esc_html_e( 'Verify', 'swift-takeoffs' ); ?></strong>
					<span><?php esc_html_e( 'Purge cache + source', 'swift-takeoffs' ); ?></span>
				</div>
			</div>
		</div>

		<?php if ( ! empty( $result['error'] ) ) : ?>
			<div class="swift-rm-alert swift-rm-alert-error" role="alert">
				<div>
					<strong><?php esc_html_e( 'Import blocked', 'swift-takeoffs' ); ?></strong>
					<?php echo esc_html( $result['error'] ); ?>
				</div>
			</div>
		<?php elseif ( ! $ready ) : ?>
			<div class="swift-rm-alert swift-rm-alert-error" role="alert">
				<div>
					<strong><?php esc_html_e( 'Rank Math required', 'swift-takeoffs' ); ?></strong>
					<?php esc_html_e( 'Activate Rank Math SEO, then return here to import.', 'swift-takeoffs' ); ?>
				</div>
			</div>
		<?php elseif ( is_array( $result ) && empty( $result['error'] ) && ! $is_dry ) : ?>
			<div class="swift-rm-alert swift-rm-alert-ok" role="status">
				<div>
					<strong><?php esc_html_e( 'Applied to Rank Math', 'swift-takeoffs' ); ?></strong>
					<?php esc_html_e( 'Purge cache (especially homepage), then verify the title tag and meta description in View Source.', 'swift-takeoffs' ); ?>
				</div>
			</div>
		<?php elseif ( is_array( $result ) && $is_dry ) : ?>
			<div class="swift-rm-alert swift-rm-alert-warn" role="status">
				<div>
					<strong><?php esc_html_e( 'Preview only — nothing written', 'swift-takeoffs' ); ?></strong>
					<?php esc_html_e( 'Turn off Preview mode and upload the same file again to apply.', 'swift-takeoffs' ); ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="swift-rm-grid">
			<section class="swift-rm-panel">
				<div class="swift-rm-panel-head">
					<h2><?php esc_html_e( 'Upload client CSV', 'swift-takeoffs' ); ?></h2>
					<p><?php esc_html_e( 'Columns: URLs · Meta Title · Meta Description', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="swift-rm-panel-body">
					<form method="post" enctype="multipart/form-data" id="swift-rm-csv-form">
						<?php wp_nonce_field( 'swift_rm_import', 'swift_rm_import_nonce' ); ?>
						<input type="hidden" name="swift_rm_source" value="csv" />

						<div class="swift-rm-dropzone" id="swift-rm-dropzone">
							<input type="file" id="swift_rm_csv" name="swift_rm_csv" accept=".csv,text/csv" required <?php disabled( ! $ready ); ?> />
							<div class="swift-rm-drop-icon" aria-hidden="true">
								<svg viewBox="0 0 24 24"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
							</div>
							<h3><?php esc_html_e( 'Drop CSV here or browse', 'swift-takeoffs' ); ?></h3>
							<p><?php esc_html_e( 'Accepts .csv — same sheet format your client already uses', 'swift-takeoffs' ); ?></p>
							<div class="swift-rm-file-chip" id="swift-rm-file-chip">
								<span><?php esc_html_e( 'Selected', 'swift-takeoffs' ); ?>:</span>
								<span id="swift-rm-file-name"></span>
							</div>
						</div>

						<div class="swift-rm-toggle-row">
							<div class="swift-rm-toggle-copy">
								<strong><?php esc_html_e( 'Preview only', 'swift-takeoffs' ); ?></strong>
								<span><?php esc_html_e( 'Dry run — map URLs without writing to Rank Math', 'swift-takeoffs' ); ?></span>
							</div>
							<label class="swift-rm-switch" title="<?php esc_attr_e( 'Toggle preview mode', 'swift-takeoffs' ); ?>">
								<input type="checkbox" name="swift_rm_dry_run" value="1" checked <?php disabled( ! $ready ); ?> />
								<span class="swift-rm-switch-ui"></span>
							</label>
						</div>

						<div class="swift-rm-actions">
							<button type="submit" class="swift-rm-btn swift-rm-btn-primary" <?php disabled( ! $ready ); ?>>
								<?php esc_html_e( 'Upload &amp; run', 'swift-takeoffs' ); ?>
							</button>
						</div>
						<p class="swift-rm-hint">
							<?php esc_html_e( 'Recommended: Preview on first. Then disable Preview and re-upload to apply. Safe to re-run — matching URLs are overwritten.', 'swift-takeoffs' ); ?>
						</p>
					</form>
				</div>
			</section>

			<aside class="swift-rm-panel">
				<div class="swift-rm-panel-head">
					<h2><?php esc_html_e( 'How it works', 'swift-takeoffs' ); ?></h2>
					<p><?php esc_html_e( 'Built for non-technical handoff from the client SEO sheet.', 'swift-takeoffs' ); ?></p>
				</div>
				<div class="swift-rm-panel-body">
					<div class="swift-rm-guide">
						<div class="swift-rm-guide-item">
							<i>1</i>
							<div>
								<strong><?php esc_html_e( 'Receive sheet', 'swift-takeoffs' ); ?></strong>
								<span><?php esc_html_e( 'Client sends CSV with URL, title, description.', 'swift-takeoffs' ); ?></span>
							</div>
						</div>
						<div class="swift-rm-guide-item">
							<i>2</i>
							<div>
								<strong><?php esc_html_e( 'Preview matches', 'swift-takeoffs' ); ?></strong>
								<span><?php esc_html_e( 'We resolve each URL to a page, service, trade, or archive.', 'swift-takeoffs' ); ?></span>
							</div>
						</div>
						<div class="swift-rm-guide-item">
							<i>3</i>
							<div>
								<strong><?php esc_html_e( 'Apply to Rank Math', 'swift-takeoffs' ); ?></strong>
								<span><?php esc_html_e( 'Writes SEO + social title/description fields.', 'swift-takeoffs' ); ?></span>
							</div>
						</div>
						<div class="swift-rm-format" aria-hidden="true">
							<span>URLs</span>, <span>Meta Title</span>, <span>Meta Description</span><br />
							https://swifttakeoffs.com/,Construction Estimating…,"Get accurate…"
						</div>
					</div>
				</div>
			</aside>
		</div>

		<details class="swift-rm-fallback">
			<summary>
				<?php
				printf(
					/* translators: %d: number of built-in URLs */
					esc_html__( 'Advanced fallback — theme seo-meta-data.php (%d URLs)', 'swift-takeoffs' ),
					(int) $theme_count
				);
				?>
			</summary>
			<div class="swift-rm-fallback-body">
				<form method="post">
					<?php wp_nonce_field( 'swift_rm_import', 'swift_rm_import_nonce' ); ?>
					<input type="hidden" name="swift_rm_source" value="theme" />
					<div class="swift-rm-toggle-row">
						<div class="swift-rm-toggle-copy">
							<strong><?php esc_html_e( 'Preview only', 'swift-takeoffs' ); ?></strong>
							<span><?php esc_html_e( 'Use only if CSV is unavailable', 'swift-takeoffs' ); ?></span>
						</div>
						<label class="swift-rm-switch">
							<input type="checkbox" name="swift_rm_dry_run" value="1" checked <?php disabled( ! $ready || ! $theme_count ); ?> />
							<span class="swift-rm-switch-ui"></span>
						</label>
					</div>
					<div class="swift-rm-actions">
						<button type="submit" class="swift-rm-btn swift-rm-btn-ghost" <?php disabled( ! $ready || ! $theme_count ); ?>>
							<?php esc_html_e( 'Import from theme file', 'swift-takeoffs' ); ?>
						</button>
					</div>
				</form>
			</div>
		</details>

		<?php if ( is_array( $result ) && empty( $result['error'] ) ) : ?>
			<section class="swift-rm-results">
				<div class="swift-rm-results-head">
					<div>
						<h2>
							<?php
							echo $is_dry
								? esc_html__( 'Preview results', 'swift-takeoffs' )
								: esc_html__( 'Import results', 'swift-takeoffs' );
							?>
						</h2>
						<p>
							<?php
							printf(
								/* translators: %s: source filename or label */
								esc_html__( 'Source: %s', 'swift-takeoffs' ),
								esc_html( isset( $result['source'] ) ? $result['source'] : '' )
							);
							?>
						</p>
					</div>
					<div class="swift-rm-stats">
						<div class="swift-rm-stat">
							<b><?php echo esc_html( (string) $ok_count ); ?></b>
							<span><?php esc_html_e( 'Matched', 'swift-takeoffs' ); ?></span>
						</div>
						<div class="swift-rm-stat">
							<b><?php echo esc_html( (string) $fail_count ); ?></b>
							<span><?php esc_html_e( 'Missing', 'swift-takeoffs' ); ?></span>
						</div>
					</div>
				</div>

				<?php if ( ! empty( $result['ok'] ) ) : ?>
					<div class="swift-rm-table-wrap">
						<table class="swift-rm-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Path', 'swift-takeoffs' ); ?></th>
									<th><?php esc_html_e( 'Target', 'swift-takeoffs' ); ?></th>
									<th><?php esc_html_e( 'SEO Title', 'swift-takeoffs' ); ?></th>
									<th><?php esc_html_e( 'Status', 'swift-takeoffs' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $result['ok'] as $row ) : ?>
									<tr>
										<td><span class="swift-rm-path"><?php echo esc_html( $row['path'] ); ?></span></td>
										<td><?php echo esc_html( $row['label'] ); ?></td>
										<td><?php echo esc_html( $row['title'] ); ?></td>
										<td>
											<?php if ( $is_dry ) : ?>
												<span class="swift-rm-badge swift-rm-badge-preview"><?php esc_html_e( 'Would apply', 'swift-takeoffs' ); ?></span>
											<?php else : ?>
												<span class="swift-rm-badge swift-rm-badge-ok"><?php echo esc_html( $row['action'] ); ?></span>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $result['fail'] ) ) : ?>
					<ul class="swift-rm-fail-list">
						<?php foreach ( $result['fail'] as $row ) : ?>
							<li>
								<strong><?php echo esc_html( $row['path'] ); ?></strong>
								— <?php echo esc_html( $row['reason'] ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</section>
		<?php endif; ?>

	</div>
	<?php
}
