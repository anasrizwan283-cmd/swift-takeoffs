<?php
/**
 * Serve WordPress-generated image sizes instead of original uploads.
 *
 * SCF/ACF image fields are stored as URLs (often the full 3000–4000px file).
 * Mobile PageSpeed then downloads that original. These helpers resolve the
 * attachment and return a sized URL + srcset so the browser can pick ~768px
 * on a phone. They cannot magically compress a 1MB PNG — that still needs
 * a WebP/JPEG re-upload in Media Library.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Banner/hero registered size: wide enough for retina desktop, srcset still
 * includes medium_large / large for phones.
 *
 * @return string
 */
function swift_takeoffs_banner_size() {
	$sizes = function_exists( 'wp_get_registered_image_subsizes' ) ? wp_get_registered_image_subsizes() : array();
	if ( isset( $sizes['1536x1536'] ) ) {
		return '1536x1536';
	}
	return 'large';
}

/**
 * Prefer a same-name .webp next to a theme PNG/JPEG when that file exists.
 *
 * @param string $url Absolute URL.
 * @return string
 */
function swift_takeoffs_prefer_webp( $url ) {
	if ( ! $url || ! preg_match( '/\.(png|jpe?g)(\?.*)?$/i', $url ) ) {
		return $url;
	}

	$theme_uri = get_template_directory_uri();
	$theme_dir = get_template_directory();

	if ( 0 !== strpos( $url, $theme_uri ) ) {
		return $url;
	}

	$webp_url = preg_replace( '/\.(png|jpe?g)(\?.*)?$/i', '.webp$2', $url );
	$path     = str_replace( $theme_uri, $theme_dir, preg_replace( '/\?.*$/', '', $webp_url ) );

	return file_exists( $path ) ? $webp_url : $url;
}

/**
 * Attachment ID from a full-size or cropped media URL.
 *
 * @param string $url Image URL.
 * @return int
 */
function swift_takeoffs_attachment_id_from_url( $url ) {
	static $cache = array();

	$url = strtok( (string) $url, '?' );
	if ( ! $url ) {
		return 0;
	}
	if ( isset( $cache[ $url ] ) ) {
		return $cache[ $url ];
	}

	$id = (int) attachment_url_to_postid( $url );
	if ( ! $id ) {
		$stripped = preg_replace( '/-\d+x\d+(?=\.[a-zA-Z0-9]+$)/', '', $url );
		if ( $stripped && $stripped !== $url ) {
			$id = (int) attachment_url_to_postid( $stripped );
		}
	}

	$cache[ $url ] = $id;
	return $id;
}

/**
 * Resolve an ACF/SCF image (URL, ID, or array) to a sized attachment.
 *
 * @param mixed  $value Field value.
 * @param string $size  Registered size.
 * @return array{id:int,url:string,width:int,height:int,srcset:string,sizes:string}
 */
function swift_takeoffs_image( $value, $size = 'large' ) {
	$id  = 0;
	$url = '';

	if ( is_numeric( $value ) ) {
		$id = (int) $value;
	} elseif ( is_array( $value ) ) {
		$id  = ! empty( $value['ID'] ) ? (int) $value['ID'] : ( ! empty( $value['id'] ) ? (int) $value['id'] : 0 );
		$url = ! empty( $value['url'] ) ? (string) $value['url'] : '';
		if ( ! $id && $url ) {
			$id = swift_takeoffs_attachment_id_from_url( $url );
		}
	} elseif ( is_string( $value ) && $value ) {
		$url = $value;
		$id  = swift_takeoffs_attachment_id_from_url( $value );
	}

	if ( $id ) {
		$src = wp_get_attachment_image_src( $id, $size );
		if ( $src ) {
			return array(
				'id'     => $id,
				'url'    => swift_takeoffs_prefer_webp( $src[0] ),
				'width'  => (int) $src[1],
				'height' => (int) $src[2],
				'srcset' => (string) wp_get_attachment_image_srcset( $id, $size ),
				'sizes'  => (string) wp_get_attachment_image_sizes( $id, $size ),
			);
		}
	}

	return array(
		'id'     => 0,
		'url'    => swift_takeoffs_prefer_webp( $url ),
		'width'  => 0,
		'height' => 0,
		'srcset' => '',
		'sizes'  => '',
	);
}

/**
 * Print an <img> from swift_takeoffs_image().
 *
 * @param array<string, mixed> $image Helper result.
 * @param array<string, mixed> $args  alt, class, loading, fetchpriority, sizes, decoding, width, height.
 */
function swift_takeoffs_the_image( $image, $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'alt'           => '',
			'class'         => '',
			'loading'       => 'lazy',
			'fetchpriority' => '',
			'sizes'         => '',
			'decoding'      => 'async',
			'width'         => 0,
			'height'        => 0,
		)
	);

	if ( empty( $image['url'] ) ) {
		return;
	}

	$width  = ! empty( $args['width'] ) ? (int) $args['width'] : (int) $image['width'];
	$height = ! empty( $args['height'] ) ? (int) $args['height'] : (int) $image['height'];
	$sizes  = $args['sizes'] ? $args['sizes'] : ( ! empty( $image['sizes'] ) ? $image['sizes'] : '' );

	$attrs = array(
		'src'      => $image['url'],
		'alt'      => (string) $args['alt'],
		'decoding' => (string) $args['decoding'],
	);

	if ( $args['class'] ) {
		$attrs['class'] = (string) $args['class'];
	}
	if ( $width ) {
		$attrs['width'] = (string) $width;
	}
	if ( $height ) {
		$attrs['height'] = (string) $height;
	}
	if ( ! empty( $image['srcset'] ) ) {
		$attrs['srcset'] = $image['srcset'];
	}
	if ( $sizes ) {
		$attrs['sizes'] = $sizes;
	}

	$priority = (string) $args['fetchpriority'];
	if ( $priority ) {
		$attrs['fetchpriority'] = $priority;
		if ( 'high' === $priority ) {
			$attrs['loading'] = 'eager';
		}
	} elseif ( $args['loading'] ) {
		$attrs['loading'] = (string) $args['loading'];
	}

	$html = '<img';
	foreach ( $attrs as $name => $value ) {
		if ( 'src' === $name ) {
			$html .= ' src="' . esc_url( $value ) . '"';
			continue;
		}
		if ( 'srcset' === $name ) {
			$html .= ' srcset="' . esc_attr( $value ) . '"';
			continue;
		}
		$html .= ' ' . $name . '="' . esc_attr( $value ) . '"';
	}
	echo $html . '>';
}

/**
 * Banner image for a service/trade single (SCF field, else featured image).
 *
 * @param int $post_id Post ID.
 * @return array<string, mixed>
 */
function swift_takeoffs_singular_banner_image( $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : (int) get_queried_object_id();
	if ( ! $post_id ) {
		return swift_takeoffs_image( '', swift_takeoffs_banner_size() );
	}

	$field = '';
	$type  = get_post_type( $post_id );
	if ( 'service' === $type ) {
		$field = 'service_banner_image';
	} elseif ( 'trade' === $type ) {
		$field = 'trade_banner_image';
	}

	$raw = '';
	if ( $field && function_exists( 'get_field' ) ) {
		$raw = get_field( $field, $post_id );
	}
	if ( ! $raw && has_post_thumbnail( $post_id ) ) {
		$raw = get_post_thumbnail_id( $post_id );
	}

	return swift_takeoffs_image( $raw, swift_takeoffs_banner_size() );
}

/**
 * URL to preload as LCP (must match the on-page image src).
 *
 * @return string
 */
function swift_takeoffs_lcp_preload_url() {
	$theme_uri = get_template_directory_uri();

	if ( is_front_page() ) {
		$hero_webp = get_template_directory() . '/assets/images/heroimage.webp';
		return file_exists( $hero_webp )
			? $theme_uri . '/assets/images/heroimage.webp'
			: $theme_uri . '/assets/images/heroimage.svg';
	}

	if ( is_page_template( 'page-about.php' ) ) {
		$about_webp = get_template_directory() . '/assets/images/group-architect-discussing-layout-plan-blueprint-office.webp';
		return file_exists( $about_webp )
			? $theme_uri . '/assets/images/group-architect-discussing-layout-plan-blueprint-office.webp'
			: $theme_uri . '/assets/images/group-architect-discussing-layout-plan-blueprint-office.svg';
	}

	if ( function_exists( 'swift_takeoffs_is_campaign_lander' ) && swift_takeoffs_is_campaign_lander() ) {
		$raw = function_exists( 'get_field' ) ? get_field( 'st_cl_hero_bg', get_queried_object_id() ) : '';
		$img = swift_takeoffs_image( $raw, swift_takeoffs_banner_size() );
		if ( ! empty( $img['url'] ) ) {
			return $img['url'];
		}
		$fallback = $theme_uri . '/assets/campaign-lander/hero-bg.png';
		return swift_takeoffs_prefer_webp( $fallback );
	}

	if ( is_page_template( 'page-drywall-estimating-landing.php' ) ) {
		return $theme_uri . '/assets/landing-drywall/images/hero-bg.svg';
	}

	if ( is_singular( array( 'service', 'trade' ) ) ) {
		$img = swift_takeoffs_singular_banner_image( get_queried_object_id() );
		return ! empty( $img['url'] ) ? $img['url'] : '';
	}

	if ( is_singular() && has_post_thumbnail() ) {
		$url = get_the_post_thumbnail_url( get_queried_object_id(), 'large' );
		return $url ? $url : '';
	}

	return '';
}
