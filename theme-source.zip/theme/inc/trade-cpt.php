<?php
/**
 * Trade Custom Post Type Registration
 *
 * Registers the 'trade' CPT and its rewrite rules.
 * Included from functions.php.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================
// REGISTER 'TRADE' CUSTOM POST TYPE
// ============================================================

function swift_takeoffs_register_trade_cpt() {

	$labels = array(
		'name'                  => _x( 'Trades', 'Post type general name', 'swift-takeoffs' ),
		'singular_name'         => _x( 'Trade', 'Post type singular name', 'swift-takeoffs' ),
		'menu_name'             => _x( 'Trades', 'Admin Menu text', 'swift-takeoffs' ),
		'name_admin_bar'        => _x( 'Trade', 'Add New on Toolbar', 'swift-takeoffs' ),
		'add_new'               => __( 'Add New Trade', 'swift-takeoffs' ),
		'add_new_item'          => __( 'Add New Trade', 'swift-takeoffs' ),
		'new_item'              => __( 'New Trade', 'swift-takeoffs' ),
		'edit_item'             => __( 'Edit Trade', 'swift-takeoffs' ),
		'view_item'             => __( 'View Trade', 'swift-takeoffs' ),
		'all_items'             => __( 'All Trades', 'swift-takeoffs' ),
		'search_items'          => __( 'Search Trades', 'swift-takeoffs' ),
		'not_found'             => __( 'No trades found.', 'swift-takeoffs' ),
		'not_found_in_trash'    => __( 'No trades found in Trash.', 'swift-takeoffs' ),
		'featured_image'        => __( 'Trade Banner Image', 'swift-takeoffs' ),
		'set_featured_image'    => __( 'Set banner image', 'swift-takeoffs' ),
		'remove_featured_image' => __( 'Remove banner image', 'swift-takeoffs' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array(
			'slug'       => 'trades',   // URL: yourdomain.com/trades/masonry-estimating/
			'with_front' => false,
		),
		'capability_type'    => 'post',
		'has_archive'        => true,   // enables: yourdomain.com/trades/
		'hierarchical'       => false,
		'menu_position'      => 5,
		'menu_icon'          => 'dashicons-hammer',
		'supports'           => array(
			'title',           // Trade name (e.g. "Masonry Estimating Service")
			'editor',          // Optional fallback content
			'thumbnail',       // Featured image (used as fallback banner)
			'excerpt',         // Short description for archive cards
		),
		'show_in_rest'       => true,   // Enables Gutenberg block editor
	);

	register_post_type( 'trade', $args );
}
add_action( 'init', 'swift_takeoffs_register_trade_cpt' );


// ============================================================
// FLUSH REWRITE RULES ONCE AFTER ACTIVATION
// (runs only when theme is switched — not on every load)
// ============================================================

function swift_takeoffs_flush_rewrite_rules() {
	swift_takeoffs_register_trade_cpt();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'swift_takeoffs_flush_rewrite_rules' );


// ============================================================
// HELPER: GET ALL PUBLISHED TRADES (used in sidebar)
// Returns WP_Post[] limited to $limit (default 6)
// ============================================================

function swift_takeoffs_get_all_trades( $limit = 6 ) {
	return get_posts(
		array(
			'post_type'      => 'trade',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		)
	);
}
