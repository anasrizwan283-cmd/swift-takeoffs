<?php
/**
 * Campaign lander field helpers + SCF/ACF local field group.
 *
 * Fields are registered in PHP so they appear automatically when
 * Secure Custom Fields (or ACF) is active. No manual field-group setup.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default copy from the client drywall HTML kit.
 *
 * @return array<string, mixed>
 */
function st_lander_defaults() {
	$uri = get_template_directory_uri() . '/assets/campaign-lander';

	return array(
		'st_cl_service_type'     => 'Drywall',
		'st_cl_funnel'           => '',
		'st_cl_hero_eyebrow'     => 'Drywall estimating services for contractors',
		'st_cl_hero_heading'     => 'Need Accurate Drywall Estimating Services, Fast?',
		'st_cl_hero_subtext'     => 'Drywall estimating services from the team that has delivered cost estimates on over $250M+ in construction projects.',
		'st_cl_hero_cta'         => 'Get My Free Quote',
		'st_cl_hero_bg'          => $uri . '/hero-bg.png',
		'st_cl_highlights'       => array(
			array( 'text' => '24–48 hour delivery' ),
			array( 'text' => '99% accurate quantities' ),
			array( 'text' => 'Built for US contractors' ),
		),
		'st_cl_form_eyebrow'     => 'Get started',
		'st_cl_form_title'       => 'Get your free quote',
		'st_cl_form_subtitle'    => 'Tell us about the project. We’ll follow up quickly',
		'st_cl_logos_heading'    => 'Trusted by construction teams nationwide',
		'st_cl_why_eyebrow'      => 'Why Swift Takeoffs',
		'st_cl_why_title'        => 'More time to bid with drywall estimating services you can build on.',
		'st_cl_features'         => array(
			array(
				'icon'  => $uri . '/icons/fast-turnaround.svg',
				'title' => 'Fast Turnaround',
				'text'  => 'Receive a clear, bid-ready estimate in as little as 8–24 hours.',
			),
			array(
				'icon'  => $uri . '/icons/accurate-quantities.svg',
				'title' => '99% Accurate Quantities',
				'text'  => 'Detailed counts and measurements you can rely on when pricing work.',
			),
			array(
				'icon'  => $uri . '/icons/bid-more.svg',
				'title' => 'Bid More Projects',
				'text'  => 'Free your team from takeoffs and keep more opportunities moving.',
			),
		),
		'st_cl_process_eyebrow'  => 'A straightforward process',
		'st_cl_process_title'    => 'From plans to a confident bid.',
		'st_cl_process_cta'      => 'Get My Free Quote',
		'st_cl_steps'            => array(
			array(
				'title' => 'Upload Plans',
				'text'  => 'Send your drawings and project details.',
			),
			array(
				'title' => 'We Prepare Your Estimate',
				'text'  => 'Our team measures every scope item.',
			),
			array(
				'title' => 'Receive Your Report & Win More Jobs',
				'text'  => 'Use the finished takeoff to price faster.',
			),
		),
		'st_cl_expertise_eyebrow' => 'Our Expertise',
		'st_cl_expertise_title'   => "Swift Takeoffs Software's",
		'st_cl_deliv_eyebrow'     => 'Deliverables',
		'st_cl_deliv_title'       => 'What you’ll receive.',
		'st_cl_deliv_text'        => 'Every order ships as a polished package — accurate quantities, marked-up plans, and cost estimates ready to hand straight to your estimator.',
		'st_cl_deliv_image'       => $uri . '/deliverables-sample.png',
		'st_cl_deliverables'      => array(
			array(
				'title' => 'Detailed Quantity Takeoffs',
				'text'  => 'Line-item breakdowns ready to drop straight into your bid.',
			),
			array(
				'title' => 'Marked-Up Plans (PDF)',
				'text'  => 'Color-coded PDFs so you can verify every measurement at a glance.',
			),
			array(
				'title' => 'Detailed Cost Estimates',
				'text'  => 'Track progress live and message your estimator directly.',
			),
			array(
				'title' => 'Scope, Assumptions & Exclusions',
				'text'  => 'Every assumption written out — no guessing what’s included or excluded.',
			),
			array(
				'title' => 'Trade-Specific Breakdown',
				'text'  => 'Toggle layers on and off so reviewing scope is efficient and clear.',
			),
		),
		'st_cl_reviews_eyebrow'   => 'Contractor feedback',
		'st_cl_reviews_title'     => 'Reviews from contractors who bid to win.',
		'st_cl_reviews'           => array(
			array(
				'initials' => 'JD',
				'color'    => 'red',
				'name'     => 'James Delaney',
				'count'    => '7 reviews',
				'time'     => '2 months ago',
				'quote'    => 'Saved us hours on our last bid. The quantities were detailed, clear, and ready to price. It gave our team the confidence to move quickly and submit a stronger number before the deadline.',
			),
			array(
				'initials' => 'MR',
				'color'    => 'blue',
				'name'     => 'Maria Rodriguez',
				'count'    => '12 reviews',
				'time'     => '4 months ago',
				'quote'    => 'The report was more organized than what we had been doing in-house. The scope was easy to follow and everything was ready for pricing. We now use Swift Takeoffs for every serious bid.',
			),
			array(
				'initials' => 'TW',
				'color'    => 'green',
				'name'     => 'Tom Wallace',
				'count'    => '5 reviews',
				'time'     => '6 months ago',
				'quote'    => 'They turned around a large job quickly and gave us the confidence to submit before the deadline. The takeoff was accurate, straightforward, and saved our estimating team a lot of time.',
			),
		),
		'st_cl_faq_eyebrow'       => 'FAQ',
		'st_cl_faq_title'         => 'Questions, answered.',
		'st_cl_guide_eyebrow'     => 'The service',
		'st_cl_guide_title'       => 'How drywall estimating services help you bid with confidence',
		'st_cl_guide_body'        => st_lander_default_guide_body(),
		'st_cl_faqs'              => array(
			array(
				'question' => 'How quickly can I receive drywall estimating services?',
				'answer'   => 'Most drywall takeoffs are delivered within 8–24 hours. Tell us if you have a deadline and we’ll confirm availability.',
			),
			array(
				'question' => 'What file formats do you accept?',
				'answer'   => 'We accept PDFs, DWG and DXF files, plus JPG and PNG plan images.',
			),
			array(
				'question' => 'How accurate are your drywall estimating services?',
				'answer'   => 'Every estimate is reviewed for scope and quantity accuracy, with a target of 99% accurate quantities.',
			),
			array(
				'question' => 'Do you work with commercial and residential drywall bids?',
				'answer'   => 'Yes. Swift Takeoffs supports both commercial and residential scopes, including metal studs, gypsum board, taping, and related finishes.',
			),
		),
		'st_cl_cta_eyebrow'       => 'Ready when you are',
		'st_cl_cta_heading'       => 'Spend less time measuring. Bid with confidence.',
		'st_cl_cta_text'          => 'Send your plans today and get a free quote for your next drywall estimate.',
		'st_cl_cta_button'        => 'Get My Free Quote',
		'st_cl_cta_bg'            => $uri . '/cta-bg.png',
		'st_cl_cta_checks'        => array(
			array( 'text' => 'USA Based' ),
			array( 'text' => 'No Contracts' ),
			array( 'text' => 'Detailed Takeoffs' ),
			array( 'text' => '24–48 Hour Turnaround' ),
		),
	);
}

/**
 * Default long-form copy for Rank Math (admin analyzer + schema).
 * Not rendered on the live lander — layout matches the HTML kit.
 *
 * @return string
 */
function st_lander_default_guide_body() {
	$keyword  = 'drywall estimating services';
	$home     = home_url( '/' );
	$services = home_url( '/services/' );
	$quote    = home_url( '/get-a-quote/' );
	$bluebeam = 'https://www.bluebeam.com/';

	return '<p>Drywall estimating services from Swift Takeoffs give contractors bid-ready quantities without pulling your team off live work. We measure board, metal studs, insulation, taping, and related finishes from your drawings and return a clear report you can price with confidence.</p>
<p>Most drywall bids are lost on incomplete counts, missed walls, or last-minute scope changes. Outsourced ' . $keyword . ' close those gaps so you can submit more jobs and protect margin. Our estimators work from PDFs and CAD files, mark up the plans, and list every assumption so you know exactly what is included.</p>
<h3>What you receive on every order</h3>
<p>Each package includes a line-item takeoff, color-coded marked-up plans, and a cost-ready breakdown. You can drop quantities into Excel or your estimating software and start pricing instead of measuring. That is why contractors use our ' . $keyword . ' when the bid calendar is full.</p>
<p>Reports are compatible with Excel and PDF and with tools such as <a href="' . esc_url( $bluebeam ) . '" rel="noopener noreferrer">Bluebeam</a>, PlanSwift, and STACK. If you already have a workflow, we match it instead of forcing a new one.</p>
<h3>Commercial and residential drywall scopes</h3>
<p>We support apartments, schools, healthcare, offices, and custom homes. Typical scopes cover gypsum board, light-gauge framing, acoustical ceilings, fire-rated assemblies, and finish levels. Tell us the spec and we will count to that spec. Swift Takeoffs ' . $keyword . ' are built for US contractors who need numbers they can stand behind.</p>
<p>Turnaround is usually 8–24 hours for standard packages, with a target of 99% accurate quantities. If you have a hard bid date, say so when you send the plans and we will confirm a delivery window before work starts.</p>
<p>Estimators stay in the file: missing partitions, shaft walls, and finish levels are the usual leaks. A second set of eyes on the drawings reduces those misses. We also document exclusions so your bid letter matches the takeoff, which keeps RFIs and change-order fights from starting on day one of the job.</p>
<p>National contractors use Swift Takeoffs when internal teams are already at capacity. Local GCs use us for overflow during busy bid weeks. In both cases the goal is the same: a quantity sheet you can price without redrawing the building. Send one project to evaluate the format, then keep us on the list for the next deadline.</p>
<h3>How to get started</h3>
<p>Upload drawings through the form on this page or visit our <a href="' . esc_url( $quote ) . '">quote page</a>. Share the project name, trade scope, and any addenda. We review the files, prepare the takeoff, and send the report so you can bid. Explore other <a href="' . esc_url( $services ) . '">construction estimating services</a> or return to the <a href="' . esc_url( $home ) . '">Swift Takeoffs homepage</a> for trades beyond drywall.</p>
<p>Whether you need a single-trade count or a multi-building package, our ' . $keyword . ' keep measuring off your plate so your estimators can focus on price, risk, and winning work.</p>';
}

/**
 * Text/URL field with drywall kit fallback.
 *
 * @param string $name    Field name.
 * @param int    $post_id Optional post ID.
 * @return string
 */
function st_lander_text( $name, $post_id = 0 ) {
	$defaults = st_lander_defaults();
	$default  = isset( $defaults[ $name ] ) ? (string) $defaults[ $name ] : '';
	$post_id  = $post_id ? (int) $post_id : (int) get_the_ID();

	if ( function_exists( 'get_field' ) ) {
		$value = $post_id ? get_field( $name, $post_id ) : get_field( $name );
		if ( is_string( $value ) && '' !== trim( $value ) ) {
			return $value;
		}
	}

	return $default;
}

/**
 * HTML field (wysiwyg) with drywall kit fallback.
 *
 * @param string $name    Field name.
 * @param int    $post_id Post ID.
 * @return string
 */
function st_lander_html( $name, $post_id = 0 ) {
	$defaults = st_lander_defaults();
	$default  = isset( $defaults[ $name ] ) ? (string) $defaults[ $name ] : '';
	$post_id  = $post_id ? (int) $post_id : (int) get_the_ID();

	if ( function_exists( 'get_field' ) ) {
		$value = $post_id ? get_field( $name, $post_id ) : get_field( $name );
		if ( is_string( $value ) && '' !== trim( wp_strip_all_tags( $value ) ) ) {
			return $value;
		}
	}

	return $default;
}

/**
 * Rank Math focus phrase from the lander’s service type.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function st_lander_focus_keyword( $post_id = 0 ) {
	$service = strtolower( trim( st_lander_text( 'st_cl_service_type', $post_id ) ) );
	if ( ! $service ) {
		$service = 'drywall';
	}
	return $service . ' estimating services';
}

/**
 * Image URL from SCF/ACF or kit fallback.
 *
 * @param string $name         Field name.
 * @param string $fallback_rel Theme-relative path starting with /assets/.
 * @return string
 */
function st_lander_image_url( $name, $fallback_rel, $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : (int) get_the_ID();
	$raw     = '';

	if ( function_exists( 'get_field' ) ) {
		$value = $post_id ? get_field( $name, $post_id ) : get_field( $name );
		if ( is_array( $value ) && ! empty( $value['url'] ) ) {
			$raw = $value;
		} elseif ( is_string( $value ) && $value ) {
			$raw = $value;
		}
	}

	if ( ! $raw ) {
		$defaults = st_lander_defaults();
		if ( ! empty( $defaults[ $name ] ) && is_string( $defaults[ $name ] ) ) {
			$raw = $defaults[ $name ];
		} else {
			$raw = get_template_directory_uri() . $fallback_rel;
		}
	}

	if ( function_exists( 'swift_takeoffs_image' ) ) {
		$sized = swift_takeoffs_image( $raw, function_exists( 'swift_takeoffs_banner_size' ) ? swift_takeoffs_banner_size() : 'large' );
		if ( ! empty( $sized['url'] ) ) {
			return $sized['url'];
		}
	}

	if ( is_array( $raw ) && ! empty( $raw['url'] ) ) {
		return $raw['url'];
	}

	return is_string( $raw ) ? $raw : ( get_template_directory_uri() . $fallback_rel );
}

/**
 * Repeater rows from SCF/ACF or kit fallback.
 *
 * @param string $name Field name.
 * @return array<int, array<string, mixed>>
 */
function st_lander_rows( $name, $post_id = 0 ) {
	$defaults = st_lander_defaults();
	$fallback = ( isset( $defaults[ $name ] ) && is_array( $defaults[ $name ] ) ) ? $defaults[ $name ] : array();
	$post_id  = $post_id ? (int) $post_id : (int) get_the_ID();

	if ( function_exists( 'get_field' ) ) {
		$rows = $post_id ? get_field( $name, $post_id ) : get_field( $name );
		if ( is_array( $rows ) && $rows ) {
			return $rows;
		}
	}

	return $fallback;
}

/**
 * Funnel slug for lead tracking + thank-you redirect.
 *
 * @return string
 */
function st_lander_funnel() {
	$funnel = st_lander_text( 'st_cl_funnel' );
	if ( $funnel ) {
		return sanitize_title( $funnel );
	}
	if ( is_singular() ) {
		$slug = get_post_field( 'post_name', get_the_ID() );
		if ( $slug ) {
			return sanitize_title( $slug );
		}
	}
	return 'campaign-lander';
}

/**
 * Build a local SCF/ACF field definition.
 *
 * @param string               $key   Unique field key.
 * @param string               $name  Field name.
 * @param string               $label Admin label.
 * @param string               $type  Field type.
 * @param array<string, mixed> $extra Extra args.
 * @return array<string, mixed>
 */
function st_cl_acf_field( $key, $name, $label, $type = 'text', $extra = array() ) {
	return array_merge(
		array(
			'key'   => $key,
			'label' => $label,
			'name'  => $name,
			'type'  => $type,
		),
		$extra
	);
}

/**
 * Register the Campaign Lander field group (appears automatically in WP admin).
 */
function st_lander_register_acf_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	$instructions = __( 'Leave a field empty to keep the drywall kit default. Layout stays the same on every lander.', 'swift-takeoffs' );

	acf_add_local_field_group(
		array(
			'key'      => 'group_st_campaign_lander',
			'title'    => 'Campaign Lander',
			'fields'   => array(
				st_cl_acf_field( 'field_stcl_tab_track', 'tab_track', 'Tracking', 'tab' ),
				st_cl_acf_field( 'field_stcl_service_type', 'st_cl_service_type', 'Service type (hidden on form)', 'text', array( 'instructions' => 'e.g. Drywall, Electrical, Concrete' ) ),
				st_cl_acf_field( 'field_stcl_funnel', 'st_cl_funnel', 'Lead funnel slug', 'text', array( 'instructions' => 'Leave blank to use the page slug (e.g. electrical-estimating).' ) ),

				st_cl_acf_field( 'field_stcl_tab_hero', 'tab_hero', 'Hero', 'tab' ),
				st_cl_acf_field( 'field_stcl_hero_eyebrow', 'st_cl_hero_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_hero_heading', 'st_cl_hero_heading', 'Heading', 'text' ),
				st_cl_acf_field( 'field_stcl_hero_subtext', 'st_cl_hero_subtext', 'Subtext', 'textarea', array( 'rows' => 3 ) ),
				st_cl_acf_field( 'field_stcl_hero_cta', 'st_cl_hero_cta', 'Button label', 'text' ),
				st_cl_acf_field( 'field_stcl_hero_bg', 'st_cl_hero_bg', 'Hero background', 'image', array( 'return_format' => 'url', 'preview_size' => 'medium' ) ),
				st_cl_acf_field(
					'field_stcl_highlights',
					'st_cl_highlights',
					'Highlights',
					'repeater',
					array(
						'layout'       => 'table',
						'button_label' => 'Add highlight',
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_highlight_text', 'text', 'Text', 'text' ),
						),
					)
				),

				st_cl_acf_field( 'field_stcl_tab_form', 'tab_form', 'Quote form', 'tab' ),
				st_cl_acf_field( 'field_stcl_form_eyebrow', 'st_cl_form_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_form_title', 'st_cl_form_title', 'Title', 'text' ),
				st_cl_acf_field( 'field_stcl_form_subtitle', 'st_cl_form_subtitle', 'Subtitle', 'text' ),
				st_cl_acf_field( 'field_stcl_logos_heading', 'st_cl_logos_heading', 'Logo strip heading', 'text' ),

				st_cl_acf_field( 'field_stcl_tab_why', 'tab_why', 'Why us', 'tab' ),
				st_cl_acf_field( 'field_stcl_why_eyebrow', 'st_cl_why_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_why_title', 'st_cl_why_title', 'Title', 'text' ),
				st_cl_acf_field(
					'field_stcl_features',
					'st_cl_features',
					'Feature cards',
					'repeater',
					array(
						'layout'       => 'block',
						'button_label' => 'Add feature',
						'max'          => 3,
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_feature_icon', 'icon', 'Icon', 'image', array( 'return_format' => 'url', 'preview_size' => 'thumbnail' ) ),
							st_cl_acf_field( 'field_stcl_feature_title', 'title', 'Title', 'text' ),
							st_cl_acf_field( 'field_stcl_feature_text', 'text', 'Text', 'textarea', array( 'rows' => 3 ) ),
						),
					)
				),

				st_cl_acf_field( 'field_stcl_tab_process', 'tab_process', 'Process', 'tab' ),
				st_cl_acf_field( 'field_stcl_process_eyebrow', 'st_cl_process_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_process_title', 'st_cl_process_title', 'Title', 'text' ),
				st_cl_acf_field( 'field_stcl_process_cta', 'st_cl_process_cta', 'Button label', 'text' ),
				st_cl_acf_field(
					'field_stcl_steps',
					'st_cl_steps',
					'Steps',
					'repeater',
					array(
						'layout'       => 'block',
						'button_label' => 'Add step',
						'max'          => 3,
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_step_title', 'title', 'Title', 'text' ),
							st_cl_acf_field( 'field_stcl_step_text', 'text', 'Text', 'textarea', array( 'rows' => 2 ) ),
						),
					)
				),
				st_cl_acf_field( 'field_stcl_expertise_eyebrow', 'st_cl_expertise_eyebrow', 'Software eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_expertise_title', 'st_cl_expertise_title', 'Software title', 'text' ),

				st_cl_acf_field( 'field_stcl_tab_deliv', 'tab_deliv', 'Deliverables', 'tab' ),
				st_cl_acf_field( 'field_stcl_deliv_eyebrow', 'st_cl_deliv_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_deliv_title', 'st_cl_deliv_title', 'Title', 'text' ),
				st_cl_acf_field( 'field_stcl_deliv_text', 'st_cl_deliv_text', 'Intro text', 'textarea', array( 'rows' => 4 ) ),
				st_cl_acf_field( 'field_stcl_deliv_image', 'st_cl_deliv_image', 'Sample image', 'image', array( 'return_format' => 'url', 'preview_size' => 'medium' ) ),
				st_cl_acf_field(
					'field_stcl_deliverables',
					'st_cl_deliverables',
					'Deliverable items',
					'repeater',
					array(
						'layout'       => 'block',
						'button_label' => 'Add item',
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_deliv_item_title', 'title', 'Title', 'text' ),
							st_cl_acf_field( 'field_stcl_deliv_item_text', 'text', 'Text', 'textarea', array( 'rows' => 2 ) ),
						),
					)
				),

				st_cl_acf_field( 'field_stcl_tab_reviews', 'tab_reviews', 'Reviews', 'tab' ),
				st_cl_acf_field( 'field_stcl_reviews_eyebrow', 'st_cl_reviews_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_reviews_title', 'st_cl_reviews_title', 'Title', 'text' ),
				st_cl_acf_field(
					'field_stcl_reviews',
					'st_cl_reviews',
					'Reviews',
					'repeater',
					array(
						'layout'       => 'block',
						'button_label' => 'Add review',
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_review_initials', 'initials', 'Initials', 'text' ),
							st_cl_acf_field(
								'field_stcl_review_color',
								'color',
								'Avatar color',
								'select',
								array(
									'choices' => array(
										'red'   => 'Red',
										'blue'  => 'Blue',
										'green' => 'Green',
									),
								)
							),
							st_cl_acf_field( 'field_stcl_review_name', 'name', 'Name', 'text' ),
							st_cl_acf_field( 'field_stcl_review_count', 'count', 'Review count label', 'text' ),
							st_cl_acf_field( 'field_stcl_review_time', 'time', 'Time label', 'text' ),
							st_cl_acf_field( 'field_stcl_review_quote', 'quote', 'Quote', 'textarea', array( 'rows' => 4 ) ),
						),
					)
				),

				st_cl_acf_field( 'field_stcl_tab_guide', 'tab_guide', 'SEO body (Rank Math only — not on page)', 'tab' ),
				st_cl_acf_field( 'field_stcl_guide_eyebrow', 'st_cl_guide_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_guide_title', 'st_cl_guide_title', 'Title (use the focus keyword)', 'text' ),
				st_cl_acf_field( 'field_stcl_guide_body', 'st_cl_guide_body', 'Article copy for Rank Math (hidden from the lander layout)', 'wysiwyg', array( 'media_upload' => 0, 'toolbar' => 'basic', 'delay' => 0 ) ),

				st_cl_acf_field( 'field_stcl_tab_faq', 'tab_faq', 'FAQ', 'tab' ),
				st_cl_acf_field( 'field_stcl_faq_eyebrow', 'st_cl_faq_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_faq_title', 'st_cl_faq_title', 'Title', 'text' ),
				st_cl_acf_field(
					'field_stcl_faqs',
					'st_cl_faqs',
					'Questions',
					'repeater',
					array(
						'layout'       => 'block',
						'button_label' => 'Add question',
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_faq_q', 'question', 'Question', 'text' ),
							st_cl_acf_field( 'field_stcl_faq_a', 'answer', 'Answer', 'textarea', array( 'rows' => 3 ) ),
						),
					)
				),

				st_cl_acf_field( 'field_stcl_tab_cta', 'tab_cta', 'Bottom CTA', 'tab' ),
				st_cl_acf_field( 'field_stcl_cta_eyebrow', 'st_cl_cta_eyebrow', 'Eyebrow', 'text' ),
				st_cl_acf_field( 'field_stcl_cta_heading', 'st_cl_cta_heading', 'Heading', 'text' ),
				st_cl_acf_field( 'field_stcl_cta_text', 'st_cl_cta_text', 'Text', 'textarea', array( 'rows' => 3 ) ),
				st_cl_acf_field( 'field_stcl_cta_button', 'st_cl_cta_button', 'Button label', 'text' ),
				st_cl_acf_field( 'field_stcl_cta_bg', 'st_cl_cta_bg', 'Background image', 'image', array( 'return_format' => 'url', 'preview_size' => 'medium' ) ),
				st_cl_acf_field(
					'field_stcl_cta_checks',
					'st_cl_cta_checks',
					'Checklist',
					'repeater',
					array(
						'layout'       => 'table',
						'button_label' => 'Add item',
						'sub_fields'   => array(
							st_cl_acf_field( 'field_stcl_cta_check_text', 'text', 'Text', 'text' ),
						),
					)
				),
			),
			'location' => array(
				array(
					array(
						'param'    => 'page_template',
						'operator' => '==',
						'value'    => 'page-campaign-lander.php',
					),
				),
			),
			'menu_order'            => 0,
			'position'              => 'normal',
			'style'                 => 'default',
			'label_placement'       => 'top',
			'instruction_placement' => 'label',
			'description'           => $instructions,
			'active'                => true,
		)
	);
}
add_action( 'acf/init', 'st_lander_register_acf_fields' );
