<?php
/**
 * Sales Funnel SEO System
 *
 * Adds per-page SEO control through a WordPress admin meta box and
 * automatically outputs Open Graph, Twitter Card, and JSON-LD Schema
 * tags in the <head>.
 *
 * All outputs are guarded: if Yoast SEO or Rank Math is active the
 * theme defers entirely to those plugins.
 *
 * @package SwiftTakeoffs
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================
// A. HELPERS — DETECT ACTIVE SEO PLUGIN
// ============================================================

/**
 * Returns true if Yoast SEO or Rank Math is active and handling SEO output.
 *
 * @return bool
 */
function swift_seo_plugin_active() {
	return function_exists( 'wpseo_init' )           // Yoast SEO
		|| class_exists( 'RankMath' )                  // Rank Math
		|| class_exists( 'WPSEO_Options' )             // Yoast Premium
		|| class_exists( 'AIOSEO\Plugin\AIOSEO' )      // All in One SEO
		|| defined( 'SEOPRESS_VERSION' )               // SEOPress
		|| defined( 'THE_SEO_FRAMEWORK_VERSION' );     // The SEO Framework
}

// Load the expert-provided meta data map
require_once get_template_directory() . '/inc/seo-meta-data.php';


// ============================================================
// A2. EXPERT TITLE TAG INJECTION (document_title_parts)
// ============================================================

/**
 * Replace the WordPress <title> tag with the SEO-expert-approved title.
 *
 * Priority order:
 *   1. Per-page meta box override  (_swift_seo_title post meta)
 *   2. Expert data map             (swift_seo_get_expert_meta)
 *   3. WordPress default           (unchanged)
 *
 * @param  array $title_parts { title, page, tagline, site }
 * @return array
 */
function swift_seo_filter_title( $title_parts ) {
	if ( swift_seo_plugin_active() ) {
		return $title_parts;
	}

	// 1. Per-page meta box
	if ( is_singular() ) {
		$meta_title = get_post_meta( get_the_ID(), '_swift_seo_title', true );
		if ( $meta_title ) {
			$title_parts['title'] = $meta_title;
			unset( $title_parts['tagline'], $title_parts['site'] );
			return $title_parts;
		}
	}

	// 2. Expert data map
	$expert = swift_seo_get_current_expert_meta();
	if ( ! empty( $expert['title'] ) ) {
		$title_parts['title'] = $expert['title'];
		unset( $title_parts['tagline'], $title_parts['site'] );
	}

	return $title_parts;
}
add_filter( 'document_title_parts', 'swift_seo_filter_title', 20 );


// ============================================================
// B. META BOX — PER-PAGE SEO FIELDS
// ============================================================

/**
 * Register the Swift Takeoffs SEO meta box on pages and posts.
 */
function swift_seo_register_meta_box() {
	add_meta_box(
		'swift-seo-funnel',
		__( 'Swift Takeoffs — Page SEO & Funnel Settings', 'swift-takeoffs' ),
		'swift_seo_meta_box_html',
		array( 'page', 'post' ),
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'swift_seo_register_meta_box' );


/**
 * Render the SEO meta box HTML.
 *
 * @param WP_Post $post Current post object.
 */
function swift_seo_meta_box_html( $post ) {
	wp_nonce_field( 'swift_seo_save', 'swift_seo_nonce' );

	$seo_title    = get_post_meta( $post->ID, '_swift_seo_title',       true );
	$seo_desc     = get_post_meta( $post->ID, '_swift_seo_desc',        true );
	$seo_og_image = get_post_meta( $post->ID, '_swift_seo_og_image',    true );
	$seo_canonical= get_post_meta( $post->ID, '_swift_seo_canonical',   true );
	$seo_noindex  = get_post_meta( $post->ID, '_swift_seo_noindex',     true );
	$seo_og_type  = get_post_meta( $post->ID, '_swift_seo_og_type',     true );

	if ( swift_seo_plugin_active() ) {
		echo '<p style="color:#e67e22;font-weight:600;">';
		esc_html_e( 'Note: An SEO plugin (Yoast / Rank Math) is active. These fields are saved but the plugin controls the actual head output. Use this box as a reference only.', 'swift-takeoffs' );
		echo '</p>';
	}
	
	// Get expert data to show as placeholder if available
	$expert = swift_seo_get_current_expert_meta();
	$placeholder_title = ! empty( $expert['title'] ) ? $expert['title'] : get_the_title( $post->ID ) . ' — Swift Takeoffs';
	$placeholder_desc = ! empty( $expert['desc'] ) ? $expert['desc'] : __( 'Write a compelling description for search engines and social sharing...', 'swift-takeoffs' );

	?>
	<style>
		.swift-seo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
		.swift-seo-grid label { font-weight: 600; display: block; margin-bottom: 4px; }
		.swift-seo-grid input[type="text"],
		.swift-seo-grid input[type="url"],
		.swift-seo-grid textarea,
		.swift-seo-grid select { width: 100%; padding: 6px; border: 1px solid #ccd0d4; border-radius: 4px; }
		.swift-seo-grid textarea { height: 80px; resize: vertical; }
		.swift-seo-full { grid-column: 1 / -1; }
		.swift-seo-counter { font-size: 11px; color: #888; text-align: right; }
		.swift-seo-counter.over { color: #c0392b; font-weight: bold; }
	</style>

	<div class="swift-seo-grid">

		<div class="swift-seo-full">
			<label for="swift_seo_title"><?php esc_html_e( 'SEO Title (60 chars recommended)', 'swift-takeoffs' ); ?></label>
			<input type="text" id="swift_seo_title" name="swift_seo_title"
				value="<?php echo esc_attr( $seo_title ); ?>"
				placeholder="<?php echo esc_attr( $placeholder_title ); ?>"
				maxlength="70">
			<p class="swift-seo-counter" id="swift_seo_title_count">
				<?php echo strlen( $seo_title ); ?> / 60
			</p>
		</div>

		<div class="swift-seo-full">
			<label for="swift_seo_desc"><?php esc_html_e( 'Meta Description (150–160 chars recommended)', 'swift-takeoffs' ); ?></label>
			<textarea id="swift_seo_desc" name="swift_seo_desc"
				placeholder="<?php echo esc_attr( $placeholder_desc ); ?>"
				maxlength="200"><?php echo esc_textarea( $seo_desc ); ?></textarea>
			<p class="swift-seo-counter" id="swift_seo_desc_count">
				<?php echo strlen( $seo_desc ); ?> / 160
			</p>
		</div>

		<div>
			<label for="swift_seo_og_image"><?php esc_html_e( 'OG / Social Share Image URL', 'swift-takeoffs' ); ?></label>
			<input type="url" id="swift_seo_og_image" name="swift_seo_og_image"
				value="<?php echo esc_url( $seo_og_image ); ?>"
				placeholder="https://...">
			<p style="font-size:11px;color:#888;margin:4px 0 0;">
				<?php esc_html_e( 'Recommended: 1200 × 630 px. Used for Facebook, LinkedIn, Twitter previews.', 'swift-takeoffs' ); ?>
			</p>
		</div>

		<div>
			<label for="swift_seo_canonical"><?php esc_html_e( 'Canonical URL (optional override)', 'swift-takeoffs' ); ?></label>
			<input type="url" id="swift_seo_canonical" name="swift_seo_canonical"
				value="<?php echo esc_url( $seo_canonical ); ?>"
				placeholder="<?php echo esc_attr( get_permalink( $post->ID ) ); ?>">
		</div>

		<div>
			<label for="swift_seo_og_type"><?php esc_html_e( 'OG Type', 'swift-takeoffs' ); ?></label>
			<select id="swift_seo_og_type" name="swift_seo_og_type">
				<option value="website"  <?php selected( $seo_og_type, 'website' ); ?>><?php esc_html_e( 'Website (default)',  'swift-takeoffs' ); ?></option>
				<option value="article"  <?php selected( $seo_og_type, 'article' ); ?>><?php esc_html_e( 'Article / Blog Post', 'swift-takeoffs' ); ?></option>
				<option value="product"  <?php selected( $seo_og_type, 'product' ); ?>><?php esc_html_e( 'Product / Offer',    'swift-takeoffs' ); ?></option>
			</select>
		</div>

		<div>
			<label style="display:flex;align-items:center;gap:8px;font-weight:600;cursor:pointer;">
				<input type="checkbox" name="swift_seo_noindex" value="1" <?php checked( $seo_noindex, '1' ); ?>>
				<?php esc_html_e( 'Hide from search engines (noindex, nofollow)', 'swift-takeoffs' ); ?>
			</label>
			<p style="font-size:11px;color:#888;margin:4px 0 0;">
				<?php esc_html_e( 'Use this on funnel draft / thank-you pages until ready.', 'swift-takeoffs' ); ?>
			</p>
		</div>

	</div><!-- .swift-seo-grid -->

	<script>
	(function(){
		function counter(inputId, countId, max) {
			var el = document.getElementById(inputId);
			var ct = document.getElementById(countId);
			if (!el || !ct) return;
			function update() {
				var len = el.value.length;
				ct.textContent = len + ' / ' + max;
				ct.classList.toggle('over', len > max);
			}
			el.addEventListener('input', update);
			update();
		}
		counter('swift_seo_title', 'swift_seo_title_count', 60);
		counter('swift_seo_desc',  'swift_seo_desc_count',  160);
	})();
	</script>
	<?php
}


/**
 * Save the SEO meta box fields.
 *
 * @param int $post_id Post ID being saved.
 */
function swift_seo_save_meta( $post_id ) {
	// Security checks
	if ( ! isset( $_POST['swift_seo_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['swift_seo_nonce'] ) ), 'swift_seo_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'_swift_seo_title'     => 'sanitize_text_field',
		'_swift_seo_desc'      => 'sanitize_textarea_field',
		'_swift_seo_og_image'  => 'esc_url_raw',
		'_swift_seo_canonical' => 'esc_url_raw',
		'_swift_seo_og_type'   => 'sanitize_text_field',
	);

	foreach ( $fields as $meta_key => $sanitizer ) {
		$post_key = ltrim( $meta_key, '_' );
		if ( isset( $_POST[ $post_key ] ) ) {
			update_post_meta( $post_id, $meta_key, call_user_func( $sanitizer, wp_unslash( $_POST[ $post_key ] ) ) );
		}
	}

	// Checkbox — save 1 or delete
	if ( ! empty( $_POST['swift_seo_noindex'] ) ) {
		update_post_meta( $post_id, '_swift_seo_noindex', '1' );
	} else {
		delete_post_meta( $post_id, '_swift_seo_noindex' );
	}
}
add_action( 'save_post', 'swift_seo_save_meta' );


// ============================================================
// C. FRONTEND <HEAD> OUTPUT
// ============================================================

/**
 * Output all SEO tags in <head> for the current page.
 * Fully skipped if Yoast or Rank Math is active.
 */
function swift_seo_output_head_tags() {
	if ( swift_seo_plugin_active() ) {
		return; // Let the SEO plugin handle everything
	}

	$post_id = is_singular() ? get_the_ID() : null;

	// ── Gather Values — priority: meta box → expert map → fallback ──

	// Per-page meta box values (only on singular pages)
	$meta_title    = $post_id ? get_post_meta( $post_id, '_swift_seo_title',     true ) : '';
	$meta_desc     = $post_id ? get_post_meta( $post_id, '_swift_seo_desc',      true ) : '';
	$meta_og_image = $post_id ? get_post_meta( $post_id, '_swift_seo_og_image',  true ) : '';
	$meta_canonical= $post_id ? get_post_meta( $post_id, '_swift_seo_canonical', true ) : '';
	$meta_og_type  = $post_id ? get_post_meta( $post_id, '_swift_seo_og_type',   true ) : '';
	$noindex       = $post_id ? get_post_meta( $post_id, '_swift_seo_noindex',   true ) : '';

	// Expert data map
	$expert = swift_seo_get_current_expert_meta();

	// Resolve with priority: meta box > expert > fallback
	if ( $meta_title ) {
		$title = $meta_title;
	} elseif ( ! empty( $expert['title'] ) ) {
		$title = $expert['title'];
	} else {
		$title = is_singular() ? get_the_title() . ' — ' . get_bloginfo( 'name' ) : get_bloginfo( 'name' );
	}

	if ( $meta_desc ) {
		$desc = $meta_desc;
	} elseif ( ! empty( $expert['desc'] ) ) {
		$desc = $expert['desc'];
	} else {
		$desc = is_singular() ? wp_strip_all_tags( get_the_excerpt() ) : get_bloginfo( 'description' );
	}

	if ( $meta_og_image ) {
		$og_image = $meta_og_image;
	} elseif ( $post_id && has_post_thumbnail( $post_id ) ) {
		$og_image = get_the_post_thumbnail_url( $post_id, 'large' );
	} else {
		$og_image = '';
	}

	$canonical = $meta_canonical ? $meta_canonical : ( is_singular() ? get_permalink( $post_id ) : '' );
	if ( ! $canonical ) {
		$canonical = home_url( add_query_arg( null, null ) );
	}

	$og_type   = $meta_og_type   ? $meta_og_type   : ( is_singular( 'post' ) ? 'article' : 'website' );
	$site_name = get_bloginfo( 'name' );
	$url       = is_singular() ? get_permalink( $post_id ) : home_url( add_query_arg( null, null ) );

	// ── Robots ───────────────────────────────────────────────
	if ( $noindex ) {
		echo '<meta name="robots" content="noindex, nofollow">' . "\n";
	}

	// ── Meta Description ─────────────────────────────────────
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}

	// ── Canonical ────────────────────────────────────────────
	echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";

	// ── Open Graph ───────────────────────────────────────────
	echo '<meta property="og:type"        content="' . esc_attr( $og_type ) . '">' . "\n";
	echo '<meta property="og:title"       content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:site_name"   content="' . esc_attr( $site_name ) . '">' . "\n";
	echo '<meta property="og:url"         content="' . esc_url( $url ) . '">' . "\n";

	if ( $desc ) {
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	if ( $og_image ) {
		echo '<meta property="og:image"        content="' . esc_url( $og_image ) . '">' . "\n";
		echo '<meta property="og:image:width"  content="1200">' . "\n";
		echo '<meta property="og:image:height" content="630">' . "\n";
	}

	// ── Twitter / X Card ─────────────────────────────────────
	echo '<meta name="twitter:card"        content="' . ( $og_image ? 'summary_large_image' : 'summary' ) . '">' . "\n";
	echo '<meta name="twitter:title"       content="' . esc_attr( $title ) . '">' . "\n";
	if ( $desc ) {
		echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	if ( $og_image ) {
		echo '<meta name="twitter:image"       content="' . esc_url( $og_image ) . '">' . "\n";
	}

	// ── Funnel / Sales Page JSON-LD Schema ───────────────────
	swift_seo_funnel_schema( $post_id, $title, $desc, $url, $og_image );
}
add_action( 'wp_head', 'swift_seo_output_head_tags', 3 );


// ============================================================
// D. DEFAULT OG IMAGE HELPER
// ============================================================

/**
 * Get the default OG image URL.
 * Checks (in order): Customizer setting → theme logo → empty string.
 *
 * @return string
 */
function swift_seo_default_og_image() {
	$custom = get_theme_mod( 'swift_default_og_image', '' );
	if ( $custom ) {
		return esc_url( $custom );
	}
	// Fallback: use custom logo attachment URL
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$logo_src = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $logo_src ) {
			return $logo_src;
		}
	}
	return '';
}


// ============================================================
// E. RICH JSON-LD SCHEMA ENGINE
// ============================================================

/**
 * Output the correct JSON-LD schema for the current page type.
 *
 * Schema types output:
 *   - Front page          → LocalBusiness + WebSite + WebPage
 *   - About page          → AboutPage
 *   - Contact page        → ContactPage
 *   - Service CPT single  → Service
 *   - Trade CPT single    → Service (trade variant)
 *   - Blog post           → Article
 *   - Landing / funnel    → WebPage + Service
 *   - All other pages     → WebPage
 *   - CPT Archives        → CollectionPage
 *
 * @param int|null $post_id  Current post ID (null for archives).
 * @param string $title    Resolved SEO title.
 * @param string $desc     Resolved SEO description.
 * @param string $url      Current page URL.
 * @param string $og_image OG image URL (may be empty).
 */
function swift_seo_funnel_schema( $post_id, $title, $desc, $url, $og_image ) {
	$business  = get_bloginfo( 'name' );
	$phone     = get_theme_mod( 'swift_phone', '678-825-6967' );
	$email     = get_theme_mod( 'swift_email', 'info@swifttakeoffs.com' );
	$address   = get_theme_mod( 'swift_address', '8 The Green #6092, Dover, 19901' );
	$logo      = get_template_directory_uri() . '/assets/images/logoheader.png';
	$home      = home_url( '/' );
	$image_url = $og_image ? $og_image : swift_seo_default_og_image();

	// Shared LocalBusiness block — reused in multiple schemas
	$local_business = array(
		'@type'     => 'LocalBusiness',
		'name'      => $business,
		'url'       => $home,
		'logo'      => $logo,
		'image'     => $image_url,
		'telephone' => $phone,
		'email'     => $email,
		'address'   => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => $address,
			'addressCountry'  => 'US',
		),
		'priceRange' => '$$',
		'areaServed' => 'US',
	);

	$schemas = array(); // will collect all schema blocks to output

	// ── 1. Site-wide: LocalBusiness + WebSite (output on every page) ──
	$schemas[] = array_merge(
		array(
			'@context' => 'https://schema.org',
		),
		$local_business
	);

	$schemas[] = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'WebSite',
		'name'            => $business,
		'url'             => $home,
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => array(
				'@type'       => 'EntryPoint',
				'urlTemplate' => $home . '?s={search_term_string}',
			),
			'query-input' => 'required name=search_term_string',
		),
	);

	// ── 2. Page-specific schema ───────────────────────────────────────
	$post_type = $post_id ? get_post_type( $post_id ) : '';
	$template  = $post_id ? get_page_template_slug( $post_id ) : '';
	$is_funnel = in_array(
		$template,
		array(
			'page-swift-takeoffs-landing.php',
			'page-get-a-quote.php',
			'page-drywall-estimating-landing.php',
			'page-campaign-lander.php',
		),
		true
	);

	if ( is_front_page() ) {
		// Homepage: WebPage with breadcrumb
		$schemas[] = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'WebPage',
			'name'        => $title,
			'description' => $desc,
			'url'         => $url,
			'isPartOf'    => array( '@type' => 'WebSite', 'url' => $home ),
		);

	} elseif ( is_page( array( 'about', 'about-us' ) ) ) {
		$schemas[] = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'AboutPage',
			'name'        => $title,
			'description' => $desc,
			'url'         => $url,
			'isPartOf'    => array( '@type' => 'WebSite', 'name' => $business, 'url' => $home ),
		);

	} elseif ( is_page( array( 'contact', 'contact-us' ) ) ) {
		$schemas[] = array(
			'@context'     => 'https://schema.org',
			'@type'        => 'ContactPage',
			'name'         => $title,
			'description'  => $desc,
			'url'          => $url,
			'contactPoint' => array(
				'@type'             => 'ContactPoint',
				'telephone'         => $phone,
				'contactType'       => 'customer service',
				'email'             => $email,
				'availableLanguage' => 'English',
			),
		);

	} elseif ( 'service' === $post_type && is_singular( 'service' ) ) {
		$post_desc = $desc ? $desc : wp_strip_all_tags( get_the_excerpt() );
		$schemas[] = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'Service',
			'name'        => $title,
			'description' => $post_desc,
			'url'         => $url,
			'provider'    => $local_business,
			'areaServed'  => 'US',
		);

	} elseif ( 'trade' === $post_type && is_singular( 'trade' ) ) {
		$post_desc  = $desc ? $desc : wp_strip_all_tags( get_the_excerpt() );
		$trade_name = get_the_title( $post_id ) . ' Estimating Services';
		$schemas[]  = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'Service',
			'name'        => $trade_name,
			'description' => $post_desc,
			'url'         => $url,
			'provider'    => $local_business,
			'areaServed'  => 'US',
			'serviceType' => 'Construction Estimating',
		);

	} elseif ( is_singular( 'post' ) ) {
		// Blog post Article schema
		$author_id = get_post_field( 'post_author', $post_id );
		$schemas[] = array(
			'@context'         => 'https://schema.org',
			'@type'            => 'Article',
			'headline'         => $title,
			'description'      => $desc,
			'url'              => $url,
			'datePublished'    => get_the_date( 'c', $post_id ),
			'dateModified'     => get_the_modified_date( 'c', $post_id ),
			'author'           => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', $author_id ),
			),
			'publisher'        => $local_business,
			'image'            => $image_url,
		);

	} elseif ( $is_funnel ) {
		// Landing / quote funnel — WebPage + Service combo
		$schemas[] = array(
			'@context'    => 'https://schema.org',
			'@type'       => array( 'WebPage', 'Service' ),
			'name'        => $title,
			'description' => $desc,
			'url'         => $url,
			'provider'    => $local_business,
			'image'       => $image_url,
		);

	} elseif ( is_post_type_archive( 'trade' ) || is_post_type_archive( 'service' ) ) {
		// CPT Archive pages
		$schemas[] = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'CollectionPage',
			'name'        => $title,
			'description' => $desc,
			'url'         => $url,
			'isPartOf'    => array( '@type' => 'WebSite', 'name' => $business, 'url' => $home ),
		);

	} else {
		// All other pages: generic WebPage
		$schemas[] = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'WebPage',
			'name'        => $title,
			'description' => $desc,
			'url'         => $url,
			'isPartOf'    => array( '@type' => 'WebSite', 'name' => $business, 'url' => $home ),
		);
	}

	// Output all schema blocks
	foreach ( $schemas as $schema ) {
		if ( ! empty( $schema ) ) {
			echo '<script type="application/ld+json">'
				. wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
				. '</script>' . "\n";
		}
	}
}


// ============================================================
// F. BREADCRUMB JSON-LD SCHEMA
// ============================================================

/**
 * Output BreadcrumbList JSON-LD schema on singular pages.
 * Skipped if an SEO plugin handles breadcrumbs.
 */
function swift_seo_breadcrumb_schema() {
	if ( swift_seo_plugin_active() ) {
		return;
	}

	if ( ! is_singular() ) {
		return;
	}

	$items = array(
		array(
			'@type'    => 'ListItem',
			'position' => 1,
			'name'     => __( 'Home', 'swift-takeoffs' ),
			'item'     => home_url( '/' ),
		),
	);

	// If it is a CPT post add a middle crumb for the archive
	$post_type = get_post_type();
	if ( 'page' !== $post_type && 'post' !== $post_type ) {
		$archive_label = array(
			'trade'   => 'Trades',
			'service' => 'Services',
		);
		$archive_url = get_post_type_archive_link( $post_type );
		if ( $archive_url ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => 2,
				'name'     => isset( $archive_label[ $post_type ] ) ? $archive_label[ $post_type ] : ucfirst( $post_type ),
				'item'     => $archive_url,
			);
		}
	} elseif ( 'post' === $post_type ) {
		$blog_url = get_permalink( get_option( 'page_for_posts' ) );
		if ( $blog_url ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => 2,
				'name'     => __( 'Blog', 'swift-takeoffs' ),
				'item'     => $blog_url,
			);
		}
	}

	$items[] = array(
		'@type'    => 'ListItem',
		'position' => count( $items ) + 1,
		'name'     => get_the_title(),
		'item'     => get_permalink(),
	);

	$schema = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $items,
	);

	echo '<script type="application/ld+json">'
		. wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
		. '</script>' . "\n";
}
add_action( 'wp_head', 'swift_seo_breadcrumb_schema', 4 );
