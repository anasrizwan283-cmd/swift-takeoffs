<?php
/**
 * Service Custom Post Type Registration
 *
 * Registers the 'service' CPT.
 * Included from functions.php.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================
// REGISTER 'SERVICE' CUSTOM POST TYPE
// ============================================================

function swift_takeoffs_register_service_cpt() {

	$labels = array(
		'name'                  => _x( 'Services', 'Post type general name', 'swift-takeoffs' ),
		'singular_name'         => _x( 'Service', 'Post type singular name', 'swift-takeoffs' ),
		'menu_name'             => _x( 'Services', 'Admin Menu text', 'swift-takeoffs' ),
		'name_admin_bar'        => _x( 'Service', 'Add New on Toolbar', 'swift-takeoffs' ),
		'add_new'               => __( 'Add New Service', 'swift-takeoffs' ),
		'add_new_item'          => __( 'Add New Service', 'swift-takeoffs' ),
		'new_item'              => __( 'New Service', 'swift-takeoffs' ),
		'edit_item'             => __( 'Edit Service', 'swift-takeoffs' ),
		'view_item'             => __( 'View Service', 'swift-takeoffs' ),
		'all_items'             => __( 'All Services', 'swift-takeoffs' ),
		'search_items'          => __( 'Search Services', 'swift-takeoffs' ),
		'not_found'             => __( 'No services found.', 'swift-takeoffs' ),
		'not_found_in_trash'    => __( 'No services found in Trash.', 'swift-takeoffs' ),
		'featured_image'        => __( 'Service Banner Image', 'swift-takeoffs' ),
		'set_featured_image'    => __( 'Set banner image', 'swift-takeoffs' ),
		'remove_featured_image' => __( 'Remove banner image', 'swift-takeoffs' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array(
			'slug'       => 'services',
			'with_front' => false,
		),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 6,
		'menu_icon'          => 'dashicons-clipboard',
		'supports'           => array(
			'title',
			'editor',
			'thumbnail',
			'excerpt',
			'page-attributes', // Enables Order field (menu_order) for nav/archive sorting
		),
		'show_in_rest'       => true,
	);

	register_post_type( 'service', $args );
}
add_action( 'init', 'swift_takeoffs_register_service_cpt' );


// ============================================================
// FLUSH REWRITE RULES ON THEME SWITCH
// ============================================================

function swift_takeoffs_flush_service_rewrite() {
	swift_takeoffs_register_service_cpt();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'swift_takeoffs_flush_service_rewrite' );


// ============================================================
// HELPER: GET ALL PUBLISHED SERVICES (used in sidebar)
// ============================================================

function swift_takeoffs_get_all_services( $limit = 6 ) {
	return get_posts(
		array(
			'post_type'      => 'service',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
		)
	);
}
