<?php
/**
 * SEO Expert Meta Data — Swift Takeoffs
 *
 * Contains the SEO-expert-approved Meta Titles and Meta Descriptions
 * for every URL on the site. These are automatically applied to the
 * correct page based on the current request URL.
 *
 * Priority order (highest → lowest):
 *   1. Per-page override saved in the admin meta box (_swift_seo_title / _swift_seo_desc)
 *   2. This expert-provided data map (loaded below)
 *   3. Generic fallback (page title + site description)
 *
 * To add / update entries:  edit the array in swift_seo_get_expert_data().
 * Keys = relative URL path (no domain, always trailing-slash).
 *
 * @package SwiftTakeoffs
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Returns the full map of SEO-expert-provided meta titles and descriptions.
 * Array key = URL path (relative, trailing-slash normalised).
 *
 * @return array<string, array{title: string, desc: string}>
 */
function swift_seo_get_expert_data() {
    return array(

        // ── Core Pages ───────────────────────────────────────────────────
        '/' => array(
            'title' => 'Construction Estimating & Takeoff Services | Swift Takeoffs',
            'desc'  => 'Get accurate construction estimating and material takeoff services for residential and commercial projects. Save time, reduce costs, and bid with confidence.',
        ),
        '/about-us/' => array(
            'title' => 'About Swift Takeoffs | Construction Estimating Experts',
            'desc'  => 'Learn about Swift Takeoffs, our experienced estimating professionals, and our commitment to delivering accurate construction takeoff services nationwide.',
        ),
        '/contact-us/' => array(
            'title' => 'Contact Swift Takeoffs | Get in Touch Today',
            'desc'  => 'Contact Swift Takeoffs for expert construction estimating and material takeoff services. We\'re ready to answer your questions and support your projects.',
        ),
        '/get-a-quote/' => array(
            'title' => 'Get a Construction Estimating Quote | Swift Takeoffs',
            'desc'  => 'Request a fast, accurate quote for construction estimating and material takeoff services. Submit your plans and receive a customized estimate today.',
        ),
        '/privacy-policy/' => array(
            'title' => 'Privacy Policy | Swift Takeoffs',
            'desc'  => 'Read the Swift Takeoffs Privacy Policy to learn how we collect, use, protect, and manage your personal information when using our website and services.',
        ),
        '/terms-and-conditions/' => array(
            'title' => 'Terms and Conditions | Swift Takeoffs',
            'desc'  => 'Review the Swift Takeoffs Terms and Conditions to understand the rules, service policies, and responsibilities for using our website and services.',
        ),

        // ── Blog / Category ──────────────────────────────────────────────
        '/blog/' => array(
            'title' => 'Construction Takeoff Blog & Estimating Tips | Swift',
            'desc'  => 'Read expert articles on construction estimating, material takeoffs, cost planning, and bidding strategies to make smarter project decisions.',
        ),
        '/category/blog/' => array(
            'title' => 'Construction Estimating Blog | Swift Takeoffs',
            'desc'  => 'Explore construction estimating guides, material takeoff tips, bidding strategies, and industry insights to improve planning and project success.',
        ),

        // ── Landing Pages ────────────────────────────────────────────────
        '/lp-a/' => array(
            'title' => 'Construction Estimating Services | Swift Takeoffs',
            'desc'  => 'Get accurate construction estimating and material takeoff services for residential and commercial projects. Request a fast, reliable quote today.',
        ),
        '/drywall-estimating/' => array(
            'title' => 'Drywall Estimating Services | Swift Takeoffs',
            'desc'  => 'Get accurate drywall estimating and material takeoff services for commercial and residential projects. Fast turnaround, bid-ready quantities.',
        ),

        // ── Blog Post / Article ──────────────────────────────────────────
        '/construction-estimating-services-to-control-costs/' => array(
            'title' => 'Construction Estimating Services to Control Costs',
            'desc'  => 'Learn how professional construction estimating services help control project costs, reduce waste, improve budgeting, and increase bidding accuracy.',
        ),

        // ── Services Archive & Singles ────────────────────────────────────
        '/services/' => array(
            'title' => 'Construction Estimating Services | Swift Takeoffs',
            'desc'  => 'Explore professional construction estimating and material takeoff services designed to improve bid accuracy, reduce costs, and support successful projects.',
        ),
        '/services/preliminary-estimating-services/' => array(
            'title' => 'Preliminary Estimating Services | Swift Takeoffs',
            'desc'  => 'Get accurate preliminary estimating services for early project planning, budgeting, and feasibility studies with reliable cost projections.',
        ),
        '/services/industrial-estimating-services/' => array(
            'title' => 'Industrial Estimating Services | Swift Takeoffs',
            'desc'  => 'Professional industrial estimating services with detailed material takeoffs and cost estimates for manufacturing, warehouses, and industrial facilities.',
        ),
        '/services/commercial-estimating-services/' => array(
            'title' => 'Commercial Estimating Services | Swift Takeoffs',
            'desc'  => 'Accurate commercial estimating services for offices, retail, healthcare, and mixed-use projects with detailed quantity takeoffs and cost estimates.',
        ),
        '/services/residential-estimating-services/' => array(
            'title' => 'Residential Estimating Services | Swift Takeoffs',
            'desc'  => 'Reliable residential estimating services for custom homes, renovations, and multi-family projects with precise material takeoffs and budgeting.',
        ),
        '/services/material-takeoff-services/' => array(
            'title' => 'Material Takeoff Services | Swift Takeoffs',
            'desc'  => 'Get detailed material takeoff services for construction projects to improve purchasing, reduce waste, and submit more competitive bids.',
        ),
        '/services/cost-estimating-services/' => array(
            'title' => 'Cost Estimating Services | Swift Takeoffs',
            'desc'  => 'Receive accurate construction cost estimating services with detailed pricing, quantity takeoffs, and budget planning for every project.',
        ),
        '/services/subcontractor-estimating-services/' => array(
            'title' => 'Subcontractor Estimating Services | Swift Takeoffs',
            'desc'  => 'Expert subcontractor estimating services with accurate quantity takeoffs to help subcontractors win more bids and improve project profitability.',
        ),
        '/services/gc-estimating-services/' => array(
            'title' => 'General Contractor Estimating | Swift Takeoffs',
            'desc'  => 'Professional estimating services for general contractors with accurate material takeoffs, budgeting, and competitive bid preparation.',
        ),

        // ── Trades Archive & Singles ──────────────────────────────────────
        '/trades/' => array(
            'title' => 'Construction Trade Estimating Services | Swift Takeoffs',
            'desc'  => 'Explore professional estimating and material takeoff services for all construction trades. Improve bid accuracy and complete projects with confidence.',
        ),
        '/trades/masonry-estimating-services/' => array(
            'title' => 'Masonry Estimating Services | Swift Takeoffs',
            'desc'  => 'Receive accurate masonry estimating services for brick, block, stone, and concrete projects. Bid confidently with detailed quantity takeoffs.',
        ),
        '/trades/concrete-estimating-services/' => array(
            'title' => 'Concrete Estimating Services | Swift Takeoffs',
            'desc'  => 'Get precise concrete estimating and quantity takeoff services for residential, commercial, and industrial construction projects.',
        ),
        '/trades/existing-conditions-estimating/' => array(
            'title' => 'Existing Conditions Estimating | Swift Takeoffs',
            'desc'  => 'Accurate existing conditions estimating services to identify site requirements, renovation needs, and project costs before construction begins.',
        ),
        '/trades/metals-estimating-services/' => array(
            'title' => 'Metals Estimating Services | Swift Takeoffs',
            'desc'  => 'Professional metals estimating services for structural steel, metal framing, and fabrication projects with detailed quantity takeoffs.',
        ),
        '/trades/wood-plastics-and-composites/' => array(
            'title' => 'Wood, Plastics & Composites Estimating | Swift',
            'desc'  => 'Accurate estimating services for wood, plastics, and composite materials to improve project planning, budgeting, and bid accuracy.',
        ),
        '/trades/thermal-and-moisture-protection/' => array(
            'title' => 'Thermal & Moisture Protection Estimating | Swift',
            'desc'  => 'Expert estimating services for insulation, waterproofing, roofing, and moisture protection systems with reliable quantity takeoffs.',
        ),
        '/trades/openings-estimating-services/' => array(
            'title' => 'Openings Estimating Services | Swift Takeoffs',
            'desc'  => 'Get precise estimating services for doors, windows, frames, glass, and hardware with detailed material takeoffs and cost estimates.',
        ),
        '/trades/finishes-estimating-services/' => array(
            'title' => 'Finishes Estimating Services | Swift Takeoffs',
            'desc'  => 'Professional estimating services for flooring, drywall finishes, ceilings, painting, and interior finish materials with accurate takeoffs.',
        ),
        '/trades/specialties-estimating-services/' => array(
            'title' => 'Specialties Estimating Services | Swift Takeoffs',
            'desc'  => 'Reliable specialties estimating services for construction projects with accurate material takeoffs and detailed cost estimates.',
        ),
        '/trades/equipment-estimating-services/' => array(
            'title' => 'Equipment Estimating Services | Swift Takeoffs',
            'desc'  => 'Accurate equipment estimating services for construction projects with reliable quantity takeoffs and detailed cost planning.',
        ),
        '/trades/furnishings-estimating-services/' => array(
            'title' => 'Furnishings Estimating Services | Swift Takeoffs',
            'desc'  => 'Professional furnishings estimating services for cabinets, fixtures, furniture, and interior elements with accurate material takeoffs.',
        ),
        '/trades/special-construction-estimating-services/' => array(
            'title' => 'Special Construction Estimating | Swift Takeoffs',
            'desc'  => 'Expert estimating services for specialty construction projects with detailed material takeoffs, budgeting, and accurate cost estimates.',
        ),
        '/trades/conveying-equipment-estimating-services/' => array(
            'title' => 'Conveying Equipment Estimating | Swift Takeoffs',
            'desc'  => 'Accurate conveying equipment estimating services for elevators, lifts, escalators, and related systems with reliable quantity takeoffs.',
        ),
        '/trades/mechanical-support-estimating-services/' => array(
            'title' => 'Mechanical Support Estimating | Swift Takeoffs',
            'desc'  => 'Professional mechanical support estimating services with detailed quantity takeoffs to improve budgeting and bid accuracy.',
        ),
        '/trades/fire-suppression-estimating-services/' => array(
            'title' => 'Fire Suppression Estimating | Swift Takeoffs',
            'desc'  => 'Expert fire suppression estimating services for sprinkler and fire protection systems with accurate material takeoffs and costs.',
        ),
        '/trades/plumbing-estimating-services/' => array(
            'title' => 'Plumbing Estimating Services | Swift Takeoffs',
            'desc'  => 'Get accurate plumbing estimating services with detailed pipe, fixture, and material takeoffs for residential and commercial projects.',
        ),
        '/trades/heating-ventilating-and-air-conditioning-hvac-estimating-services/' => array(
            'title' => 'HVAC Estimating Services | Swift Takeoffs',
            'desc'  => 'Professional HVAC estimating services with accurate ductwork, equipment, and material takeoffs for efficient project bidding.',
        ),
        '/trades/electrical-estimating-services/' => array(
            'title' => 'Electrical Estimating Services | Swift Takeoffs',
            'desc'  => 'Receive accurate electrical estimating services with detailed material takeoffs for commercial, residential, and industrial projects.',
        ),
        '/trades/earthwork-estimating-services/' => array(
            'title' => 'Earthwork Estimating Services | Swift Takeoffs',
            'desc'  => 'Expert earthwork estimating services for excavation, grading, and site preparation with accurate quantity takeoffs and cost estimates.',
        ),
        '/trades/exterior-improvements-estimating-services/' => array(
            'title' => 'Exterior Improvements Estimating | Swift Takeoffs',
            'desc'  => 'Professional estimating services for paving, landscaping, fencing, and exterior improvements with reliable quantity takeoffs.',
        ),
        '/trades/utilities-estimating-services/' => array(
            'title' => 'Utilities Estimating Services | Swift Takeoffs',
            'desc'  => 'Accurate utilities estimating services for water, sewer, drainage, and underground utility projects with detailed material takeoffs.',
        ),

    );
}


/**
 * Look up the SEO expert meta data for the current request URL.
 *
 * Strips the home URL, normalises trailing slashes, and returns the
 * matching entry or an empty array when no match is found.
 *
 * @return array{title?: string, desc?: string}
 */
function swift_seo_get_current_expert_meta() {
    $home = home_url( '/' );
    $url  = '';

    if ( is_singular() ) {
        $url = get_permalink();
    } elseif ( is_post_type_archive() ) {
        $url = get_post_type_archive_link( get_post_type() );
    } elseif ( is_home() ) {
        $url = get_permalink( get_option( 'page_for_posts' ) );
    } elseif ( is_front_page() ) {
        $url = $home;
    }

    if ( ! $url ) {
        // Fallback for weird edge cases, strip query string immediately
        $url = home_url( strtok( $_SERVER['REQUEST_URI'] ?? '', '?' ) );
    }

    // Build a clean relative path
    $path = str_replace( untrailingslashit( $home ), '', $url );
    $path = '/' . ltrim( $path, '/' );           // ensure leading slash
    $path = trailingslashit( $path );            // ensure trailing slash
    $path = strtolower( $path );                 // normalise case

    $data = swift_seo_get_expert_data();

    return isset( $data[ $path ] ) ? $data[ $path ] : array();
}
