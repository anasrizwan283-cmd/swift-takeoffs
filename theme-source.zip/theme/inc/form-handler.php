<?php
/**
 * Custom Form Handler for Swift Takeoffs
 * Unifies all frontend forms (Home, Contact, Get a Quote)
 * Sends email and stores submissions in the Admin Panel as a Custom Post Type.
 */

// 1. Register Leads Custom Post Type
function swift_register_leads_cpt() {
    $labels = array(
        'name'                  => _x( 'Leads', 'Post Type General Name', 'swift-takeoffs' ),
        'singular_name'         => _x( 'Lead', 'Post Type Singular Name', 'swift-takeoffs' ),
        'menu_name'             => __( 'Form Leads', 'swift-takeoffs' ),
        'all_items'             => __( 'All Leads', 'swift-takeoffs' ),
        'view_item'             => __( 'View Lead', 'swift-takeoffs' ),
        'search_items'          => __( 'Search Leads', 'swift-takeoffs' ),
        'not_found'             => __( 'No leads found', 'swift-takeoffs' ),
    );
    $args = array(
        'label'                 => __( 'Lead', 'swift-takeoffs' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'custom-fields' ), // Enable custom fields metabox
        'public'                => false, // Private CPT, only visible in admin
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 25,
        'menu_icon'             => 'dashicons-email-alt',
        'show_in_admin_bar'     => false,
        'show_in_nav_menus'     => false,
        'can_export'            => true,
        'has_archive'           => false,
        'exclude_from_search'   => true,
        'publicly_queryable'    => false,
        'capability_type'       => 'post',
        'capabilities' => array(
            'create_posts' => 'do_not_allow', // Prevents manual creation of leads via admin UI
        ),
        'map_meta_cap' => true,
    );
    register_post_type( 'swift_lead', $args );
}
add_action( 'init', 'swift_register_leads_cpt' );

/**
 * Verify reCAPTCHA v3 token with Google.
 *
 * @param string $token reCAPTCHA response token.
 * @return bool
 */
function swift_takeoffs_verify_recaptcha( $token ) {
    if ( empty( $token ) ) {
        return false;
    }

    $response = wp_remote_post(
        'https://www.google.com/recaptcha/api/siteverify',
        array(
            'body' => array(
                'secret'   => swift_takeoffs_get_recaptcha_secret_key(),
                'response' => sanitize_text_field( $token ),
            ),
        )
    );

    if ( is_wp_error( $response ) ) {
        return false;
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    return isset( $body['success'] ) && $body['success'] && isset( $body['score'] ) && $body['score'] >= 0.5;
}

/**
 * Collect and sanitize lead fields from $_POST (shared by redirect + AJAX handlers).
 *
 * @return array{name:string,email:string,phone:string,message:string,company:string,scope:string,utm_source:string,utm_medium:string,utm_campaign:string,utm_content:string,utm_term:string,gclid:string,landing_page:string,lead_funnel:string,source:string,sms_consent:string}
 */
function swift_collect_lead_fields_from_request() {
	$name = isset( $_POST['quote_name'] ) ? sanitize_text_field( wp_unslash( $_POST['quote_name'] ) ) : ( isset( $_POST['contact_name'] ) ? sanitize_text_field( wp_unslash( $_POST['contact_name'] ) ) : ( isset( $_POST['fq_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fq_name'] ) ) : '' ) );
	$email = isset( $_POST['quote_email'] ) ? sanitize_email( wp_unslash( $_POST['quote_email'] ) ) : ( isset( $_POST['contact_email'] ) ? sanitize_email( wp_unslash( $_POST['contact_email'] ) ) : ( isset( $_POST['fq_email'] ) ? sanitize_email( wp_unslash( $_POST['fq_email'] ) ) : '' ) );
	$phone = isset( $_POST['quote_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['quote_phone'] ) ) : ( isset( $_POST['contact_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['contact_phone'] ) ) : ( isset( $_POST['fq_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['fq_phone'] ) ) : '' ) );
	$message = isset( $_POST['quote_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['quote_message'] ) ) : ( isset( $_POST['contact_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['contact_message'] ) ) : ( isset( $_POST['fq_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fq_message'] ) ) : '' ) );
	$company = isset( $_POST['quote_company'] ) ? sanitize_text_field( wp_unslash( $_POST['quote_company'] ) ) : ( isset( $_POST['fq_company'] ) ? sanitize_text_field( wp_unslash( $_POST['fq_company'] ) ) : '' );
	$scope = isset( $_POST['fq_scope'] ) ? sanitize_text_field( wp_unslash( $_POST['fq_scope'] ) ) : '';

	// Landing hero extras → fold into scope/message when present.
	$trades = isset( $_POST['trades'] ) ? sanitize_text_field( wp_unslash( $_POST['trades'] ) ) : '';
	$level  = isset( $_POST['takeoff_level'] ) ? sanitize_text_field( wp_unslash( $_POST['takeoff_level'] ) ) : ( isset( $_POST['level_type'] ) ? sanitize_text_field( wp_unslash( $_POST['level_type'] ) ) : '' );
	if ( $trades && ! $scope ) {
		$scope = $trades;
	}
	$extra_bits = array();
	if ( $trades ) {
		$extra_bits[] = 'Trades: ' . $trades;
	}
	if ( $level ) {
		$extra_bits[] = 'Level: ' . $level;
	}
	if ( ! empty( $_POST['service_type'] ) ) {
		$extra_bits[] = 'Service: ' . sanitize_text_field( wp_unslash( $_POST['service_type'] ) );
	}
	if ( ! empty( $_POST['project_name'] ) ) {
		$extra_bits[] = 'Project: ' . sanitize_text_field( wp_unslash( $_POST['project_name'] ) );
	}
	if ( ! empty( $_POST['project_type'] ) ) {
		$extra_bits[] = 'Project type: ' . sanitize_text_field( wp_unslash( $_POST['project_type'] ) );
	}
	if ( ! empty( $_POST['plan_link'] ) ) {
		$extra_bits[] = 'Plan link: ' . esc_url_raw( wp_unslash( $_POST['plan_link'] ) );
	}
	if ( $extra_bits ) {
		$extra = implode( ' | ', $extra_bits );
		$message = $message ? ( $message . "\n" . $extra ) : $extra;
	}

	return array(
		'name'         => $name,
		'email'        => $email,
		'phone'        => $phone,
		'message'      => $message,
		'company'      => $company,
		'scope'        => $scope,
		'utm_source'   => isset( $_POST['utm_source'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_source'] ) ) : '',
		'utm_medium'   => isset( $_POST['utm_medium'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_medium'] ) ) : '',
		'utm_campaign' => isset( $_POST['utm_campaign'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_campaign'] ) ) : '',
		'utm_content'  => isset( $_POST['utm_content'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_content'] ) ) : '',
		'utm_term'     => isset( $_POST['utm_term'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_term'] ) ) : '',
		'gclid'        => isset( $_POST['gclid'] ) ? sanitize_text_field( wp_unslash( $_POST['gclid'] ) ) : '',
		'landing_page' => isset( $_POST['landing_page'] ) ? esc_url_raw( wp_unslash( $_POST['landing_page'] ) ) : '',
		'lead_funnel'  => isset( $_POST['lead_funnel'] ) ? sanitize_text_field( wp_unslash( $_POST['lead_funnel'] ) ) : '',
		'source'       => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : 'Direct',
		'sms_consent'  => ! empty( $_POST['sms_consent'] ) ? 'Yes' : 'No',
	);
}

/**
 * Persist lead + email admin. Returns post ID or WP_Error.
 *
 * @param array $data From swift_collect_lead_fields_from_request().
 * @return int|WP_Error
 */
function swift_store_lead_and_notify( $data ) {
	$name = $data['name'];
	if ( '' === $name || '' === $data['email'] ) {
		return new WP_Error( 'missing_fields', __( 'Name and email are required.', 'swift-takeoffs' ) );
	}

	$post_id = wp_insert_post(
		array(
			'post_title'  => 'Lead: ' . $name . ' (' . current_time( 'Y-m-d H:i' ) . ')',
			'post_type'   => 'swift_lead',
			'post_status' => 'publish',
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}

	update_post_meta( $post_id, 'Name', $data['name'] );
	update_post_meta( $post_id, 'Email', $data['email'] );
	update_post_meta( $post_id, 'Phone', $data['phone'] );
	if ( ! empty( $data['company'] ) ) {
		update_post_meta( $post_id, 'Company', $data['company'] );
	}
	if ( ! empty( $data['scope'] ) ) {
		update_post_meta( $post_id, 'Scope', $data['scope'] );
	}
	update_post_meta( $post_id, 'Message', $data['message'] );
	update_post_meta( $post_id, 'Source URL', $data['source'] );
	if ( $data['utm_source'] ) {
		update_post_meta( $post_id, 'UTM Source', $data['utm_source'] );
	}
	if ( $data['utm_medium'] ) {
		update_post_meta( $post_id, 'UTM Medium', $data['utm_medium'] );
	}
	if ( $data['utm_campaign'] ) {
		update_post_meta( $post_id, 'UTM Campaign', $data['utm_campaign'] );
	}
	if ( $data['utm_content'] ) {
		update_post_meta( $post_id, 'UTM Content', $data['utm_content'] );
	}
	if ( $data['utm_term'] ) {
		update_post_meta( $post_id, 'UTM Term', $data['utm_term'] );
	}
	if ( $data['gclid'] ) {
		update_post_meta( $post_id, 'GCLID', $data['gclid'] );
	}
	if ( $data['landing_page'] ) {
		update_post_meta( $post_id, 'Landing Page', $data['landing_page'] );
	}
	if ( $data['lead_funnel'] ) {
		update_post_meta( $post_id, 'Lead Funnel', $data['lead_funnel'] );
	}
	update_post_meta( $post_id, 'SMS Consent', isset( $data['sms_consent'] ) ? $data['sms_consent'] : 'No' );

	$file_url = '';
	if ( isset( $_FILES['fq_file'] ) && isset( $_FILES['fq_file']['error'] ) && UPLOAD_ERR_OK === (int) $_FILES['fq_file']['error'] ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$movefile = wp_handle_upload( $_FILES['fq_file'], array( 'test_form' => false ) );
		if ( $movefile && ! isset( $movefile['error'] ) ) {
			$file_url = $movefile['url'];
			update_post_meta( $post_id, 'File Upload', $file_url );
		}
	}

	$to      = get_theme_mod( 'swift_email', get_option( 'admin_email' ) );
	$subject = 'New Lead Submission from ' . $data['name'];
	$body    = "You have received a new lead submission from your website.\n\n";
	$body   .= 'Name: ' . $data['name'] . "\n";
	$body   .= 'Email: ' . $data['email'] . "\n";
	$body   .= 'Phone: ' . $data['phone'] . "\n";
	if ( ! empty( $data['company'] ) ) {
		$body .= 'Company: ' . $data['company'] . "\n";
	}
	if ( ! empty( $data['scope'] ) ) {
		$body .= 'Scope: ' . $data['scope'] . "\n";
	}
	if ( $data['lead_funnel'] ) {
		$body .= 'Funnel: ' . $data['lead_funnel'] . "\n";
	}
	$body .= 'SMS Consent: ' . ( isset( $data['sms_consent'] ) ? $data['sms_consent'] : 'No' ) . "\n";
	if ( $data['utm_source'] || $data['utm_medium'] || $data['utm_campaign'] ) {
		$body .= 'UTM: source=' . $data['utm_source'] . ' | medium=' . $data['utm_medium'] . ' | campaign=' . $data['utm_campaign'] . ' | content=' . $data['utm_content'] . ' | term=' . $data['utm_term'] . "\n";
	}
	if ( $data['gclid'] ) {
		$body .= 'GCLID: ' . $data['gclid'] . "\n";
	}
	if ( $data['landing_page'] ) {
		$body .= 'Landing Page: ' . $data['landing_page'] . "\n";
	}
	$body .= "Message:\n" . $data['message'] . "\n\n";
	if ( $file_url ) {
		$body .= 'Uploaded File: ' . $file_url . "\n";
	}
	$body .= 'Source Page: ' . $data['source'] . "\n";

	wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );

	return (int) $post_id;
}

/**
 * Funnels that should land on the generic Thank You page after submit.
 *
 * @param string $funnel Lead funnel slug.
 * @return bool
 */
function swift_lead_uses_thank_you_page( $funnel ) {
	$funnel = (string) $funnel;
	$stay_on_page = array( '', 'homepage-quote', 'contact-page', 'get-a-quote', 'contact-form-7' );
	return ! in_array( $funnel, $stay_on_page, true );
}

/**
 * Permalink for the generic Thank You page.
 *
 * @param string $funnel Optional funnel slug added as ?from= for back-link context.
 * @return string
 */
function swift_get_thank_you_url( $funnel = '' ) {
	$page = get_page_by_path( 'thank-you' );
	if ( ! $page ) {
		$pages = get_posts(
			array(
				'post_type'              => 'page',
				'post_status'            => 'publish',
				'posts_per_page'         => 1,
				'meta_key'               => '_wp_page_template',
				'meta_value'             => 'page-thank-you.php',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		$page = $pages ? $pages[0] : null;
	}

	$url = $page ? get_permalink( $page ) : home_url( '/thank-you/' );
	if ( $funnel ) {
		$url = add_query_arg( 'from', sanitize_title( $funnel ), $url );
	}

	return $url;
}

// 2. Handle Form Submissions from Frontend (classic POST + redirect)
function swift_handle_lead_submission() {
	if ( ! isset( $_POST['form_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['form_nonce'] ) ), 'swifttakeoffs_form' ) ) {
		wp_die( esc_html__( 'Security check failed. Please try again.', 'swift-takeoffs' ) );
	}

	$recaptcha_token = isset( $_POST['recaptcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['recaptcha_token'] ) ) : '';
	if ( ! swift_takeoffs_verify_recaptcha( $recaptcha_token ) ) {
		$referer = wp_get_referer();
		$redirect = $referer ? add_query_arg( 'form_error', 'recaptcha', $referer ) : home_url( '/' );
		wp_safe_redirect( $redirect );
		exit;
	}

	$data        = swift_collect_lead_fields_from_request();
	$lead_funnel = $data['lead_funnel'];
	$result      = swift_store_lead_and_notify( $data );

	if ( is_wp_error( $result ) ) {
		wp_die( esc_html( $result->get_error_message() ) );
	}

	$referer = wp_get_referer();
	if ( swift_lead_uses_thank_you_page( $lead_funnel ) ) {
		$redirect_url = swift_get_thank_you_url( $lead_funnel );
	} else {
		$redirect_url = add_query_arg( 'form_success', '1', $referer ? $referer : home_url( '/' ) );
	}

	wp_safe_redirect( $redirect_url );
	exit;
}
add_action( 'admin_post_nopriv_swift_lead_submission', 'swift_handle_lead_submission' );
add_action( 'admin_post_swift_lead_submission', 'swift_handle_lead_submission' );

/**
 * AJAX lead submit (Swift landing). Redirects to generic Thank You on success.
 */
function swift_ajax_lead_submission() {
	if ( ! isset( $_POST['form_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['form_nonce'] ) ), 'swifttakeoffs_form' ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed. Please try again.', 'swift-takeoffs' ) ), 403 );
	}

	$recaptcha_token = isset( $_POST['recaptcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['recaptcha_token'] ) ) : '';
	if ( ! swift_takeoffs_verify_recaptcha( $recaptcha_token ) ) {
		wp_send_json_error( array( 'message' => __( 'reCAPTCHA verification failed. Please try again.', 'swift-takeoffs' ) ), 400 );
	}

	$data   = swift_collect_lead_fields_from_request();
	$result = swift_store_lead_and_notify( $data );
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
	}

	$payload = array(
		'lead_id' => (int) $result,
		'message' => __( 'Thank you! Your request was received.', 'swift-takeoffs' ),
	);

	if ( swift_lead_uses_thank_you_page( $data['lead_funnel'] ) ) {
		$payload['redirect'] = swift_get_thank_you_url( $data['lead_funnel'] );
	}

	wp_send_json_success( $payload );
}
add_action( 'wp_ajax_swift_lead_submission', 'swift_ajax_lead_submission' );
add_action( 'wp_ajax_nopriv_swift_lead_submission', 'swift_ajax_lead_submission' );

// 3. Display Custom Columns in Admin Panel
function swift_lead_columns( $columns ) {
    $new_columns = array(
        'cb' => $columns['cb'],
        'title' => __( 'Lead Title', 'swift-takeoffs' ),
        'name' => __( 'Name', 'swift-takeoffs' ),
        'email' => __( 'Email', 'swift-takeoffs' ),
        'phone' => __( 'Phone', 'swift-takeoffs' ),
        'company' => __( 'Company', 'swift-takeoffs' ),
        'scope' => __( 'Project Type', 'swift-takeoffs' ),
        'file' => __( 'File', 'swift-takeoffs' ),
        'date' => $columns['date']
    );
    return $new_columns;
}
add_filter( 'manage_swift_lead_posts_columns', 'swift_lead_columns' );

function swift_lead_custom_column( $column, $post_id ) {
    switch ( $column ) {
        case 'name':
            echo esc_html( get_post_meta( $post_id, 'Name', true ) );
            break;
        case 'email':
            $email = get_post_meta( $post_id, 'Email', true );
            echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
            break;
        case 'phone':
            echo esc_html( get_post_meta( $post_id, 'Phone', true ) );
            break;
        case 'company':
            echo esc_html( get_post_meta( $post_id, 'Company', true ) );
            break;
        case 'scope':
            echo esc_html( get_post_meta( $post_id, 'Scope', true ) );
            break;
        case 'file':
            $file = get_post_meta( $post_id, 'File Upload', true );
            if ( $file ) {
                echo '<a href="' . esc_url($file) . '" target="_blank">View File</a>';
            } else {
                echo '-';
            }
            break;
    }
}
add_action( 'manage_swift_lead_posts_custom_column', 'swift_lead_custom_column', 10, 2 );

// 4. Add Custom Metabox to display all details cleanly
function swift_lead_add_metabox() {
    add_meta_box(
        'swift_lead_details',
        __( 'Lead Details', 'swift-takeoffs' ),
        'swift_lead_metabox_callback',
        'swift_lead',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'swift_lead_add_metabox' );

function swift_lead_metabox_callback( $post ) {
    $name = get_post_meta( $post->ID, 'Name', true );
    $email = get_post_meta( $post->ID, 'Email', true );
    $phone = get_post_meta( $post->ID, 'Phone', true );
    $company = get_post_meta( $post->ID, 'Company', true );
    $scope = get_post_meta( $post->ID, 'Scope', true );
    $message = get_post_meta( $post->ID, 'Message', true );
    $file = get_post_meta( $post->ID, 'File Upload', true );
    $source = get_post_meta( $post->ID, 'Source URL', true );
    $utm_source = get_post_meta( $post->ID, 'UTM Source', true );
    $utm_medium = get_post_meta( $post->ID, 'UTM Medium', true );
    $utm_campaign = get_post_meta( $post->ID, 'UTM Campaign', true );
    $gclid = get_post_meta( $post->ID, 'GCLID', true );
    $landing_page = get_post_meta( $post->ID, 'Landing Page', true );
    $lead_funnel = get_post_meta( $post->ID, 'Lead Funnel', true );
    $sms_consent = get_post_meta( $post->ID, 'SMS Consent', true );

    echo '<table class="form-table" style="width: 100%; text-align: left;">';
    echo '<tr><th style="width: 20%; padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Name:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html($name) . '</td></tr>';
    echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Email:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;"><a href="mailto:'.esc_attr($email).'">' . esc_html($email) . '</a></td></tr>';
    echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Phone:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;"><a href="tel:'.esc_attr($phone).'">' . esc_html($phone) . '</a></td></tr>';
    if($company) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Company:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html($company) . '</td></tr>';
    if($scope) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Project Type:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html($scope) . '</td></tr>';
    if($lead_funnel) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Funnel:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html($lead_funnel) . '</td></tr>';
    if ( $sms_consent ) {
		echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>SMS Consent:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html( $sms_consent ) . '</td></tr>';
    }
    if($landing_page) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Landing Page:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;"><a href="' . esc_url($landing_page) . '" target="_blank">' . esc_html($landing_page) . '</a></td></tr>';
    if($utm_source || $utm_medium || $utm_campaign) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>UTM:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html( trim( "source=$utm_source | medium=$utm_medium | campaign=$utm_campaign" ) ) . '</td></tr>';
    if($gclid) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>GCLID:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;">' . esc_html($gclid) . '</td></tr>';
    echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Source URL:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;"><a href="' . esc_url($source) . '" target="_blank">' . esc_html($source) . '</a></td></tr>';
    if($file) echo '<tr><th style="padding: 10px 0; border-bottom: 1px solid #ddd;"><strong>Uploaded File:</strong></th><td style="padding: 10px 0; border-bottom: 1px solid #ddd;"><a href="' . esc_url($file) . '" target="_blank" class="button button-primary">Download / View File</a></td></tr>';
    echo '<tr><th style="padding: 10px 0; vertical-align: top;"><strong>Message:</strong></th><td style="padding: 10px 0;">' . nl2br(esc_html($message)) . '</td></tr>';
    echo '</table>';
}

/**
 * Safety net: if Contact Form 7 is still used anywhere, mirror submissions into Form Leads.
 *
 * @param WPCF7_ContactForm $contact_form CF7 form object.
 */
function swift_cf7_store_lead( $contact_form ) {
	if ( ! class_exists( 'WPCF7_Submission' ) ) {
		return;
	}
	$submission = WPCF7_Submission::get_instance();
	if ( ! $submission ) {
		return;
	}
	$posted = $submission->get_posted_data();
	if ( ! is_array( $posted ) ) {
		return;
	}

	$name = '';
	foreach ( array( 'your-name', 'quote_name', 'contact_name', 'fq_name', 'name' ) as $key ) {
		if ( ! empty( $posted[ $key ] ) ) {
			$name = sanitize_text_field( (string) $posted[ $key ] );
			break;
		}
	}
	$email = '';
	foreach ( array( 'your-email', 'quote_email', 'contact_email', 'fq_email', 'email' ) as $key ) {
		if ( ! empty( $posted[ $key ] ) ) {
			$email = sanitize_email( (string) $posted[ $key ] );
			break;
		}
	}
	if ( ! $name || ! $email ) {
		return;
	}

	$phone = '';
	foreach ( array( 'your-phone', 'quote_phone', 'contact_phone', 'fq_phone', 'phone', 'tel' ) as $key ) {
		if ( ! empty( $posted[ $key ] ) ) {
			$phone = sanitize_text_field( (string) $posted[ $key ] );
			break;
		}
	}
	$company = '';
	foreach ( array( 'your-company', 'quote_company', 'fq_company', 'company' ) as $key ) {
		if ( ! empty( $posted[ $key ] ) ) {
			$company = sanitize_text_field( (string) $posted[ $key ] );
			break;
		}
	}
	$message = '';
	foreach ( array( 'your-message', 'quote_message', 'contact_message', 'fq_message', 'message' ) as $key ) {
		if ( ! empty( $posted[ $key ] ) ) {
			$message = sanitize_textarea_field( (string) $posted[ $key ] );
			break;
		}
	}
	$scope = '';
	foreach ( array( 'fq_scope', 'project-type', 'scope' ) as $key ) {
		if ( ! empty( $posted[ $key ] ) ) {
			$scope = sanitize_text_field( (string) $posted[ $key ] );
			break;
		}
	}

	$data = array(
		'name'         => $name,
		'email'        => $email,
		'phone'        => $phone,
		'message'      => $message,
		'company'      => $company,
		'scope'        => $scope,
		'utm_source'   => '',
		'utm_medium'   => '',
		'utm_campaign' => '',
		'utm_content'  => '',
		'utm_term'     => '',
		'gclid'        => '',
		'landing_page' => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '',
		'lead_funnel'  => 'contact-form-7',
		'source'       => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : 'CF7',
	);

	// Avoid duplicate admin email from theme — CF7 already emails; only store CPT.
	$post_id = wp_insert_post(
		array(
			'post_title'  => 'Lead: ' . $name . ' (' . current_time( 'Y-m-d H:i' ) . ')',
			'post_type'   => 'swift_lead',
			'post_status' => 'publish',
		)
	);
	if ( is_wp_error( $post_id ) || ! $post_id ) {
		return;
	}
	update_post_meta( $post_id, 'Name', $data['name'] );
	update_post_meta( $post_id, 'Email', $data['email'] );
	update_post_meta( $post_id, 'Phone', $data['phone'] );
	if ( $data['company'] ) {
		update_post_meta( $post_id, 'Company', $data['company'] );
	}
	if ( $data['scope'] ) {
		update_post_meta( $post_id, 'Scope', $data['scope'] );
	}
	update_post_meta( $post_id, 'Message', $data['message'] );
	update_post_meta( $post_id, 'Source URL', $data['source'] );
	update_post_meta( $post_id, 'Lead Funnel', $data['lead_funnel'] );
	if ( $data['landing_page'] ) {
		update_post_meta( $post_id, 'Landing Page', $data['landing_page'] );
	}
}
add_action( 'wpcf7_mail_sent', 'swift_cf7_store_lead' );

/**
 * REST: POST /wp-json/swift/v1/quote-request
 *
 * JSON body from the free-quote form. Honeypot → silent 200.
 * Stores the lead via swift_store_lead_and_notify(); add CRM webhook below.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function swift_rest_quote_request( WP_REST_Request $request ) {
	$params = $request->get_json_params();
	if ( ! is_array( $params ) || empty( $params ) ) {
		$params = $request->get_params();
	}

	// Honeypot — bots that fill hidden "website" get a fake success (no lead stored).
	$hp = isset( $params['website'] ) ? trim( (string) $params['website'] ) : '';
	if ( '' === $hp && isset( $params['hp_field'] ) ) {
		$hp = trim( (string) $params['hp_field'] );
	}
	if ( '' !== $hp ) {
		return new WP_REST_Response( array( 'success' => true ), 200 );
	}

	$nonce = isset( $params['form_nonce'] ) ? sanitize_text_field( wp_unslash( $params['form_nonce'] ) ) : '';
	if ( ! $nonce || ! wp_verify_nonce( $nonce, 'swifttakeoffs_form' ) ) {
		return new WP_Error( 'invalid_nonce', __( 'Security check failed. Please refresh and try again.', 'swift-takeoffs' ), array( 'status' => 403 ) );
	}

	$recaptcha_token = isset( $params['recaptcha_token'] ) ? sanitize_text_field( wp_unslash( $params['recaptcha_token'] ) ) : '';
	if ( ! swift_takeoffs_verify_recaptcha( $recaptcha_token ) ) {
		return new WP_Error( 'recaptcha', __( 'Security check failed. Please try again.', 'swift-takeoffs' ), array( 'status' => 400 ) );
	}

	$name    = isset( $params['name'] ) ? sanitize_text_field( wp_unslash( $params['name'] ) ) : '';
	$email   = isset( $params['email'] ) ? sanitize_email( wp_unslash( $params['email'] ) ) : '';
	$phone   = isset( $params['phone'] ) ? sanitize_text_field( wp_unslash( $params['phone'] ) ) : '';
	$service = isset( $params['service'] ) ? sanitize_text_field( wp_unslash( $params['service'] ) ) : '';
	$message = isset( $params['message'] ) ? sanitize_textarea_field( wp_unslash( $params['message'] ) ) : '';
	$consent = ! empty( $params['sms_consent'] );

	if ( '' === $name ) {
		return new WP_Error( 'invalid_name', __( 'Name is required', 'swift-takeoffs' ), array( 'status' => 400 ) );
	}
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'invalid_email', __( 'Enter a valid email', 'swift-takeoffs' ), array( 'status' => 400 ) );
	}
	$digits = preg_replace( '/\D+/', '', $phone );
	if ( strlen( (string) $digits ) < 10 ) {
		return new WP_Error( 'invalid_phone', __( 'Enter a valid phone number', 'swift-takeoffs' ), array( 'status' => 400 ) );
	}
	if ( '' === $service ) {
		return new WP_Error( 'invalid_service', __( 'Service is required', 'swift-takeoffs' ), array( 'status' => 400 ) );
	}
	if ( ! $consent ) {
		return new WP_Error( 'invalid_consent', __( 'Please agree to SMS updates to continue', 'swift-takeoffs' ), array( 'status' => 400 ) );
	}

	$data = array(
		'name'         => $name,
		'email'        => $email,
		'phone'        => $phone,
		'message'      => $message,
		'company'      => '',
		'scope'        => $service,
		'utm_source'   => isset( $params['utm_source'] ) ? sanitize_text_field( wp_unslash( $params['utm_source'] ) ) : '',
		'utm_medium'   => isset( $params['utm_medium'] ) ? sanitize_text_field( wp_unslash( $params['utm_medium'] ) ) : '',
		'utm_campaign' => isset( $params['utm_campaign'] ) ? sanitize_text_field( wp_unslash( $params['utm_campaign'] ) ) : '',
		'utm_content'  => isset( $params['utm_content'] ) ? sanitize_text_field( wp_unslash( $params['utm_content'] ) ) : '',
		'utm_term'     => isset( $params['utm_term'] ) ? sanitize_text_field( wp_unslash( $params['utm_term'] ) ) : '',
		'gclid'        => isset( $params['gclid'] ) ? sanitize_text_field( wp_unslash( $params['gclid'] ) ) : '',
		'landing_page' => isset( $params['landing_page'] ) ? esc_url_raw( wp_unslash( $params['landing_page'] ) ) : '',
		'lead_funnel'  => isset( $params['lead_funnel'] ) ? sanitize_text_field( wp_unslash( $params['lead_funnel'] ) ) : 'homepage-quote',
		'source'       => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : 'Direct',
		'sms_consent'  => 'Yes',
	);

	/*
	 * CRM / webhook (wire later):
	 * wp_remote_post(
	 *     'https://example.com/hooks/quote-request',
	 *     array(
	 *         'headers' => array( 'Content-Type' => 'application/json' ),
	 *         'body'    => wp_json_encode( $data ),
	 *         'timeout' => 8,
	 *     )
	 * );
	 */
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( 'swift quote-request: ' . wp_json_encode( array( 'email' => $email, 'service' => $service ) ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}

	$result = swift_store_lead_and_notify( $data );
	if ( is_wp_error( $result ) ) {
		return new WP_Error( $result->get_error_code(), $result->get_error_message(), array( 'status' => 400 ) );
	}

	return new WP_REST_Response(
		array(
			'success' => true,
			'lead_id' => (int) $result,
			'message' => __( "Thanks! We'll be in touch shortly.", 'swift-takeoffs' ),
		),
		200
	);
}

/**
 * Register quote-request REST route.
 */
function swift_register_quote_request_route() {
	register_rest_route(
		'swift/v1',
		'/quote-request',
		array(
			'methods'             => 'POST',
			'callback'            => 'swift_rest_quote_request',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'swift_register_quote_request_route' );
