<?php
/**
 * Register Testimonial Custom Post Type
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function swift_takeoffs_register_testimonial_cpt() {
	$labels = array(
		'name'                  => _x( 'Testimonials', 'Post type general name', 'swift-takeoffs' ),
		'singular_name'         => _x( 'Testimonial', 'Post type singular name', 'swift-takeoffs' ),
		'menu_name'             => _x( 'Testimonials', 'Admin Menu text', 'swift-takeoffs' ),
		'name_admin_bar'        => _x( 'Testimonial', 'Add New on Toolbar', 'swift-takeoffs' ),
		'add_new'               => __( 'Add New', 'swift-takeoffs' ),
		'add_new_item'          => __( 'Add New Testimonial', 'swift-takeoffs' ),
		'new_item'              => __( 'New Testimonial', 'swift-takeoffs' ),
		'edit_item'             => __( 'Edit Testimonial', 'swift-takeoffs' ),
		'view_item'             => __( 'View Testimonial', 'swift-takeoffs' ),
		'all_items'             => __( 'All Testimonials', 'swift-takeoffs' ),
		'search_items'          => __( 'Search Testimonials', 'swift-takeoffs' ),
		'not_found'             => __( 'No testimonials found.', 'swift-takeoffs' ),
		'not_found_in_trash'    => __( 'No testimonials found in Trash.', 'swift-takeoffs' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => false,
		'rewrite'            => false,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon'          => 'dashicons-format-quote',
		'supports'           => array( 'title', 'editor', 'thumbnail' ),
	);

	register_post_type( 'testimonial', $args );
}
add_action( 'init', 'swift_takeoffs_register_testimonial_cpt' );
