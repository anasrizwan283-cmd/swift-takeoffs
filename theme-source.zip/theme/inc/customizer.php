<?php
/**
 * Swift Takeoffs Theme Customizer
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function swift_takeoffs_customize_register( $wp_customize ) {

	// ── Contact Info Panel ──────────────────────────────────
	$wp_customize->add_panel(
		'swift_contact_panel',
		array(
			'title'    => __( 'Contact Information', 'swift-takeoffs' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_section(
		'swift_contact_section',
		array(
			'title' => __( 'Phone, Email & Address', 'swift-takeoffs' ),
			'panel' => 'swift_contact_panel',
		)
	);

	// Phone Number
	$wp_customize->add_setting( 'swift_phone', array( 'default' => '678-825-6967', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'swift_phone', array( 'label' => __( 'Phone Number', 'swift-takeoffs' ), 'section' => 'swift_contact_section', 'type' => 'text' ) );

	// Email
	$wp_customize->add_setting( 'swift_email', array( 'default' => 'info@swifttakeoffs.com', 'sanitize_callback' => 'sanitize_email' ) );
	$wp_customize->add_control( 'swift_email', array( 'label' => __( 'Email Address', 'swift-takeoffs' ), 'section' => 'swift_contact_section', 'type' => 'email' ) );

	// Address
	$wp_customize->add_setting( 'swift_address', array( 'default' => '8 The Green #6092, Dover, 19901', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'swift_address', array( 'label' => __( 'Address', 'swift-takeoffs' ), 'section' => 'swift_contact_section', 'type' => 'text' ) );

	// Business Hours
	$wp_customize->add_setting( 'swift_hours', array( 'default' => 'Monday To Friday 8:00 AM To 10:00 PM', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'swift_hours', array( 'label' => __( 'Business Hours', 'swift-takeoffs' ), 'section' => 'swift_contact_section', 'type' => 'text' ) );

	// Website URL
	$wp_customize->add_setting( 'swift_website', array( 'default' => 'www.swifttakeoffs.com', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'swift_website', array( 'label' => __( 'Website (display text)', 'swift-takeoffs' ), 'section' => 'swift_contact_section', 'type' => 'text' ) );

	// Default OG Image
	$wp_customize->add_setting( 'swift_default_og_image', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'swift_default_og_image', array(
		'label'       => __( 'Default OG / Social Share Image', 'swift-takeoffs' ),
		'description' => __( 'Used for SEO / social sharing when a page has no specific image (Recommended: 1200x630px).', 'swift-takeoffs' ),
		'section'     => 'swift_contact_section',
		'settings'    => 'swift_default_og_image',
	) ) );

	// ── Social Media Section ────────────────────────────────
	$wp_customize->add_section(
		'swift_social_section',
		array(
			'title' => __( 'Social Media URLs', 'swift-takeoffs' ),
			'panel' => 'swift_contact_panel',
		)
	);

	$social_links = array(
		'swift_facebook'  => 'Facebook URL',
		'swift_instagram' => 'Instagram URL',
		'swift_linkedin'  => 'LinkedIn URL',
	);

	foreach ( $social_links as $setting_id => $label ) {
		$wp_customize->add_setting( $setting_id, array( 'default' => '#', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( $setting_id, array( 'label' => __( $label, 'swift-takeoffs' ), 'section' => 'swift_social_section', 'type' => 'url' ) );
	}

	// ── Footer Section ─────────────────────────────────────
	$wp_customize->add_section(
		'swift_footer_section',
		array(
			'title'    => __( 'Footer Settings', 'swift-takeoffs' ),
			'priority' => 35,
		)
	);

	$wp_customize->add_setting( 'swift_footer_about', array(
		'default'           => 'Swift Takeoffs is your trusted partner for precise construction estimating and material takeoffs. We empower contractors with accurate data to win more bids and manage projects effectively.',
		'sanitize_callback' => 'sanitize_textarea_field',
	) );
	$wp_customize->add_control( 'swift_footer_about', array(
		'label'   => __( 'Footer About Text', 'swift-takeoffs' ),
		'section' => 'swift_footer_section',
		'type'    => 'textarea',
	) );

	$wp_customize->add_setting( 'swift_footer_copyright', array(
		'default'           => '© 2024 Swift Takeoffs. All Rights Reserved. Designed for Excellence by <a href="https://nexflow.tech/" target="_blank" rel="noopener noreferrer">Nexflow Technologies</a>.',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'swift_footer_copyright', array(
		'label'   => __( 'Copyright Text (HTML allowed)', 'swift-takeoffs' ),
		'section' => 'swift_footer_section',
		'type'    => 'textarea',
	) );
}
add_action( 'customize_register', 'swift_takeoffs_customize_register' );


/**
 * Helper: get theme mod with fallback default.
 */
function swift_get_mod( $key, $default = '' ) {
	return get_theme_mod( $key, $default );
}
