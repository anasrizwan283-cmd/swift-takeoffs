<?php
/**
 * Enqueue landing page assets (general + drywall campaign funnel).
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load general Swift Takeoffs landing assets.
 */
function portfolio_theme_enqueue_landing_assets() {
	if ( function_exists( 'swift_takeoffs_is_campaign_lander' ) && swift_takeoffs_is_campaign_lander() ) {
		return;
	}

	// Load landing styles for the generic landing template, the drywall landing,
	// and for known landing slugs such as 'drywall-estimating' and 'lp-a'.
	if ( ! ( is_page_template( 'page-swift-takeoffs-landing.php' )
		|| is_page_template( 'page-drywall-estimating-landing.php' )
		|| is_page( array( 'drywall-estimating', 'lp-a' ) ) ) ) {
		return;
	}

	$base_uri = get_template_directory_uri() . '/assets/landing';
	$base_dir = get_template_directory() . '/assets/landing';

	// Poppins already loaded globally (swift-google-fonts) — do not enqueue a duplicate Google Fonts CSS.

	/*
	 * Tailwind CDN = browser me poora Tailwind compiler download + run.
	 * Jab assets/landing/css/tw.min.css maujood ho, CDN band; warna temporary CDN.
	 */
	$tw_built = $base_dir . '/css/tw.min.css';
	if ( file_exists( $tw_built ) ) {
		wp_enqueue_style(
			'st-landing-tailwind',
			$base_uri . '/css/tw.min.css',
			array(),
			swift_takeoffs_asset_ver( '/assets/landing/css/tw.min.css' )
		);
	} else {
		wp_enqueue_script(
			'tailwind-cdn',
			'https://cdn.tailwindcss.com',
			array(),
			null,
			true
		);
	}

	$landing_rel = file_exists( $base_dir . '/css/landing.min.css' )
		? '/assets/landing/css/landing.min.css'
		: '/assets/landing/css/landing.css';

	wp_enqueue_style(
		'st-landing-custom',
		get_template_directory_uri() . $landing_rel,
		array( 'swift-main-style' ),
		swift_takeoffs_asset_ver( $landing_rel )
	);

	wp_enqueue_script(
		'st-landing-js',
		$base_uri . '/js/landing-script.js',
		array(),
		swift_takeoffs_asset_ver( '/assets/landing/js/landing-script.js' ),
		true
	);

	wp_localize_script(
		'st-landing-js',
		'ST_LANDING_FORM',
		array(
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'siteKey'      => function_exists( 'swift_takeoffs_get_recaptcha_site_key' ) ? swift_takeoffs_get_recaptcha_site_key() : '',
			'thankYouUrl'  => function_exists( 'swift_get_thank_you_url' ) ? swift_get_thank_you_url( 'swift-takeoffs-landing' ) : home_url( '/thank-you/' ),
			'successTitle' => __( 'Request received', 'swift-takeoffs' ),
			'successBody'  => __( 'Thanks — our estimating team will follow up shortly. Keep your plans handy so we can move fast.', 'swift-takeoffs' ),
			'errorGeneric' => __( 'Something went wrong. Please try again.', 'swift-takeoffs' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'portfolio_theme_enqueue_landing_assets' );

/**
 * Drywall campaign landing assets (theme header/footer remain; kit CSS/JS added).
 */
function swift_takeoffs_enqueue_drywall_landing_assets() {
	$is_drywall = is_page_template( 'page-drywall-estimating-landing.php' )
		|| is_page_template( 'page-drywall-thank-you.php' );

	if ( ! $is_drywall ) {
		return;
	}

	$base_uri = get_template_directory_uri() . '/assets/landing-drywall';
	$base_dir = get_template_directory() . '/assets/landing-drywall';

	wp_enqueue_style(
		'st-drywall-inter',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
		array(),
		null
	);

	$drywall_rel = file_exists( $base_dir . '/css/drywall-landing.min.css' )
		? '/assets/landing-drywall/css/drywall-landing.min.css'
		: '/assets/landing-drywall/css/drywall-landing.css';

	wp_enqueue_style(
		'st-drywall-landing',
		get_template_directory_uri() . $drywall_rel,
		array( 'swift-main-style' ), // Inter loads non-blocking separately — don't stall kit CSS
		swift_takeoffs_asset_ver( $drywall_rel )
	);

	wp_enqueue_script(
		'st-drywall-landing-js',
		$base_uri . '/js/drywall-landing.js',
		array(),
		swift_takeoffs_asset_ver( '/assets/landing-drywall/js/drywall-landing.js' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'swift_takeoffs_enqueue_drywall_landing_assets', 30 );

/**
 * Reusable campaign lander (client HTML kit).
 */
function swift_takeoffs_enqueue_campaign_lander_assets() {
	if ( ! function_exists( 'swift_takeoffs_is_campaign_lander' ) || ! swift_takeoffs_is_campaign_lander() ) {
		return;
	}

	$base_uri = get_template_directory_uri() . '/assets/campaign-lander';
	$base_dir = get_template_directory() . '/assets/campaign-lander';

	wp_enqueue_style(
		'st-campaign-inter',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
		array(),
		null
	);

	$css_rel = file_exists( $base_dir . '/css/lander.min.css' )
		? '/assets/campaign-lander/css/lander.min.css'
		: '/assets/campaign-lander/css/lander.css';

	wp_enqueue_style(
		'st-campaign-lander',
		get_template_directory_uri() . $css_rel,
		array(),
		swift_takeoffs_asset_ver( $css_rel )
	);

	wp_enqueue_script(
		'st-campaign-lander-js',
		$base_uri . '/js/lander.js',
		array(),
		swift_takeoffs_asset_ver( '/assets/campaign-lander/js/lander.js' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'swift_takeoffs_enqueue_campaign_lander_assets', 30 );

/**
 * Create Drywall landing + thank-you pages once (if missing).
 */
function swift_takeoffs_ensure_drywall_pages() {
	if ( get_option( 'swift_drywall_pages_created' ) ) {
		return;
	}

	$landing = get_page_by_path( 'drywall-estimating' );
	if ( ! $landing ) {
		$landing_id = wp_insert_post(
			array(
				'post_title'   => 'Drywall Estimating',
				'post_name'    => 'drywall-estimating',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			)
		);
		if ( $landing_id && ! is_wp_error( $landing_id ) ) {
			update_post_meta( $landing_id, '_wp_page_template', 'page-campaign-lander.php' );
			update_post_meta( $landing_id, 'rank_math_title', 'Drywall Estimating Services | Swift Takeoffs' );
			update_post_meta( $landing_id, 'rank_math_description', 'Get accurate drywall estimating and material takeoff services for commercial and residential projects. Fast turnaround, bid-ready quantities.' );
		}
	} else {
		update_post_meta( $landing->ID, '_wp_page_template', 'page-campaign-lander.php' );
		if ( function_exists( 'swift_rm_seed_lander_seo_meta' ) ) {
			swift_rm_seed_lander_seo_meta( $landing->ID );
		}
	}

	$thanks = get_page_by_path( 'drywall-estimating/thank-you' );
	if ( ! $thanks ) {
		$parent = get_page_by_path( 'drywall-estimating' );
		$thanks_id = wp_insert_post(
			array(
				'post_title'   => 'Thank You — Drywall Quote',
				'post_name'    => 'thank-you',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_parent'  => $parent ? (int) $parent->ID : 0,
				'post_content' => '',
			)
		);
		if ( $thanks_id && ! is_wp_error( $thanks_id ) ) {
			update_post_meta( $thanks_id, '_wp_page_template', 'page-drywall-thank-you.php' );
			update_post_meta( $thanks_id, 'rank_math_robots', array( 'index' => 'noindex', 'follow' => 'nofollow' ) );
			update_post_meta( $thanks_id, 'rank_math_title', 'Thank You | Drywall Estimating' );
		}
	}

	update_option( 'swift_drywall_pages_created', 1, false );
}
add_action( 'admin_init', 'swift_takeoffs_ensure_drywall_pages' );

/**
 * Point existing /drywall-estimating/ page at the reusable campaign lander.
 */
function swift_takeoffs_assign_campaign_lander_template() {
	if ( get_option( 'swift_campaign_lander_assigned' ) ) {
		return;
	}

	$page = get_page_by_path( 'drywall-estimating' );
	if ( $page ) {
		update_post_meta( $page->ID, '_wp_page_template', 'page-campaign-lander.php' );
	}

	update_option( 'swift_campaign_lander_assigned', 1, false );
}
add_action( 'init', 'swift_takeoffs_assign_campaign_lander_template', 20 );

/**
 * Create generic /thank-you/ page once (if missing).
 */
function swift_takeoffs_ensure_thank_you_page() {
	if ( get_option( 'swift_thank_you_page_created' ) ) {
		return;
	}

	$page = get_page_by_path( 'thank-you' );
	if ( ! $page ) {
		$page_id = wp_insert_post(
			array(
				'post_title'   => 'Thank You',
				'post_name'    => 'thank-you',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			)
		);
		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_post_meta( $page_id, '_wp_page_template', 'page-thank-you.php' );
			update_post_meta( $page_id, 'rank_math_robots', array( 'index' => 'noindex', 'follow' => 'nofollow' ) );
			update_post_meta( $page_id, 'rank_math_title', 'Thank You | Swift Takeoffs' );
		}
	} else {
		update_post_meta( $page->ID, '_wp_page_template', 'page-thank-you.php' );
	}

	update_option( 'swift_thank_you_page_created', 1, false );
}
add_action( 'admin_init', 'swift_takeoffs_ensure_thank_you_page' );

/**
 * Hard noindex for thank-you templates (campaign hygiene).
 */
function swift_takeoffs_thankyou_robots() {
	if ( is_page_template( 'page-thank-you.php' ) || is_page_template( 'page-drywall-thank-you.php' ) ) {
		echo '<meta name="robots" content="noindex, nofollow" />' . "\n";
	}
}
add_action( 'wp_head', 'swift_takeoffs_thankyou_robots', 1 );
