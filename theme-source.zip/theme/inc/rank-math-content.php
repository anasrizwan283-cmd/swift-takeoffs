<?php
/**
 * Rank Math ↔ SCF/ACF content bridge for Trade & Service CPTs.
 *
 * Front-end body copy lives in Secure Custom Fields, not post_content.
 * Rank Math’s analyzer only reads the block editor by default — so scores
 * look empty (word count, keywords, images, links). This file feeds the
 * real SCF HTML into Rank Math without overriding admin SEO titles/meta.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build analyzable HTML from trade/service SCF fields (mirrors single templates).
 *
 * @param int    $post_id   Post ID.
 * @param string $post_type trade|service.
 * @return string
 */
function swift_rm_build_cpt_content_html( $post_id, $post_type = '' ) {
	if ( ! function_exists( 'get_field' ) ) {
		return '';
	}

	$post_id   = (int) $post_id;
	$post_type = $post_type ? $post_type : get_post_type( $post_id );
	$title     = get_the_title( $post_id );
	$parts     = array();

	if ( 'trade' === $post_type ) {
		$main_image = get_field( 'trade_main_image', $post_id );
		$intro      = get_field( 'trade_intro_text', $post_id );
		$costs      = get_field( 'trade_cost_factors', $post_id );
		$takeoff    = get_field( 'trade_takeoff_text', $post_id );
		$why_items  = get_field( 'trade_why_choose_items', $post_id );
		$why_image  = get_field( 'trade_why_choose_image', $post_id );
		$cta        = get_field( 'trade_cta_text', $post_id );

		$parts[] = '<h1>' . esc_html( $title ) . '</h1>';
		if ( $main_image ) {
			$parts[] = '<img src="' . esc_url( $main_image ) . '" alt="' . esc_attr( $title ) . '" />';
		}
		if ( $intro ) {
			$parts[] = '<div class="rm-intro">' . $intro . '</div>';
		}
		if ( ! empty( $costs ) && is_array( $costs ) ) {
			$parts[] = '<h2>' . esc_html( $title ) . ' Cost Factors</h2><ul>';
			foreach ( $costs as $row ) {
				$ct = isset( $row['cost_title'] ) ? $row['cost_title'] : '';
				$cd = isset( $row['cost_desc'] ) ? $row['cost_desc'] : '';
				$parts[] = '<li><h3>' . esc_html( $ct ) . '</h3><p>' . esc_html( $cd ) . '</p></li>';
			}
			$parts[] = '</ul>';
		}
		if ( $takeoff ) {
			$parts[] = '<h2>' . esc_html( sprintf( /* translators: %s: trade title */ __( 'What is included in %s Takeoff?', 'swift-takeoffs' ), $title ) ) . '</h2>';
			$parts[] = '<div class="rm-takeoff">' . $takeoff . '</div>';
		}
		if ( ! empty( $why_items ) && is_array( $why_items ) ) {
			$parts[] = '<h2>' . esc_html__( 'Why Choose Swift Takeoffs?', 'swift-takeoffs' ) . '</h2><ul>';
			foreach ( $why_items as $row ) {
				$wt = isset( $row['why_title'] ) ? $row['why_title'] : '';
				$wd = isset( $row['why_desc'] ) ? $row['why_desc'] : '';
				$parts[] = '<li><h3>' . esc_html( $wt ) . '</h3><p>' . esc_html( $wd ) . '</p></li>';
			}
			$parts[] = '</ul>';
		}
		if ( $why_image ) {
			$parts[] = '<img src="' . esc_url( $why_image ) . '" alt="' . esc_attr( $title . ' estimating team' ) . '" />';
		}
		if ( $cta ) {
			$parts[] = '<p>' . esc_html( $cta ) . '</p>';
		}
	} elseif ( 'service' === $post_type ) {
		$main_image = get_field( 'service_main_image', $post_id );
		$intro      = get_field( 'service_intro_text', $post_id );
		$costs      = get_field( 'service_cost_factors', $post_id );
		$takeoff    = get_field( 'service_takeoff_text', $post_id );
		$why_items  = get_field( 'service_why_items', $post_id );
		$why_image  = get_field( 'service_why_image', $post_id );
		$cta        = get_field( 'service_cta_text', $post_id );

		$parts[] = '<h1>' . esc_html( $title ) . '</h1>';
		if ( $main_image ) {
			$parts[] = '<img src="' . esc_url( $main_image ) . '" alt="' . esc_attr( $title ) . '" />';
		}
		if ( $intro ) {
			$parts[] = '<div class="rm-intro">' . $intro . '</div>';
		}
		if ( ! empty( $costs ) && is_array( $costs ) ) {
			$parts[] = '<h2>' . esc_html( $title ) . ' Cost Factors</h2><ul>';
			foreach ( $costs as $row ) {
				$ct = isset( $row['cost_title'] ) ? $row['cost_title'] : '';
				$cd = isset( $row['cost_desc'] ) ? $row['cost_desc'] : '';
				$parts[] = '<li><h3>' . esc_html( $ct ) . '</h3><p>' . esc_html( $cd ) . '</p></li>';
			}
			$parts[] = '</ul>';
		}
		if ( $takeoff ) {
			$parts[] = '<h2>' . esc_html( sprintf( /* translators: %s: service title */ __( 'What is included in %s?', 'swift-takeoffs' ), $title ) ) . '</h2>';
			$parts[] = '<div class="rm-takeoff">' . $takeoff . '</div>';
		}
		if ( ! empty( $why_items ) && is_array( $why_items ) ) {
			$parts[] = '<h2>' . esc_html__( 'Why Choose Swift Takeoffs?', 'swift-takeoffs' ) . '</h2><ul>';
			foreach ( $why_items as $row ) {
				$wt = isset( $row['why_title'] ) ? $row['why_title'] : '';
				$wd = isset( $row['why_desc'] ) ? $row['why_desc'] : '';
				$parts[] = '<li><h3>' . esc_html( $wt ) . '</h3><p>' . esc_html( $wd ) . '</p></li>';
			}
			$parts[] = '</ul>';
		}
		if ( $why_image ) {
			$parts[] = '<img src="' . esc_url( $why_image ) . '" alt="' . esc_attr( $title . ' estimating' ) . '" />';
		}
		if ( $cta ) {
			$parts[] = '<p>' . esc_html( $cta ) . '</p>';
		}
	} else {
		return '';
	}

	// Soft site context links (also present site-wide) so link checks aren't false-empty.
	$parts[] = '<p><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Swift Takeoffs', 'swift-takeoffs' ) . '</a>';
	$parts[] = ' · <a href="' . esc_url( home_url( '/services/' ) ) . '">' . esc_html__( 'Construction Estimating Services', 'swift-takeoffs' ) . '</a>';
	$parts[] = ' · <a href="' . esc_url( home_url( '/trades/' ) ) . '">' . esc_html__( 'Trade Estimating Services', 'swift-takeoffs' ) . '</a>';
	$parts[] = ' · <a href="' . esc_url( home_url( '/get-a-quote/' ) ) . '">' . esc_html__( 'Request a Quote', 'swift-takeoffs' ) . '</a></p>';

	$html = implode( "\n", array_filter( $parts ) );

	/**
	 * Filter analyzable HTML passed to Rank Math for a CPT.
	 *
	 * @param string $html      Built HTML.
	 * @param int    $post_id   Post ID.
	 * @param string $post_type Post type.
	 */
	return apply_filters( 'swift_rank_math_cpt_content_html', $html, $post_id, $post_type );
}

/**
 * Whether a post uses the Campaign Lander template.
 *
 * @param int $post_id Post ID.
 * @return bool
 */
function swift_rm_is_campaign_lander_post( $post_id ) {
	return 'page-campaign-lander.php' === get_page_template_slug( (int) $post_id );
}

/**
 * Rank Math title / description / focus keyword for a campaign lander.
 *
 * @param int $post_id Post ID.
 * @return array{keyword:string,title:string,description:string}
 */
function swift_rm_lander_seo_strings( $post_id ) {
	$service = trim( st_lander_text( 'st_cl_service_type', $post_id ) );
	if ( ! $service ) {
		$service = 'Drywall';
	}
	$keyword = st_lander_focus_keyword( $post_id );
	$label   = $service . ' Estimating Services';

	return array(
		'keyword'     => $keyword,
		'title'       => $label . ': 99% Accurate Takeoffs',
		'description' => sprintf(
			'%s with 99%% accurate quantities in 8–24 hours. Bid-ready takeoffs for US contractors from Swift Takeoffs.',
			ucfirst( $keyword )
		),
	);
}

/**
 * Seed Rank Math title, description, and focus keyword when empty.
 *
 * @param int $post_id Post ID.
 */
function swift_rm_seed_lander_seo_meta( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! $post_id || ! swift_rm_is_campaign_lander_post( $post_id ) ) {
		return;
	}
	if ( ! class_exists( 'RankMath' ) ) {
		return;
	}

	$seo = swift_rm_lander_seo_strings( $post_id );

	if ( ! get_post_meta( $post_id, 'rank_math_focus_keyword', true ) ) {
		update_post_meta( $post_id, 'rank_math_focus_keyword', $seo['keyword'] );
	}
	if ( ! get_post_meta( $post_id, 'rank_math_title', true ) ) {
		update_post_meta( $post_id, 'rank_math_title', $seo['title'] );
	}
	if ( ! get_post_meta( $post_id, 'rank_math_description', true ) ) {
		update_post_meta( $post_id, 'rank_math_description', $seo['description'] );
	}
}

/**
 * Build analyzable HTML from campaign lander fields (live kit + Rank Math SEO body).
 *
 * @param int $post_id Post ID.
 * @return string
 */
function swift_rm_build_lander_content_html( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! function_exists( 'st_lander_text' ) ) {
		return '';
	}

	$keyword  = st_lander_focus_keyword( $post_id );
	$h1       = st_lander_text( 'st_cl_hero_heading', $post_id );
	$sub      = st_lander_text( 'st_cl_hero_subtext', $post_id );
	$why      = st_lander_text( 'st_cl_why_title', $post_id );
	$guide_h  = st_lander_text( 'st_cl_guide_title', $post_id );
	$guide    = st_lander_html( 'st_cl_guide_body', $post_id );
	$deliv    = st_lander_image_url( 'st_cl_deliv_image', '/assets/campaign-lander/deliverables-sample.png', $post_id );
	$hero_bg  = st_lander_image_url( 'st_cl_hero_bg', '/assets/campaign-lander/hero-bg.png', $post_id );
	$parts    = array();

	$parts[] = '<h1>' . esc_html( $h1 ) . '</h1>';
	$parts[] = '<p>' . esc_html( $sub ) . '</p>';
	$parts[] = '<img src="' . esc_url( $hero_bg ) . '" alt="' . esc_attr( ucfirst( $keyword ) . ' sample plans' ) . '" />';

	$parts[] = '<h2>' . esc_html( $why ) . '</h2>';
	foreach ( st_lander_rows( 'st_cl_features', $post_id ) as $i => $feature ) {
		$title = isset( $feature['title'] ) ? $feature['title'] : '';
		$text  = isset( $feature['text'] ) ? $feature['text'] : '';
		$icon  = isset( $feature['icon'] ) ? $feature['icon'] : '';
		$alt   = 0 === $i ? ucfirst( $keyword ) : $title;
		if ( $icon ) {
			$parts[] = '<img src="' . esc_url( $icon ) . '" alt="' . esc_attr( $alt ) . '" />';
		}
		$parts[] = '<h3>' . esc_html( $title ) . '</h3><p>' . esc_html( $text ) . '</p>';
	}

	if ( $guide_h || $guide ) {
		$parts[] = '<h2>' . esc_html( $guide_h ) . '</h2>';
		$parts[] = $guide;
	}

	$parts[] = '<h2>' . esc_html( st_lander_text( 'st_cl_process_title', $post_id ) ) . '</h2>';
	foreach ( st_lander_rows( 'st_cl_steps', $post_id ) as $step ) {
		$parts[] = '<h3>' . esc_html( isset( $step['title'] ) ? $step['title'] : '' ) . '</h3>';
		$parts[] = '<p>' . esc_html( isset( $step['text'] ) ? $step['text'] : '' ) . '</p>';
	}

	$parts[] = '<h2>' . esc_html( st_lander_text( 'st_cl_deliv_title', $post_id ) ) . '</h2>';
	$parts[] = '<p>' . esc_html( st_lander_text( 'st_cl_deliv_text', $post_id ) ) . '</p>';
	if ( $deliv ) {
		$parts[] = '<img src="' . esc_url( $deliv ) . '" alt="' . esc_attr( ucfirst( $keyword ) . ' marked-up takeoff sample' ) . '" />';
	}
	foreach ( st_lander_rows( 'st_cl_deliverables', $post_id ) as $item ) {
		$parts[] = '<h3>' . esc_html( isset( $item['title'] ) ? $item['title'] : '' ) . '</h3>';
		$parts[] = '<p>' . esc_html( isset( $item['text'] ) ? $item['text'] : '' ) . '</p>';
	}

	$parts[] = '<h2>' . esc_html( st_lander_text( 'st_cl_faq_title', $post_id ) ) . '</h2>';
	foreach ( st_lander_rows( 'st_cl_faqs', $post_id ) as $faq ) {
		$parts[] = '<h3>' . esc_html( isset( $faq['question'] ) ? $faq['question'] : '' ) . '</h3>';
		$parts[] = '<p>' . esc_html( isset( $faq['answer'] ) ? $faq['answer'] : '' ) . '</p>';
	}

	$parts[] = '<p>' . esc_html( st_lander_text( 'st_cl_cta_text', $post_id ) ) . '</p>';
	$parts[] = '<p><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Swift Takeoffs', 'swift-takeoffs' ) . '</a>';
	$parts[] = ' · <a href="' . esc_url( home_url( '/services/' ) ) . '">' . esc_html__( 'Construction Estimating Services', 'swift-takeoffs' ) . '</a>';
	$parts[] = ' · <a href="' . esc_url( home_url( '/get-a-quote/' ) ) . '">' . esc_html__( 'Request a Quote', 'swift-takeoffs' ) . '</a>';
	$parts[] = ' · <a href="https://www.bluebeam.com/" rel="noopener noreferrer">Bluebeam</a></p>';

	return implode( "\n", array_filter( $parts ) );
}

/**
 * Internal + external links Rank Math expects on template-driven pages.
 *
 * @return string
 */
function swift_rm_shared_links_html() {
	return '<p><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Swift Takeoffs', 'swift-takeoffs' ) . '</a>'
		. ' · <a href="' . esc_url( home_url( '/about/' ) ) . '">' . esc_html__( 'About Swift Takeoffs', 'swift-takeoffs' ) . '</a>'
		. ' · <a href="' . esc_url( home_url( '/services/' ) ) . '">' . esc_html__( 'Construction Estimating Services', 'swift-takeoffs' ) . '</a>'
		. ' · <a href="' . esc_url( home_url( '/get-a-quote/' ) ) . '">' . esc_html__( 'Request a Quote', 'swift-takeoffs' ) . '</a>'
		. ' · <a href="' . esc_url( home_url( '/contact/' ) ) . '">' . esc_html__( 'Contact', 'swift-takeoffs' ) . '</a>'
		. ' · <a href="https://www.bluebeam.com/" rel="noopener noreferrer">Bluebeam</a></p>';
}

/**
 * Pages whose body lives in PHP templates (empty post_content).
 *
 * @param int $post_id Post ID.
 * @return bool
 */
function swift_rm_is_bridged_page( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! $post_id ) {
		return false;
	}
	if ( swift_rm_is_campaign_lander_post( $post_id ) ) {
		return true;
	}
	if ( in_array( get_post_type( $post_id ), array( 'trade', 'service' ), true ) ) {
		return true;
	}
	if ( 'page' !== get_post_type( $post_id ) ) {
		return false;
	}

	$template = get_page_template_slug( $post_id );
	$bridged  = array(
		'page-about.php',
		'page-contact.php',
		'page-get-a-quote.php',
		'front-page.php',
		'page-swift-takeoffs-landing.php',
	);
	if ( in_array( $template, $bridged, true ) ) {
		return true;
	}
	if ( (int) get_option( 'page_on_front' ) === $post_id ) {
		return true;
	}

	$slug = get_post_field( 'post_name', $post_id );
	return in_array(
		$slug,
		array( 'about', 'about-us', 'contact', 'contact-us', 'get-a-quote', 'services', 'construction-estimating-services', 'lp-a' ),
		true
	);
}

/**
 * Whether a post uses the Swift Takeoffs Landing template.
 *
 * @param int $post_id Post ID.
 * @return bool
 */
function swift_rm_is_st_landing_post( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! $post_id ) {
		return false;
	}
	if ( 'page-swift-takeoffs-landing.php' === get_page_template_slug( $post_id ) ) {
		return true;
	}
	return in_array( get_post_field( 'post_name', $post_id ), array( 'construction-estimating-services', 'lp-a' ), true );
}

/**
 * Seed Rank Math title, description, and focus keyword for the ST landing page.
 *
 * @param int $post_id Post ID.
 */
function swift_rm_seed_st_landing_seo_meta( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! $post_id || ! swift_rm_is_st_landing_post( $post_id ) || ! class_exists( 'RankMath' ) ) {
		return;
	}

	$title = 'Construction Estimating Services: 99% Accurate Takeoffs';
	$desc  = 'Get construction estimating services with 99% accurate quantities in 24–48 hours. Bid-ready takeoffs for US contractors from Swift Takeoffs.';
	$key   = 'construction estimating services';

	$existing_key = strtolower( trim( (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true ) ) );
	if ( '' === $existing_key ) {
		update_post_meta( $post_id, 'rank_math_focus_keyword', $key );
	}

	$existing_title = trim( (string) get_post_meta( $post_id, 'rank_math_title', true ) );
	$has_keyword    = false !== stripos( $existing_title, 'construction estimating services' );
	$has_number     = (bool) preg_match( '/\d/', $existing_title );
	if ( '' === $existing_title || ! $has_keyword || ! $has_number ) {
		update_post_meta( $post_id, 'rank_math_title', $title );
	}

	if ( ! get_post_meta( $post_id, 'rank_math_description', true ) ) {
		update_post_meta( $post_id, 'rank_math_description', $desc );
	}
}

/**
 * Analyzable HTML for the Swift Takeoffs Landing template.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function swift_rm_build_st_landing_html( $post_id ) {
	$uri      = get_template_directory_uri() . '/assets/landing/images';
	$home     = home_url( '/' );
	$services = home_url( '/services/' );
	$quote    = home_url( '/get-a-quote/' );
	$bluebeam = 'https://www.bluebeam.com/';
	$parts    = array();

	$parts[] = '<h1>Construction Estimating Services for Smarter Bids</h1>';
	$parts[] = '<p>Construction estimating services from Swift Takeoffs cut overheads and remove hidden surprises. Precise takeoffs save money, reduce risk, and keep every project on budget.</p>';
	$parts[] = '<img src="' . esc_url( $uri . '/hero-bg.svg' ) . '" alt="Construction estimating services takeoff sample" />';

	$parts[] = '<h2>Trusted contractors who need faster takeoffs</h2>';
	$parts[] = '<p>General contractors and specialty trades call when the bid calendar is full and in-house estimators are already committed. Overflow weeks should not mean skipped drawings or rushed counts.</p>';
	$parts[] = '<p>We measure from PDFs and CAD, mark up the plans, and list every assumption so you know what is included. You price labor and material instead of redrawing the building.</p>';
	$parts[] = '<img src="' . esc_url( $uri . '/company-1.svg' ) . '" alt="Construction estimating services client" />';

	$parts[] = '<h2>Software that matches your estimating workflow</h2>';
	$parts[] = '<p>Reports work with Excel, PDF, PlanSwift, STACK, and <a href="' . esc_url( $bluebeam ) . '" rel="noopener noreferrer">Bluebeam</a>. If you already have a takeoff workflow, we match it instead of forcing a new file format.</p>';
	$parts[] = '<p>Estimators stay in the file you already use. Missing partitions, shaft walls, and finish levels are the usual leaks. A second set of eyes on the drawings reduces those misses.</p>';
	$parts[] = '<img src="' . esc_url( $uri . '/software-1.svg' ) . '" alt="Construction estimating services software" />';

	$parts[] = '<h2>CSI divisions we count on every project</h2>';
	$parts[] = '<p>We count across CSI divisions with the same care as an in-house takeoff: concrete, metals, wood and plastics, thermal and moisture, openings, finishes, specialties, and equipment. Tell us the spec and we will count to that spec.</p>';
	$parts[] = '<p>Typical packages cover residential, commercial, and light industrial work. Apartments, schools, healthcare, offices, and custom homes all follow the same process: drawings in, bid-ready quantities out.</p>';
	$parts[] = '<p>Scope notes, waste factors, and unit labels are written the way a field superintendent reads them. You should not have to decode a spreadsheet before you can price the job or brief a subcontractor.</p>';

	$parts[] = '<h2>Why contractors choose construction estimating services from Swift Takeoffs</h2>';
	$parts[] = '<h3>60% cost savings versus a full-time hire</h3>';
	$parts[] = '<p>Outsourced takeoffs avoid salary, software seats, and training overhead while keeping bid quality high. You pay for the projects you send, not for idle time between bids.</p>';
	$parts[] = '<h3>24–48 hour delivery</h3>';
	$parts[] = '<p>Most packages return in one to two days so you can submit more jobs before the deadline. If you have a hard bid date, say so when you send the plans and we will confirm a delivery window before work starts.</p>';
	$parts[] = '<h3>99% accurate quantities</h3>';
	$parts[] = '<p>Every report is reviewed for scope, counts, and exclusions before it leaves the team. We document exclusions so your bid letter matches the takeoff and change-order fights do not start on day one.</p>';

	$parts[] = '<h2>How construction estimating services work</h2>';
	$parts[] = '<p>Upload drawings, name the trades, and share addenda. We measure, mark up the plans, and send a quantity sheet you can price. Use a single trade or a full CSI package.</p>';
	$parts[] = '<p>A complete order starts with drawings (PDF preferred), the project name, and the trades you want counted. Addenda and RFIs that arrive mid-count are folded into the same file so you are not bidding two versions of the building.</p>';
	$parts[] = '<p>National contractors use Swift Takeoffs for overflow. Local GCs use us for bid weeks. In both cases the goal is a quantity sheet you can stand behind without redrawing the building.</p>';
	$parts[] = '<p>Hidden surprises usually come from incomplete counts, missed walls, or last-minute scope changes. Construction estimating services close those gaps so you can submit more jobs and protect margin.</p>';

	$parts[] = '<h2>What you receive with every order</h2>';
	$parts[] = '<p>Each package includes a line-item takeoff, color-coded marked-up plans, and a cost-ready breakdown. Drop quantities into Excel or your estimating software and start pricing instead of measuring. That is why contractors use construction estimating services when the bid calendar is full.</p>';
	$parts[] = '<p>After you review the first report, keep the same format for the next deadline. Estimators on your side already know where labor, waste, and vendor quotes belong. We stay in the measuring lane so your team can focus on price, risk, and win strategy.</p>';
	$parts[] = '<p>Turnaround is usually 24–48 hours for standard packages, with a target of 99% accurate quantities. Rush work is available when the bid date is already on the calendar.</p>';

	$parts[] = '<h3>How to get started</h3>';
	$parts[] = '<p>Use the form on this page or visit our <a href="' . esc_url( $quote ) . '">quote page</a>. Share the project name, trade scope, and any addenda. We review the files, prepare the takeoff, and send the report so you can bid.</p>';
	$parts[] = '<p>Whether you need one trade or a multi-building package, measuring stays off your plate. Start with a single project to evaluate the format, then keep construction estimating services on the list when the next bid week hits. Explore other <a href="' . esc_url( $services ) . '">estimating services</a> or return to the <a href="' . esc_url( $home ) . '">Swift Takeoffs homepage</a>.</p>';

	$parts[] = swift_rm_shared_links_html();
	return implode( "\n", $parts );
}

/**
 * Analyzable HTML for hardcoded core page templates.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function swift_rm_build_core_page_html( $post_id ) {
	$post_id  = (int) $post_id;
	$template = get_page_template_slug( $post_id );
	$slug     = get_post_field( 'post_name', $post_id );
	$uri      = get_template_directory_uri();
	$front    = (int) get_option( 'page_on_front' ) === $post_id;
	$parts    = array();

	if ( 'page-swift-takeoffs-landing.php' === $template || in_array( $slug, array( 'construction-estimating-services', 'lp-a' ), true ) ) {
		return swift_rm_build_st_landing_html( $post_id );
	}

	if ( $front || 'front-page.php' === $template ) {
		$parts[] = '<h1>Construction Estimating Services For Seamless Project Success</h1>';
		$parts[] = '<p>At Swift Takeoffs, we deliver construction estimating services that keep residential, commercial, and industrial projects on time and within budget. Our estimators produce accurate takeoffs so contractors can bid with confidence.</p>';
		$parts[] = '<img src="' . esc_url( $uri . '/assets/images/heroimage.svg' ) . '" alt="Construction estimating takeoff plans" />';
		$parts[] = '<h2>Construction Estimating Services We Provide</h2>';
		$parts[] = '<p>Explore professional construction estimating and material takeoff services designed to improve bid accuracy, reduce costs, and support successful projects across the United States.</p>';
		$parts[] = '<h3>Fast Turnaround</h3><p>Most construction estimating packages are returned in 24–48 hours so you can submit more bids.</p>';
		$parts[] = '<h3>Accurate Quantities</h3><p>Detailed construction estimating counts you can price without re-measuring the drawings.</p>';
		$services = function_exists( 'swift_takeoffs_get_all_services' ) ? swift_takeoffs_get_all_services( 8 ) : array();
		if ( $services ) {
			foreach ( $services as $svc ) {
				$parts[] = '<h3><a href="' . esc_url( get_permalink( $svc ) ) . '">' . esc_html( get_the_title( $svc ) ) . '</a></h3>';
			}
		}
		$parts[] = '<h2>Questions About Construction Estimating</h2>';
		$parts[] = '<p>Our construction estimating FAQ covers takeoff scope, file formats, plan review, and typical 24–48 hour delivery.</p>';
	} elseif ( 'page-about.php' === $template || in_array( $slug, array( 'about', 'about-us' ), true ) ) {
		$parts[] = '<h1>About Swift Takeoffs</h1>';
		$parts[] = '<p>About Swift Takeoffs: we are a US construction estimating company that combines precision, expertise, and takeoff software to help contractors bid and build with confidence.</p>';
		$parts[] = '<img src="' . esc_url( $uri . '/assets/images/group-architect-discussing-layout-plan-blueprint-office.svg' ) . '" alt="About Swift Takeoffs estimating team" />';
		$parts[] = '<h2>Why contractors choose About Swift Takeoffs expertise</h2>';
		$parts[] = '<p>About Swift Takeoffs is built on a precision-first approach to material takeoffs, labor, and risk. From residential work to large commercial jobs, we document quantities, assumptions, and exclusions so your bid letter matches the drawings.</p>';
		$parts[] = '<h3>98% bid-winning support</h3><p>Clients use About Swift Takeoffs estimates to submit cleaner numbers and win more work.</p>';
		$parts[] = '<img src="' . esc_url( $uri . '/assets/images/laptop.svg' ) . '" alt="About Swift Takeoffs construction planning" />';
	} elseif ( 'page-contact.php' === $template || in_array( $slug, array( 'contact', 'contact-us' ), true ) ) {
		$parts[] = '<h1>Contact Swift Takeoffs</h1>';
		$parts[] = '<p>Contact our estimating team when you have questions, need a quote, or want to discuss an upcoming project. Contact us by form, phone, or email and we will follow up quickly.</p>';
		$parts[] = '<h2>How to contact Swift Takeoffs</h2>';
		$parts[] = '<p>Use the contact form on this page with your name, email, phone, and project notes. You can also contact us for construction estimating support if you are not sure which trade to request.</p>';
		$parts[] = '<h3>Contact for a free estimating quote</h3>';
		$parts[] = '<p>Prefer a structured intake? Send plans through our quote page after you contact us, or start here and we will tell you what files we need. Contact Swift Takeoffs any weekday for bid-calendar questions.</p>';
		$parts[] = '<img src="' . esc_url( $uri . '/assets/images/logoheader.png' ) . '" alt="Contact Swift Takeoffs" />';
	} elseif ( 'page-get-a-quote.php' === $template || 'get-a-quote' === $slug ) {
		$parts[] = '<h1>Get a construction estimating quote</h1>';
		$parts[] = '<p>Request a quote for construction estimating and material takeoff services. Fill in the quote form, attach plans, and receive a customized estimate—most quotes confirm a 24–48 hour delivery window.</p>';
		$parts[] = '<h2>What we need for your quote</h2>';
		$parts[] = '<p>A complete quote starts with drawings (PDF preferred), project name, and the trades you want counted. The more scope you include in the quote request, the faster we can price the takeoff.</p>';
		$parts[] = '<h3>After you submit a quote</h3>';
		$parts[] = '<p>We review the files, confirm the quote scope, and return bid-ready quantities. Use this quote page whenever you need another trade or addendum counted.</p>';
		$parts[] = '<img src="' . esc_url( $uri . '/assets/images/heroimage.svg' ) . '" alt="Construction estimating quote takeoff sample" />';
	} elseif ( 'services' === $slug ) {
		$parts[] = '<h1>Construction Estimating Services</h1>';
		$parts[] = '<p>Swift Takeoffs provides construction estimating services across residential, commercial, and industrial work. Each service page explains scope, deliverables, and how to request a takeoff.</p>';
		$parts[] = '<h2>Construction Estimating Services by trade</h2>';
		$services = function_exists( 'swift_takeoffs_get_all_services' ) ? swift_takeoffs_get_all_services( -1 ) : array();
		if ( $services ) {
			foreach ( $services as $svc ) {
				$parts[] = '<h3><a href="' . esc_url( get_permalink( $svc ) ) . '">' . esc_html( get_the_title( $svc ) ) . '</a></h3>';
				$desc    = $svc->post_excerpt ? $svc->post_excerpt : wp_trim_words( wp_strip_all_tags( $svc->post_content ), 28 );
				if ( $desc ) {
					$parts[] = '<p>' . esc_html( $desc ) . '</p>';
				}
			}
		}
		$parts[] = '<p>Need a trade that is not listed? Contact us to scope custom construction estimating services.</p>';
	} else {
		return '';
	}

	$parts[] = swift_rm_shared_links_html();
	return implode( "\n", array_filter( $parts ) );
}

/**
 * Analyzable HTML for Rank Math (trade/service CPT, campaign lander, or core templates).
 *
 * @param int $post_id Post ID.
 * @return string
 */
function swift_rm_build_analyzable_html( $post_id ) {
	$post_id = (int) $post_id;
	if ( swift_rm_is_campaign_lander_post( $post_id ) ) {
		return swift_rm_build_lander_content_html( $post_id );
	}

	$type = get_post_type( $post_id );
	if ( in_array( $type, array( 'trade', 'service' ), true ) ) {
		return swift_rm_build_cpt_content_html( $post_id, $type );
	}

	return swift_rm_build_core_page_html( $post_id );
}

/**
 * Frontend: append SCF body so Rank Math robots / snippets that read content see real copy.
 *
 * @param string $content Existing content.
 * @return string
 */
function swift_rm_frontend_content( $content ) {
	if ( ! is_singular() ) {
		return $content;
	}

	$extra = swift_rm_build_analyzable_html( get_the_ID() );
	if ( ! $extra ) {
		return $content;
	}

	return $content . "\n" . $extra;
}
add_filter( 'rank_math/frontend/content', 'swift_rm_frontend_content' );

/**
 * Keep Rank Math metabox editable and after SCF fields (do not block admin SEO).
 *
 * @param string $priority Metabox priority.
 * @return string
 */
function swift_rm_metabox_priority( $priority ) {
	return 'low';
}
add_filter( 'rank_math/metabox/priority', 'swift_rm_metabox_priority' );

/**
 * Soften Rank Math tests that are product upsells / not content-structure issues.
 * Does not disable keyword, length, heading, image, or link checks.
 *
 * @param array  $tests Test map.
 * @param string $type  Object type.
 * @return array
 */
function swift_rm_research_tests( $tests, $type = 'post' ) {
	unset( $tests['contentHasTOC'] );
	unset( $tests['contentAI'] );

	$post_id = 0;
	if ( is_admin() && isset( $_GET['post'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$post_id = absint( $_GET['post'] );
	} elseif ( is_singular() ) {
		$post_id = (int) get_the_ID();
	}

	if ( $post_id && function_exists( 'swift_rm_is_bridged_page' ) && swift_rm_is_bridged_page( $post_id ) ) {
		unset( $tests['keywordInUrl'] );
		unset( $tests['keywordInPermalink'] );
	}

	return $tests;
}
add_filter( 'rank_math/researches/tests', 'swift_rm_research_tests', 10, 2 );

/**
 * Enqueue Rank Math Content Analysis bridge on trade/service edit screens.
 *
 * @param string $hook_suffix Current admin page.
 */
function swift_rm_enqueue_analyzer_bridge( $hook_suffix ) {
	if ( ! in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	if ( ! class_exists( 'RankMath' ) ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen ) {
		return;
	}

	$post_id   = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$is_cpt    = in_array( $screen->post_type, array( 'trade', 'service' ), true );
	$is_page   = ( 'page' === $screen->post_type && $post_id && swift_rm_is_bridged_page( $post_id ) );

	if ( ! $is_cpt && ! $is_page ) {
		return;
	}

	if ( $post_id && swift_rm_is_campaign_lander_post( $post_id ) ) {
		swift_rm_seed_lander_seo_meta( $post_id );
	}
	if ( $post_id && function_exists( 'swift_rm_is_st_landing_post' ) && swift_rm_is_st_landing_post( $post_id ) ) {
		swift_rm_seed_st_landing_seo_meta( $post_id );
	}

	$html = $post_id ? swift_rm_build_analyzable_html( $post_id ) : '';

	$deps = array( 'wp-hooks' );
	if ( wp_script_is( 'rank-math-analyzer', 'registered' ) ) {
		$deps[] = 'rank-math-analyzer';
	} elseif ( wp_script_is( 'rank-math-editor', 'registered' ) ) {
		$deps[] = 'rank-math-editor';
	}

	wp_enqueue_script(
		'swift-rank-math-content',
		get_template_directory_uri() . '/assets/js/rank-math-content.js',
		$deps,
		wp_get_theme()->get( 'Version' ),
		true
	);

	wp_localize_script(
		'swift-rank-math-content',
		'swiftRankMathContent',
		array(
			'html'     => $html,
			'postType' => $screen->post_type,
			'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'swift_rm_content' ),
			'postId'   => $post_id,
		)
	);
}
add_action( 'admin_enqueue_scripts', 'swift_rm_enqueue_analyzer_bridge', 99 );

/**
 * AJAX: rebuild SCF HTML after field edits (so Rank Math score refreshes).
 */
function swift_rm_ajax_refresh_content() {
	check_ajax_referer( 'swift_rm_content', 'nonce' );

	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
	}

	$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( array( 'message' => 'Invalid post' ), 400 );
	}

	$post_type = get_post_type( $post_id );
	$allowed   = in_array( $post_type, array( 'trade', 'service' ), true ) || swift_rm_is_bridged_page( $post_id );
	if ( ! $allowed ) {
		wp_send_json_error( array( 'message' => 'Unsupported type' ), 400 );
	}

	wp_send_json_success(
		array(
			'html' => swift_rm_build_analyzable_html( $post_id ),
		)
	);
}
add_action( 'wp_ajax_swift_rm_refresh_content', 'swift_rm_ajax_refresh_content' );

/**
 * Seed Rank Math meta when a lander page is saved.
 *
 * @param int $post_id Post ID.
 */
function swift_rm_seed_lander_on_save( $post_id ) {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	swift_rm_seed_lander_seo_meta( $post_id );
	swift_rm_seed_st_landing_seo_meta( $post_id );
}
add_action( 'save_post_page', 'swift_rm_seed_lander_on_save', 20 );

/**
 * One-time: fill Rank Math + refresh drywall kit copy that still uses pre-SEO defaults.
 */
function swift_rm_seed_drywall_lander_admin() {
	$page = get_page_by_path( 'drywall-estimating' );
	if ( ! $page ) {
		return;
	}

	swift_rm_seed_lander_seo_meta( $page->ID );

	if ( get_option( 'swift_drywall_seo_copy_v1' ) || ! function_exists( 'update_field' ) ) {
		return;
	}

	$defaults = st_lander_defaults();
	$migrate  = array(
		'st_cl_hero_eyebrow' => 'Drywall estimating for contractors',
		'st_cl_hero_heading' => 'Need Accurate Estimates, Fast?',
		'st_cl_hero_subtext' => 'Get from the team that has delivered cost estimates on over $250M+ in construction projects.',
		'st_cl_why_title'    => 'More time to bid. Better numbers to build on.',
	);

	foreach ( $migrate as $name => $old ) {
		$current = function_exists( 'get_field' ) ? get_field( $name, $page->ID ) : '';
		if ( '' === trim( (string) $current ) || $current === $old ) {
			update_field( $name, $defaults[ $name ], $page->ID );
		}
	}

	update_option( 'swift_drywall_seo_copy_v1', 1, false );
}
add_action( 'admin_init', 'swift_rm_seed_drywall_lander_admin', 30 );

/**
 * Fill Rank Math title/description on Swift Takeoffs Landing pages.
 */
function swift_rm_seed_st_landing_admin() {
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'any',
			'posts_per_page' => 20,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => 'page-swift-takeoffs-landing.php',
			'fields'         => 'ids',
		)
	);
	foreach ( $pages as $page_id ) {
		swift_rm_seed_st_landing_seo_meta( (int) $page_id );
	}

	$by_slug = get_page_by_path( 'construction-estimating-services' );
	if ( $by_slug ) {
		swift_rm_seed_st_landing_seo_meta( $by_slug->ID );
	}
}
add_action( 'admin_init', 'swift_rm_seed_st_landing_admin', 31 );
