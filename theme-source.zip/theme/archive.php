<?php
/**
 * Blog Archive Template — Two column layout with sidebar
 *
 * @package SwiftTakeoffs
 */

get_header();
swift_takeoffs_page_banner( __( 'Our Blogs', 'swift-takeoffs' ), 'blog-archive-banner' );
?>

<section class="blog-archive-sec">
	<div class="container blog-archive-container">

		<!-- ══ LEFT: Posts List ══ -->
		<div class="blog-archive-main">

			<?php if ( have_posts() ) : ?>

				<?php while ( have_posts() ) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-archive-card' ); ?>>

						<!-- Thumbnail -->
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="blog-archive-img">
								<a href="<?php the_permalink(); ?>">
									<?php the_post_thumbnail( 'large', array( 'alt' => get_the_title() ) ); ?>
								</a>
							</div>
						<?php endif; ?>

						<!-- Meta: date -->
						<div class="blog-archive-meta">
							<span class="blog-archive-date">
								<i class="fa-regular fa-clock" aria-hidden="true"></i>
								<?php echo esc_html( get_the_date( 'j F, Y' ) ); ?>
							</span>
						</div>

						<!-- Title -->
						<h2 class="blog-archive-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>

						<!-- Excerpt -->
						<p class="blog-archive-excerpt"><?php echo wp_kses_post( get_the_excerpt() ); ?></p>

						<!-- Read More -->
						<a href="<?php the_permalink(); ?>" class="blog-read-more">
							<?php esc_html_e( 'Read More', 'swift-takeoffs' ); ?>
						</a>

					</article>
				<?php endwhile; ?>

				<!-- Pagination -->
				<div class="blog-archive-pagination">
					<?php
					the_posts_pagination( array(
						'mid_size'           => 1,
						'prev_text'          => '<i class="fa-solid fa-arrow-left"></i>',
						'next_text'          => '<i class="fa-solid fa-arrow-right"></i>',
						'before_page_number' => '',
					) );
					?>
				</div>

			<?php else : ?>
				<p class="no-posts-message"><?php esc_html_e( 'No posts found. Check back soon!', 'swift-takeoffs' ); ?></p>
			<?php endif; ?>

		</div><!-- .blog-archive-main -->

		<!-- ══ RIGHT: Sidebar ══ -->
		<aside class="blog-archive-sidebar">

			<!-- Search -->
			<div class="blog-sidebar-widget">
				<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="blog-search-form">
					<input
						type="search"
						name="s"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Search any Post', 'swift-takeoffs' ); ?>"
						class="blog-search-input"
					>
					<button type="submit" class="blog-search-btn" aria-label="Search">
						<i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
					</button>
				</form>
			</div>

			<!-- Latest Posts -->
			<?php
			$latest_posts = get_posts( array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 5,
				'orderby'        => 'date',
				'order'          => 'DESC',
			) );
			if ( $latest_posts ) :
			?>
			<div class="blog-sidebar-widget blog-sidebar-latest">
				<h3 class="blog-sidebar-title"><?php esc_html_e( 'Latest Posts', 'swift-takeoffs' ); ?></h3>
				<ul class="blog-latest-list">
					<?php foreach ( $latest_posts as $lp ) : ?>
						<li class="blog-latest-item">
							<?php if ( has_post_thumbnail( $lp->ID ) ) : ?>
								<a href="<?php echo esc_url( get_permalink( $lp->ID ) ); ?>" class="blog-latest-thumb">
									<?php echo get_the_post_thumbnail( $lp->ID, array( 60, 60 ), array( 'alt' => get_the_title( $lp->ID ) ) ); ?>
								</a>
							<?php endif; ?>
							<div class="blog-latest-info">
								<a href="<?php echo esc_url( get_permalink( $lp->ID ) ); ?>" class="blog-latest-title">
									<?php echo esc_html( get_the_title( $lp->ID ) ); ?>
								</a>
								<span class="blog-latest-date">
									<?php echo esc_html( get_the_date( 'M d, Y', $lp->ID ) ); ?>
								</span>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<!-- Post Categories -->
			<?php
			$categories = get_categories( array( 'hide_empty' => true ) );
			if ( $categories ) :
			?>
			<div class="blog-sidebar-widget blog-sidebar-cats">
				<h3 class="blog-sidebar-title"><?php esc_html_e( 'Post Categories', 'swift-takeoffs' ); ?></h3>
				<ul class="blog-cats-list">
					<?php foreach ( $categories as $cat ) : ?>
						<li>
							<a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>">
								<?php echo esc_html( $cat->name ); ?>
							</a>
							<span class="blog-cat-count">(<?php echo absint( $cat->count ); ?>)</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<!-- Popular Tags -->
			<?php
			$tags = get_tags( array( 'hide_empty' => true, 'number' => 10, 'orderby' => 'count', 'order' => 'DESC' ) );
			if ( $tags ) :
			?>
			<div class="blog-sidebar-widget blog-sidebar-tags">
				<h3 class="blog-sidebar-title"><?php esc_html_e( 'Popular Tags', 'swift-takeoffs' ); ?></h3>
				<div class="blog-tags-cloud">
					<?php foreach ( $tags as $tag ) : ?>
						<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" class="blog-tag">
							<?php echo esc_html( $tag->name ); ?>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
			<?php endif; ?>

		</aside><!-- .blog-archive-sidebar -->

	</div>
</section>

<?php get_footer(); ?>