<?php
/**
 * Template Name: Privacy Policy
 * Dedicated Privacy Policy page — content lives in this template (not the WP editor).
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$phone   = get_theme_mod( 'swift_phone', '678-825-6967' );
$email   = get_theme_mod( 'swift_email', 'info@swifttakeoffs.com' );
$address = get_theme_mod( 'swift_address', '8 The Green #6092, Dover, 19901' );
$tel     = preg_replace( '/[^0-9+]/', '', $phone );

swift_takeoffs_page_banner( __( 'Privacy Policy', 'swift-takeoffs' ), 'privacy-banner' );
?>

<section class="privacy-page" aria-labelledby="privacy-policy-heading">
	<div class="container container-column">
		<div class="privacy-layout">

			<nav class="privacy-toc" id="privacyToc" aria-label="<?php esc_attr_e( 'Privacy Policy sections', 'swift-takeoffs' ); ?>">
				<button type="button" class="privacy-toc__toggle" id="privacyTocToggle" aria-expanded="false" aria-controls="privacyTocList">
					<span class="privacy-toc__toggle-label"><?php esc_html_e( 'On this page', 'swift-takeoffs' ); ?></span>
					<span class="privacy-toc__current" id="privacyTocCurrent"><?php esc_html_e( 'SMS / mobile', 'swift-takeoffs' ); ?></span>
					<i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
				</button>
				<p class="privacy-toc__heading"><?php esc_html_e( 'On this page', 'swift-takeoffs' ); ?></p>
				<ul class="privacy-toc__list" id="privacyTocList">
					<li><a href="#sms-mobile-information"><?php esc_html_e( 'SMS / mobile', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#information-we-collect"><?php esc_html_e( 'Information we collect', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#how-we-use"><?php esc_html_e( 'How we use it', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#sharing-of-information"><?php esc_html_e( 'Sharing', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#project-confidentiality"><?php esc_html_e( 'Project confidentiality', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#data-retention"><?php esc_html_e( 'Data retention', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#cookies"><?php esc_html_e( 'Cookies', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#data-security"><?php esc_html_e( 'Data security', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#your-privacy-rights"><?php esc_html_e( 'Your rights', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#third-party-links"><?php esc_html_e( 'Third-party links', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#childrens-privacy"><?php esc_html_e( 'Children’s privacy', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#policy-changes"><?php esc_html_e( 'Policy changes', 'swift-takeoffs' ); ?></a></li>
					<li><a href="#privacy-contact"><?php esc_html_e( 'Contact', 'swift-takeoffs' ); ?></a></li>
				</ul>
			</nav>

			<article class="privacy-doc">

				<header class="privacy-doc__intro">
					<p class="privacy-doc__kicker"><?php esc_html_e( 'Swift Takeoffs Inc.', 'swift-takeoffs' ); ?></p>
					<h2 id="privacy-policy-heading"><?php esc_html_e( 'Privacy Policy', 'swift-takeoffs' ); ?></h2>
					<p class="privacy-doc__updated">
						<i class="fa-regular fa-calendar" aria-hidden="true"></i>
						<?php esc_html_e( 'Last updated: August 26, 2026', 'swift-takeoffs' ); ?>
					</p>
					<div class="privacy-doc__lede">
						<p><?php esc_html_e( 'Swift Takeoffs Inc. (“Company,” “We,” “Us,” or “Our”) respects your privacy and is committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website, communicate with us, or use our estimating and quantity takeoff services.', 'swift-takeoffs' ); ?></p>
						<p><?php esc_html_e( 'By accessing our website or using our services, you agree to the collection and use of information in accordance with this Privacy Policy.', 'swift-takeoffs' ); ?></p>
					</div>
				</header>

				<aside class="privacy-sms-callout" id="sms-mobile-information" role="note">
					<div class="privacy-sms-callout__icon" aria-hidden="true">
						<i class="fa-solid fa-shield-halved"></i>
					</div>
					<div class="privacy-sms-callout__body">
						<h3><?php esc_html_e( 'SMS and Mobile Information', 'swift-takeoffs' ); ?></h3>
						<p><?php esc_html_e( 'No mobile information will be shared with third parties/affiliates for marketing/promotional purposes. All other categories exclude text messaging originator opt-in data and consent; this information will not be shared with any third parties.', 'swift-takeoffs' ); ?></p>
					</div>
				</aside>

				<section class="privacy-section" id="information-we-collect">
					<h3><?php esc_html_e( 'Information We Collect', 'swift-takeoffs' ); ?></h3>

					<div class="privacy-split">
						<div class="privacy-split__col">
							<h4><?php esc_html_e( 'Personal Information', 'swift-takeoffs' ); ?></h4>
							<p><?php esc_html_e( 'We may collect personally identifiable information that you voluntarily provide to us, including:', 'swift-takeoffs' ); ?></p>
							<ul class="privacy-list">
								<li><?php esc_html_e( 'Full name', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Company name', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Email address', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Phone number', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Mailing address', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Project information', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Construction plans and specifications', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Payment information', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Any information submitted through contact forms, email, or telephone communications', 'swift-takeoffs' ); ?></li>
							</ul>
						</div>
						<div class="privacy-split__col">
							<h4><?php esc_html_e( 'Automatically Collected Information', 'swift-takeoffs' ); ?></h4>
							<p><?php esc_html_e( 'When you visit our website, we may automatically collect certain information, including:', 'swift-takeoffs' ); ?></p>
							<ul class="privacy-list">
								<li><?php esc_html_e( 'IP address', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Browser type and version', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Device information', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Operating system', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Pages visited', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Date and time of access', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Referring website information', 'swift-takeoffs' ); ?></li>
								<li><?php esc_html_e( 'Website usage statistics', 'swift-takeoffs' ); ?></li>
							</ul>
						</div>
					</div>
				</section>

				<section class="privacy-section" id="how-we-use">
					<h3><?php esc_html_e( 'How We Use Your Information', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. may use collected information to:', 'swift-takeoffs' ); ?></p>
					<ul class="privacy-list privacy-list--cols">
						<li><?php esc_html_e( 'Provide construction estimating and quantity takeoff services', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Prepare and deliver project estimates', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Respond to inquiries and customer requests', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Process payments and invoices', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Improve our services and website functionality', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Communicate project updates, quote reminders, and service-related notifications (including by SMS where you have provided a phone number)', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Provide customer support', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Send promotional and marketing communications (where permitted by law), excluding SMS opt-in data which is never shared', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Comply with legal obligations', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Protect against fraud, unauthorized access, and security threats', 'swift-takeoffs' ); ?></li>
					</ul>
				</section>

				<section class="privacy-section" id="sharing-of-information">
					<h3><?php esc_html_e( 'Sharing of Information', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'We do not sell, rent, or trade your personal information.', 'swift-takeoffs' ); ?></p>
					<p class="privacy-inline-note"><strong><?php esc_html_e( 'No mobile information will be shared with third parties/affiliates for marketing/promotional purposes. All other categories exclude text messaging originator opt-in data and consent; this information will not be shared with any third parties.', 'swift-takeoffs' ); ?></strong></p>

					<div class="privacy-subblocks">
						<div class="privacy-subblock">
							<h4><?php esc_html_e( 'Service Providers', 'swift-takeoffs' ); ?></h4>
							<p><?php esc_html_e( 'We may share limited information with trusted vendors who help us operate our business (for example website hosting, payment processing, email delivery, and analytics). These providers are not permitted to use your information for their own marketing, and they do not receive SMS opt-in data or consent.', 'swift-takeoffs' ); ?></p>
						</div>
						<div class="privacy-subblock">
							<h4><?php esc_html_e( 'Legal Requirements', 'swift-takeoffs' ); ?></h4>
							<p><?php esc_html_e( 'We may disclose information if required to comply with applicable laws and regulations, respond to legal requests or court orders, protect our rights, property, and safety, or prevent fraud or unlawful activities.', 'swift-takeoffs' ); ?></p>
						</div>
						<div class="privacy-subblock">
							<h4><?php esc_html_e( 'Business Transfers', 'swift-takeoffs' ); ?></h4>
							<p><?php esc_html_e( 'In the event of a merger, acquisition, restructuring, or sale of assets, customer information may be transferred as part of the business transaction. SMS opt-in data and consent will remain subject to this Privacy Policy and will not be shared with third parties for marketing or promotional purposes.', 'swift-takeoffs' ); ?></p>
						</div>
					</div>
				</section>

				<section class="privacy-section" id="project-confidentiality">
					<h3><?php esc_html_e( 'Project Confidentiality', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'We understand the importance of protecting construction documents and project-related information.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'Upon request, Swift Takeoffs Inc. is willing to enter into a mutually executed Non-Disclosure Agreement (NDA) before project commencement.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'Unless otherwise restricted by a signed NDA, we may use completed project information, company names, logos, testimonials, and project descriptions for marketing and portfolio purposes.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'We will never intentionally disclose proprietary information that has been designated as confidential by our clients.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="data-retention">
					<h3><?php esc_html_e( 'Data Retention', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'We retain personal and project-related information only for as long as necessary to:', 'swift-takeoffs' ); ?></p>
					<ul class="privacy-list">
						<li><?php esc_html_e( 'Provide services', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Maintain business records', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Fulfill contractual obligations', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Comply with legal requirements', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Resolve disputes and enforce agreements', 'swift-takeoffs' ); ?></li>
					</ul>
					<p><?php esc_html_e( 'When information is no longer required, reasonable measures will be taken to securely delete or anonymize it.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="cookies">
					<h3><?php esc_html_e( 'Cookies and Tracking Technologies', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Our website may use cookies and similar technologies to:', 'swift-takeoffs' ); ?></p>
					<ul class="privacy-list">
						<li><?php esc_html_e( 'Improve website functionality', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Analyze website traffic', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Remember user preferences', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Enhance user experience', 'swift-takeoffs' ); ?></li>
					</ul>
					<p><?php esc_html_e( 'You may choose to disable cookies through your browser settings. However, some website features may not function properly if cookies are disabled.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="data-security">
					<h3><?php esc_html_e( 'Data Security', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. implements reasonable administrative, technical, and physical safeguards designed to protect your information from unauthorized access, disclosure, alteration, or destruction.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'While we strive to use commercially acceptable means to protect your information, no method of electronic transmission or storage is completely secure. Therefore, we cannot guarantee absolute security.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="your-privacy-rights">
					<h3><?php esc_html_e( 'Your Privacy Rights', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Depending on your location and applicable laws, you may have the right to:', 'swift-takeoffs' ); ?></p>
					<ul class="privacy-list privacy-list--cols">
						<li><?php esc_html_e( 'Access your personal information', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Request corrections to inaccurate information', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Request deletion of personal information', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Restrict certain processing activities', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Withdraw consent where applicable, including SMS messaging by replying STOP', 'swift-takeoffs' ); ?></li>
						<li><?php esc_html_e( 'Request a copy of your personal data', 'swift-takeoffs' ); ?></li>
					</ul>
					<p><?php esc_html_e( 'To exercise these rights, please contact us using the information below.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="third-party-links">
					<h3><?php esc_html_e( 'Third-Party Links', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Our website may contain links to third-party websites. We are not responsible for the privacy practices, policies, or content of those websites. We encourage users to review the privacy policies of any external websites they visit.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="childrens-privacy">
					<h3><?php esc_html_e( 'Children’s Privacy', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Our services are intended for business professionals and individuals over the age of 18. We do not knowingly collect personal information from children under the age of 13.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'If we become aware that personal information from a child has been collected without appropriate consent, we will promptly delete such information.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section" id="policy-changes">
					<h3><?php esc_html_e( 'Changes to This Privacy Policy', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Swift Takeoffs Inc. reserves the right to update or modify this Privacy Policy at any time. Any changes will become effective upon posting the revised policy on our website.', 'swift-takeoffs' ); ?></p>
					<p><?php esc_html_e( 'We encourage users to periodically review this page to stay informed about our privacy practices.', 'swift-takeoffs' ); ?></p>
				</section>

				<section class="privacy-section privacy-contact" id="privacy-contact">
					<h3><?php esc_html_e( 'Contact Us', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'If you have any questions regarding this Privacy Policy or our data handling practices, please contact us:', 'swift-takeoffs' ); ?></p>
					<ul class="privacy-contact__list">
						<li>
							<i class="fa-solid fa-building" aria-hidden="true"></i>
							<span><?php esc_html_e( 'Swift Takeoffs Inc.', 'swift-takeoffs' ); ?></span>
						</li>
						<li>
							<i class="fa-solid fa-location-dot" aria-hidden="true"></i>
							<span><?php echo esc_html( $address ); ?></span>
						</li>
						<li>
							<i class="fa-solid fa-phone" aria-hidden="true"></i>
							<a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( $phone ); ?></a>
						</li>
						<li>
							<i class="fa-solid fa-envelope" aria-hidden="true"></i>
							<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
						</li>
					</ul>
				</section>

			</article>
		</div>
	</div>
</section>

<?php
get_footer();
