<?php
/**
 * Swift Takeoffs Theme Functions
 *
 * @package SwiftTakeoffs
 * @version 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================
// 1. THEME SETUP
// ============================================================

if ( ! function_exists( 'swift_takeoffs_setup' ) ) :
	function swift_takeoffs_setup() {

		// Make theme translation-ready
		load_theme_textdomain( 'swift-takeoffs', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to <head>
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the <title> tag
		add_theme_support( 'title-tag' );

		// Enable Post Thumbnails (featured images) on posts and pages
		add_theme_support( 'post-thumbnails' );

		// Register navigation menus
		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary Navigation', 'swift-takeoffs' ),
				'footer'  => esc_html__( 'Footer Quick Links', 'swift-takeoffs' ),
			)
		);

		// Switch default core markup to valid HTML5
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Custom logo support
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 60,
				'width'       => 150,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);

		// Enable Gutenberg wide alignment
		add_theme_support( 'align-wide' );

		// Guides srcset `sizes` for in-content images (~main column width).
		$GLOBALS['content_width'] = 800;
	}
endif;
add_action( 'after_setup_theme', 'swift_takeoffs_setup' );


// ============================================================
// 2. ENQUEUE STYLES & SCRIPTS
// ============================================================

/**
 * Cache-bust asset URLs from filemtime so live CDN/browser cache
 * cannot keep serving an old CSS/JS file after upload.
 *
 * @param string $relative_path Path relative to the theme directory.
 * @return string
 */
function swift_takeoffs_asset_ver( $relative_path ) {
	$file = get_template_directory() . $relative_path;
	if ( file_exists( $file ) ) {
		return (string) filemtime( $file );
	}
	$theme_version = wp_get_theme()->get( 'Version' );
	return $theme_version ? (string) $theme_version : '1.1.2';
}

function swift_takeoffs_enqueue_assets() {

	$theme_uri = get_template_directory_uri();
	$theme_dir = get_template_directory();

	// Campaign lander ships its own CSS/JS. Skip the unused ~90KB theme bundle
	// (Montserrat/Poppins + style.min.css + main.js) so mobile TBT/LCP improve.
	$is_campaign = function_exists( 'swift_takeoffs_is_campaign_lander' ) && swift_takeoffs_is_campaign_lander();

	// Google Fonts (loaded non-blocking via style_loader_tag filter)
	if ( ! $is_campaign ) {
		wp_enqueue_style(
			'swift-google-fonts',
			'https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Poppins:wght@400;500;600;700;800&display=swap',
			array(),
			null
		);
	}

	// Font Awesome full kit — non-blocking; long-term: replace with subset/inline SVG icons
	wp_enqueue_style(
		'swift-font-awesome',
		'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
		array(),
		'6.5.1'
	);

	if ( $is_campaign ) {
		return;
	}

	// Prefer minified CSS when build step has produced it (see package.json)
	$main_css_rel = file_exists( $theme_dir . '/assets/css/style.min.css' )
		? '/assets/css/style.min.css'
		: '/assets/css/style.css';

	// Main theme CSS — no font/FA deps so it is not stalled behind third-party CSS
	wp_enqueue_style(
		'swift-main-style',
		$theme_uri . $main_css_rel,
		array(),
		swift_takeoffs_asset_ver( $main_css_rel )
	);

	$main_js_rel = file_exists( $theme_dir . '/assets/js/main.min.js' )
		? '/assets/js/main.min.js'
		: '/assets/js/main.js';

	wp_enqueue_script(
		'swift-main-js',
		$theme_uri . $main_js_rel,
		array(), // no jQuery
		swift_takeoffs_asset_ver( $main_js_rel ),
		true
	);

	$trades_data = swift_takeoffs_get_trades_data();
	wp_localize_script( 'swift-main-js', 'swiftTradesData', $trades_data );

	wp_localize_script(
		'swift-main-js',
		'swiftThemeData',
		array(
			'themeUrl' => $theme_uri,
			'siteUrl'  => get_site_url(),
			'blogUrl'  => get_permalink( get_option( 'page_for_posts' ) ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'swift_takeoffs_enqueue_assets' );


/**
 * Whether the current page contains a theme form.
 */
function swift_takeoffs_page_has_form() {
	return is_front_page()
		|| is_page( 'contact' )
		|| is_page( 'get-a-quote' )
		|| is_page_template( 'page-contact.php' )
		|| is_page_template( 'page-get-a-quote.php' )
		|| is_page_template( 'page-swift-takeoffs-landing.php' )
		|| is_page_template( 'page-drywall-estimating-landing.php' )
		|| is_page_template( 'page-campaign-lander.php' );
}

/**
 * reCAPTCHA site key — reads ST_RECAPTCHA_SITE_KEY from wp-config.php.
 */
function swift_takeoffs_get_recaptcha_site_key() {
	if ( defined( 'ST_RECAPTCHA_SITE_KEY' ) && ST_RECAPTCHA_SITE_KEY ) {
		return ST_RECAPTCHA_SITE_KEY;
	}
	if ( defined( 'SI_RECAPTCHA_SITE_KEY' ) && SI_RECAPTCHA_SITE_KEY ) {
		return SI_RECAPTCHA_SITE_KEY;
	}
	return '';
}

/**
 * reCAPTCHA secret key — reads ST_RECAPTCHA_SECRET_KEY from wp-config.php.
 */
function swift_takeoffs_get_recaptcha_secret_key() {
	if ( defined( 'ST_RECAPTCHA_SECRET_KEY' ) && ST_RECAPTCHA_SECRET_KEY ) {
		return ST_RECAPTCHA_SECRET_KEY;
	}
	if ( defined( 'SI_RECAPTCHA_SECRET_KEY' ) && SI_RECAPTCHA_SECRET_KEY ) {
		return SI_RECAPTCHA_SECRET_KEY;
	}
	return '';
}

/**
 * Load reCAPTCHA only after the user interacts with a form (cuts TBT / unused JS on first paint).
 */
function swift_takeoffs_enqueue_recaptcha() {
	if ( ! swift_takeoffs_page_has_form() ) {
		return;
	}

	$site_key = swift_takeoffs_get_recaptcha_site_key();
	$api_src  = 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $site_key );

	// Registered for other scripts that may list it as a dependency — not printed until interaction.
	wp_register_script( 'google-recaptcha', $api_src, array(), null, true );

	wp_register_script( 'swift-recaptcha-boot', false, array(), null, true );
	wp_enqueue_script( 'swift-recaptcha-boot' );

	$inline_js = "
(function() {
	var siteKey = " . wp_json_encode( $site_key ) . ";
	var apiSrc = " . wp_json_encode( $api_src ) . ";
	var loading = null;

	function loadRecaptcha() {
		if (window.grecaptcha) {
			return Promise.resolve(window.grecaptcha);
		}
		if (loading) {
			return loading;
		}
		loading = new Promise(function(resolve, reject) {
			var s = document.createElement('script');
			s.src = apiSrc;
			s.async = true;
			s.onload = function() { resolve(window.grecaptcha); };
			s.onerror = reject;
			document.head.appendChild(s);
		});
		return loading;
	}

	function fillTracking(form) {
		try {
			var params = new URLSearchParams(window.location.search);
			['utm_source','utm_medium','utm_campaign','utm_content','utm_term','gclid'].forEach(function(key) {
				var el = form.querySelector('[name=\"' + key + '\"]');
				if (el && params.has(key)) el.value = params.get(key) || '';
			});
			var landing = form.querySelector('[name=\"landing_page\"]');
			if (landing) landing.value = window.location.href;
		} catch (err) {}
	}

	function bindForms() {
		document.querySelectorAll('form').forEach(function(form) {
			if (form.dataset.stRecaptchaBound === '1') { return; }
			// Landing AJAX forms handle their own reCAPTCHA + submit.
			if (form.id === 'heroForm' || form.id === 'contactForm') { return; }
			if (form.classList.contains('st-lead-form')) { return; }
			if (form.classList.contains('st-free-quote-form') || form.hasAttribute('data-fq-form')) { return; }
			var tokenField = form.querySelector('input[name=\"recaptcha_token\"]');
			if (!tokenField) { return; }
			form.dataset.stRecaptchaBound = '1';
			fillTracking(form);
			form.addEventListener('submit', function(e) {
				if (form.dataset.stRecaptchaReady === '1') {
					form.dataset.stRecaptchaReady = '';
					return;
				}
				e.preventDefault();
				fillTracking(form);
				var btn = form.querySelector('[type=\"submit\"]');
				if (btn) btn.disabled = true;
				loadRecaptcha().then(function(grecaptcha) {
					grecaptcha.ready(function() {
						grecaptcha.execute(siteKey, {action: 'submit'}).then(function(token) {
							tokenField.value = token;
							form.dataset.stRecaptchaReady = '1';
							if (btn) btn.disabled = false;
							if (typeof form.requestSubmit === 'function') {
								form.requestSubmit();
							} else {
								form.submit();
							}
						}).catch(function() {
							if (btn) btn.disabled = false;
							alert('Security check failed to load. Please refresh and try again.');
						});
					});
				}).catch(function() {
					if (btn) btn.disabled = false;
					alert('Security check failed to load. Please refresh and try again.');
				});
			});
		});
	}

	function warmOnIntent() {
		loadRecaptcha();
		bindForms();
		document.removeEventListener('pointerdown', warmOnIntent, true);
		document.removeEventListener('keydown', warmOnIntent, true);
		document.removeEventListener('focusin', warmOnIntent, true);
	}

	document.addEventListener('DOMContentLoaded', function() {
		bindForms();
		document.addEventListener('pointerdown', warmOnIntent, true);
		document.addEventListener('keydown', warmOnIntent, true);
		document.addEventListener('focusin', warmOnIntent, true);
	});
})();
";
	wp_add_inline_script( 'swift-recaptcha-boot', $inline_js );
}
add_action( 'wp_enqueue_scripts', 'swift_takeoffs_enqueue_recaptcha', 20 );

/**
 * Assets for the standalone free-quote form (enqueued from the template part).
 */
function swift_takeoffs_enqueue_free_quote_form() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;

	$rel = '/assets/js/free-quote-form.js';
	wp_enqueue_script(
		'swift-free-quote-form',
		get_template_directory_uri() . $rel,
		array(),
		swift_takeoffs_asset_ver( $rel ),
		true
	);

	wp_localize_script(
		'swift-free-quote-form',
		'swiftFreeQuote',
		array(
			'endpoint'         => rest_url( 'swift/v1/quote-request' ),
			'nonce'            => wp_create_nonce( 'wp_rest' ),
			'recaptchaSiteKey' => function_exists( 'swift_takeoffs_get_recaptcha_site_key' )
				? swift_takeoffs_get_recaptcha_site_key()
				: '',
		)
	);
}


/**
 * Defer non-critical scripts.
 */
function swift_takeoffs_script_loader_tag( $tag, $handle, $src ) {
	$defer_handles = array(
		'swift-main-js',
		'emailjs-com',
		'st-landing-js',
		'st-drywall-landing-js',
		'st-campaign-lander-js',
		'swift-recaptcha-boot',
		'swift-free-quote-form',
		'tailwind-cdn',
	);

	if ( in_array( $handle, $defer_handles, true ) && false === strpos( $tag, ' defer' ) ) {
		return str_replace( ' src', ' defer src', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'swift_takeoffs_script_loader_tag', 10, 3 );


/**
 * Load third-party CSS without blocking first paint (media=print → all onload).
 * Main theme CSS stays render-blocking on purpose (needed for LCP layout).
 *
 * @param string $html   Link tag HTML.
 * @param string $handle Style handle.
 * @param string $href   Stylesheet URL.
 * @param string $media  Media attribute.
 * @return string
 */
function swift_takeoffs_style_loader_tag( $html, $handle, $href, $media ) {
	$non_blocking = array(
		'swift-google-fonts',
		'swift-font-awesome',
		'st-landing-poppins',
		'st-drywall-inter',
		'st-campaign-inter',
	);

	if ( ! in_array( $handle, $non_blocking, true ) ) {
		return $html;
	}

	$href_esc = esc_url( $href );
	return '<link rel="stylesheet" id="' . esc_attr( $handle ) . '-css" href="' . $href_esc . '" media="print" onload="this.media=\'all\'" />' . "\n" .
		'<noscript><link rel="stylesheet" href="' . $href_esc . '" /></noscript>' . "\n";
}
add_filter( 'style_loader_tag', 'swift_takeoffs_style_loader_tag', 10, 4 );


// ============================================================
// 2c. SECURITY HARDENING
// ============================================================

remove_action( 'wp_head', 'wp_generator' );


// NOTE: Canonical tag output is now handled by inc/seo-funnel.php (priority chain: meta box → expert data → permalink).
// The old swift_takeoffs_canonical_tag() function has been removed to prevent duplicate <link rel="canonical"> tags.


// ============================================================
// 3. TRADES DATA (centralised — used by front-page & JS)
// ============================================================

function swift_takeoffs_get_trades_data() {
	$img = get_template_directory_uri() . '/assets/images/engineer-builder.svg';

	return array(
		'concrete'    => array(
			'title' => 'Concrete <span>Estimating</span> Service',
			'desc'  => 'Concrete estimating services from Swift Takeoffs are crucial for accurately predicting the costs associated with concrete work, including materials, labor, and associated fees. Whether your project requires foundations, slabs, footings, or walls, Swift Takeoffs provides precise estimates to help you budget accurately, allocate resources effectively, and keep the project on track.',
			'extra' => 'Concrete Estimating Services cover everything from calculating the volume of concrete needed to evaluating the costs of reinforcement materials, such as rebar and additives.',
			'img'   => $img,
		),
		'masonry'     => array(
			'title' => 'Masonry <span>Estimating</span> Service',
			'desc'  => 'Masonry estimating services from Swift Takeoffs are essential for accurately forecasting the costs associated with brick, block, stone, and other masonry work, including materials, labor, and related expenses.',
			'extra' => 'Masonry Estimating Services include precise quantity takeoffs for bricks, CMU blocks, mortar, reinforcement, and accessories, along with labor and equipment assessments.',
			'img'   => $img,
		),
		'plumbing'    => array(
			'title' => 'Plumbing <span>Estimating</span> Service',
			'desc'  => 'Plumbing estimating services from Swift Takeoffs are vital for accurately determining the costs associated with plumbing systems, including piping, fixtures, fittings, and installation labor.',
			'extra' => 'Plumbing Estimating Services cover detailed takeoffs of pipes, valves, fixtures, insulation, and supports, as well as labor and equipment costs.',
			'img'   => $img,
		),
		'earthwork'   => array(
			'title' => 'Earthwork <span>Estimating</span> Service',
			'desc'  => 'Earthwork estimating services from Swift Takeoffs are crucial for calculating the costs associated with site preparation, excavation, grading, and soil stabilization.',
			'extra' => 'Earthwork Estimating Services include detailed quantity calculations for excavation volumes, hauling requirements, compaction needs, and equipment usage.',
			'img'   => $img,
		),
		'electrical'  => array(
			'title' => 'Electrical <span>Estimating</span> Service',
			'desc'  => 'Electrical estimating services from Swift Takeoffs are essential for forecasting the costs related to electrical systems, including wiring, conduits, panels, fixtures, and labor.',
			'extra' => 'Electrical Estimating Services cover detailed material takeoffs for cables, switchgear, panels, lighting fixtures, and devices, along with labor and installation costs.',
			'img'   => $img,
		),
		'utilities'   => array(
			'title' => 'Utilities <span>Estimating</span> Service',
			'desc'  => 'Utilities estimating services from Swift Takeoffs are critical for determining the costs associated with underground and site utility systems, including water, sewer, gas, and storm drainage.',
			'extra' => 'Utilities Estimating Services include accurate quantity takeoffs for piping, manholes, fittings, and related infrastructure.',
			'img'   => $img,
		),
		'specialties' => array(
			'title' => 'Specialties <span>Estimating</span> Service',
			'desc'  => 'Specialties estimating services from Swift Takeoffs are important for accurately assessing the costs of specialty construction items such as signage, access panels, lockers, and miscellaneous architectural components.',
			'extra' => 'Specialties Estimating Services involve detailed quantity takeoffs and cost analysis for all specified specialty components, along with associated labor and installation expenses.',
			'img'   => $img,
		),
		'painting'    => array(
			'title' => 'Painting <span>Estimating</span> Service',
			'desc'  => 'Painting estimating services from Swift Takeoffs are essential for calculating the costs associated with surface preparation, coatings, finishes, and labor.',
			'extra' => 'Painting Estimating Services cover detailed measurements of surface areas, material requirements such as primers and paints, and labor costs for application and finishing.',
			'img'   => $img,
		),
	);
}


// ============================================================
// 4. CUSTOM POST TYPE: Blog Posts use native WordPress Posts
//    (No custom CPT needed — we use the built-in "post" type)
// ============================================================

// Set default post thumbnail size for blog cards
add_image_size( 'swift-blog-thumb', 600, 400, true );


// ============================================================
// 5. CUSTOM EXCERPT LENGTH & READ MORE
// ============================================================

function swift_takeoffs_excerpt_length( $length ) {
	return 25;
}
add_filter( 'excerpt_length', 'swift_takeoffs_excerpt_length', 999 );

function swift_takeoffs_excerpt_more( $more ) {
	return '...';
}
add_filter( 'excerpt_more', 'swift_takeoffs_excerpt_more' );


// ============================================================
// 6. TEMPLATE HELPER FUNCTIONS
// ============================================================

/**
 * Render the page banner used on inner pages.
 *
 * @param string $title      Page title displayed in the banner.
 * @param string $extra_class Additional CSS class for the section.
 */
function swift_takeoffs_page_banner( $title, $extra_class = '' ) {
	$home_url = home_url( '/' );
	?>
	<section class="page-banner <?php echo esc_attr( $extra_class ); ?>">
		<div class="page-banner-overlay"></div>
		<div class="container">
			<div class="page-banner-content">
				<h1><?php echo esc_html( $title ); ?></h1>
				<div class="breadcrumbs">
					<a href="<?php echo esc_url( $home_url ); ?>"><?php esc_html_e( 'Home', 'swift-takeoffs' ); ?></a>
					<i class="fa-solid fa-arrow-right-long"></i>
					<span><?php echo esc_html( $title ); ?></span>
				</div>
			</div>
		</div>
	</section>
	<?php
}

/**
 * Canonical Privacy Policy URL.
 *
 * @return string
 */
function swift_takeoffs_privacy_policy_url() {
	$page = get_page_by_path( 'privacy-policy' );
	return $page ? get_permalink( $page ) : home_url( '/privacy-policy/' );
}

/**
 * Canonical Website Policies / Terms URL.
 *
 * @return string
 */
function swift_takeoffs_terms_url() {
	$page = get_page_by_path( 'terms-and-conditions' );
	return $page ? get_permalink( $page ) : home_url( '/terms-and-conditions/' );
}

/**
 * Return the header logo — custom logo if set, else fallback image.
 */
function swift_takeoffs_header_logo() {
	if ( has_custom_logo() ) {
		the_custom_logo();
	} else {
		$logo_url = get_template_directory_uri() . '/assets/images/logoheader.png';
		echo '<a href="' . esc_url( home_url( '/' ) ) . '">';
		echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" width="150" height="60" loading="lazy">';
		echo '</a>';
	}
}

/**
 * Return the footer logo — custom logo if set, else fallback image.
 */
function swift_takeoffs_footer_logo() {
	$logo_url = get_template_directory_uri() . '/assets/images/logofooter.png';
	echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="footer-logo" width="150" height="60" loading="lazy">';
}


/**
 * Reusable campaign lander (client HTML kit + SCF fields).
 *
 * @return bool
 */
function swift_takeoffs_is_campaign_lander() {
	return is_page_template( 'page-campaign-lander.php' );
}

/**
 * Determine whether the current request should use the minimal landing header/footer.
 *
 * Checks page slugs, known landing templates, an optional query override, and
 * also inspects the request URI so deployments where slugs differ still work.
 *
 * @return bool
 */
function swift_takeoffs_is_landing_page() {
	if ( is_admin() ) {
		return false;
	}

	// Query-string override for testing: append ?st-landing=1 to force landing layout.
	if ( isset( $_GET['st-landing'] ) && '1' === (string) $_GET['st-landing'] ) {
		return true;
	}

	// Known page slugs.
	if ( is_page( array( 'drywall-estimating', 'lp-a' ) ) ) {
		return true;
	}

	if ( function_exists( 'swift_takeoffs_is_campaign_lander' ) && swift_takeoffs_is_campaign_lander() ) {
		return true;
	}

	// Known landing page templates.
	if ( is_page_template( array( 'page-drywall-estimating-landing.php', 'page-swift-takeoffs-landing.php', 'page-campaign-lander.php' ) ) ) {
		return true;
	}

	// Last-resort: inspect REQUEST_URI for expected path segments.
	if ( isset( $_SERVER['REQUEST_URI'] ) ) {
		$uri = untrailingslashit( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		if ( false !== stripos( $uri, '/drywall-estimating' ) || false !== stripos( $uri, '/lp-a' ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Mark campaign landing pages so CSS can disable top-bar scroll hide.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function swift_takeoffs_landing_body_class( $classes ) {
	if ( swift_takeoffs_is_landing_page() ) {
		$classes[] = 'st-landing-page';
	}
	if ( is_page( 'privacy-policy' ) ) {
		$classes[] = 'page-privacy-policy';
		$classes[] = 'page-template-page-privacy-policy';
	}
	if ( is_page( 'terms-and-conditions' ) ) {
		$classes[] = 'page-terms-and-conditions';
		$classes[] = 'page-template-page-terms-and-conditions';
	}
	return $classes;
}
add_filter( 'body_class', 'swift_takeoffs_landing_body_class' );

/**
 * Always render coded legal templates (Privacy Policy, Website Policies).
 *
 * @param string $template Located template path.
 * @return string
 */
function swift_takeoffs_force_legal_page_templates( $template ) {
	$map = array(
		'privacy-policy'       => 'page-privacy-policy.php',
		'terms-and-conditions' => 'page-terms-and-conditions.php',
	);

	foreach ( $map as $slug => $file ) {
		if ( is_page( $slug ) ) {
			$coded = locate_template( $file );
			if ( $coded ) {
				return $coded;
			}
		}
	}

	return $template;
}
add_filter( 'template_include', 'swift_takeoffs_force_legal_page_templates' );


// ============================================================
// 7. WIDGET AREAS (Sidebars)
// ============================================================

function swift_takeoffs_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Blog Sidebar', 'swift-takeoffs' ),
			'id'            => 'swift-blog-sidebar',
			'description'   => esc_html__( 'Add widgets here for the blog sidebar.', 'swift-takeoffs' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'swift_takeoffs_widgets_init' );


// ============================================================
// 8. INCLUDE ADDITIONAL FILES
// ============================================================

require_once get_template_directory() . '/inc/images.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/trade-cpt.php';
require_once get_template_directory() . '/inc/service-cpt.php';
require_once get_template_directory() . '/inc/testimonial-cpt.php';
require_once get_template_directory() . '/inc/form-handler.php';
require_once get_template_directory() . '/inc/lander-fields.php';
require_once get_template_directory() . '/inc/landing-enqueue.php';
require_once get_template_directory() . '/inc/seo-funnel.php';
require_once get_template_directory() . '/inc/rank-math-importer.php';
require_once get_template_directory() . '/inc/rank-math-content.php';


// ============================================================
// 9. ARCHIVE QUERY LIMIT FIX
// ============================================================
// Display all posts on Trade and Service archive pages instead of default 10
function swift_takeoffs_archive_queries( $query ) {
    if ( ! is_admin() && $query->is_main_query() ) {
        if ( is_post_type_archive( 'trade' ) || is_post_type_archive( 'service' ) ) {
            $query->set( 'posts_per_page', -1 );
            $query->set( 'orderby', 'title' );
            $query->set( 'order', 'ASC' );
        }
    }
}
add_action( 'pre_get_posts', 'swift_takeoffs_archive_queries' );


// NOTE: Meta descriptions, OG tags, Twitter cards, JSON-LD schemas, and canonical tags are
// now fully handled by inc/seo-funnel.php with support for the SEO expert data map.
// The old swift_takeoffs_seo_schemas() function has been removed to prevent duplicate output.


