<?php
/**
 * Single Post Template
 * Individual blog post page.
 *
 * @package SwiftTakeoffs
 */

get_header();

if ( have_posts() ) :
	the_post();
	swift_takeoffs_page_banner( get_the_title(), 'blog-single-banner' );
	?>

	<!-- ===== SINGLE POST CONTENT ===== -->
	<section class="single-post-sec">
		<div class="container container-column">

			<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post-article' ); ?>>

				<!-- Featured Image -->
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="single-post-thumbnail">
						<?php the_post_thumbnail( 'full', array( 'class' => 'single-post-img' ) ); ?>
					</div>
				<?php endif; ?>

				<!-- Post Meta -->
				<div class="single-post-meta">
					<span class="post-date">
						<i class="fa-regular fa-calendar" aria-hidden="true"></i>
						<?php echo esc_html( get_the_date( 'd M Y' ) ); ?>
					</span>
					<?php
					$categories = get_the_category();
					if ( $categories ) : ?>
						<span class="post-category">
							<i class="fa-solid fa-folder-open" aria-hidden="true"></i>
							<?php echo esc_html( $categories[0]->name ); ?>
						</span>
					<?php endif; ?>
					<span class="post-author">
						<i class="fa-solid fa-user" aria-hidden="true"></i>
						<?php the_author(); ?>
					</span>
				</div>

				<!-- Post Body -->
				<div class="single-post-body">
					<?php the_content(); ?>
				</div>

				<!-- Post Tags -->
				<?php
				$tags = get_the_tags();
				if ( $tags ) : ?>
					<div class="post-tags">
						<i class="fa-solid fa-tags" aria-hidden="true"></i>
						<?php the_tags( '', ', ' ); ?>
					</div>
				<?php endif; ?>

			</article>

			<!-- Post Navigation -->
			<nav class="post-navigation" aria-label="<?php esc_attr_e( 'Post navigation', 'swift-takeoffs' ); ?>">
				<?php
				the_post_navigation(
					array(
						'prev_text' => '<i class="fa-solid fa-arrow-left"></i> <span>%title</span>',
						'next_text' => '<span>%title</span> <i class="fa-solid fa-arrow-right"></i>',
					)
				);
				?>
			</nav>

			<!-- Related Posts -->
			<?php
			$current_id = get_the_ID();
			$related    = new WP_Query(
				array(
					'post_type'      => 'post',
					'posts_per_page' => 3,
					'post__not_in'   => array( $current_id ),
					'orderby'        => 'rand',
					'post_status'    => 'publish',
				)
			);

			if ( $related->have_posts() ) : ?>
				<div class="related-posts">
					<h3 class="related-posts-title"><?php esc_html_e( 'Related Posts', 'swift-takeoffs' ); ?></h3>
					<div class="blogs-grid">
						<?php while ( $related->have_posts() ) : $related->the_post(); ?>
							<?php get_template_part( 'template-parts/card', 'blog' ); ?>
						<?php endwhile; ?>
					</div>
				</div>
				<?php wp_reset_postdata(); ?>
			<?php endif; ?>

		</div>
	</section>

<?php endif; ?>

<?php get_footer(); ?>
