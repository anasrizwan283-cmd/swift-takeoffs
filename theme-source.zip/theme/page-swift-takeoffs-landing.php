<?php
/**
 * Template Name: Swift Takeoffs Landing
 * Description: Pre-construction estimating landing page with theme header and footer.
 *
 * @package portfolio-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div id="swift-takeoffs-landing" class="st-landing">
	<?php get_template_part( 'template-parts/landing/content' ); ?>
</div>

<?php
get_footer();
