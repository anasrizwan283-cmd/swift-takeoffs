<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-55HC6T6B');</script>
<!-- End Google Tag Manager -->
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Early connections for critical third-parties -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
	<link rel="dns-prefetch" href="https://www.googletagmanager.com">
	<link rel="dns-prefetch" href="https://www.google.com">

	<!-- LCP image preload (fetchpriority hints discovery; do NOT lazy-load this asset) -->
	<?php
	$lcp_image = function_exists( 'swift_takeoffs_lcp_preload_url' ) ? swift_takeoffs_lcp_preload_url() : '';

	if ( ! empty( $lcp_image ) ) {
		printf(
			'<link rel="preload" as="image" href="%s" fetchpriority="high">' . "\n",
			esc_url( $lcp_image )
		);
	}
	?>

	<!-- LocalBusiness Schema for SEO -->
	<script type="application/ld+json">
	<?php
	$schema_address = get_theme_mod( 'swift_address', '8 The Green #6092, Dover, 19901' );
	echo wp_json_encode(
		array(
			'@context'    => 'https://schema.org',
			'@type'       => 'LocalBusiness',
			'name'        => 'Swift Takeoffs',
			'image'       => get_template_directory_uri() . '/assets/images/logoheader.png',
			'url'         => 'https://swifttakeoffs.com',
			'telephone'   => get_theme_mod( 'swift_phone', '678-825-6967' ),
			'email'       => get_theme_mod( 'swift_email', 'info@swifttakeoffs.com' ),
			'address'     => array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => $schema_address,
				'addressLocality' => 'Dover',
				'addressRegion'   => 'DE',
				'postalCode'      => '19901',
				'addressCountry'  => 'US',
			),
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	);
	?>
	</script>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main-content"><?php esc_html_e( 'Skip to content', 'swift-takeoffs' ); ?></a>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55HC6T6B"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<?php
// Campaign lander uses the kit header inside the template.
if ( function_exists( 'swift_takeoffs_is_campaign_lander' ) && swift_takeoffs_is_campaign_lander() ) {
	echo '<main id="main-content">';
	return;
}

// Load minimal landing header for specific pages.
if ( function_exists( 'swift_takeoffs_is_landing_page' ) && swift_takeoffs_is_landing_page() ) {
	get_template_part( 'template-parts/landing/landing-header' );
	return;
}

?>

<header id="site-header">

	<!-- ===== TOP NAVBAR ===== -->
	<div class="top-navbar">
		<div class="container">
			<div class="top-nav-left">
				<div class="top-nav-items">
					<i class="fa-solid fa-phone" aria-hidden="true"></i>
					<span><?php echo esc_html( get_theme_mod( 'swift_phone', '678-825-6967' ) ); ?></span>
				</div>
				<div class="divider" aria-hidden="true">|</div>
				<div class="top-nav-items">
					<i class="fa-solid fa-envelope" aria-hidden="true"></i>
					<span><?php echo esc_html( get_theme_mod( 'swift_email', 'info@swifttakeoffs.com' ) ); ?></span>
				</div>
			</div>
			<div class="top-nav-right">
				<span><?php esc_html_e( 'Follow Us', 'swift-takeoffs' ); ?></span>
				<div class="divider" aria-hidden="true">|</div>
				<div class="social-icons">
					<?php
					$social_links = array(
						'facebook'  => array( 'url' => get_theme_mod( 'swift_facebook', '' ), 'label' => 'Facebook', 'icon' => 'fa-facebook-f' ),
						'instagram' => array( 'url' => get_theme_mod( 'swift_instagram', '' ), 'label' => 'Instagram', 'icon' => 'fa-instagram' ),
						'linkedin'  => array( 'url' => get_theme_mod( 'swift_linkedin', '' ), 'label' => 'LinkedIn', 'icon' => 'fa-linkedin-in' ),
					);
					foreach ( $social_links as $social ) :
						if ( empty( $social['url'] ) || '#' === $social['url'] ) {
							continue;
						}
						?>
					<a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $social['label'] ); ?>"><i class="fa-brands <?php echo esc_attr( $social['icon'] ); ?>" aria-hidden="true"></i></a>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>

	<!-- ===== MAIN NAVBAR ===== -->
	<div class="main-navbar">
		<div class="container">

			<!-- Logo -->
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand">
				<svg width="45" height="39" viewBox="0 0 198 171" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
					<path d="M71.36 140.73L71.53 135.9L77.7 135.88C78.18 135.88 79.14 135.22 79.24 134.75C79.34 134.28 78.61 133.24 78.06 133.24L71.5 133.18V127.53L82.65 127.52C83.21 127.52 84.12 126.94 84.25 126.48C84.38 126.02 83.67 124.87 83.14 124.86L71.49 124.78L71.44 118.99L77.69 118.92C78.21 118.92 79.12 118.29 79.21 117.82C79.3 117.35 78.62 116.3 78.1 116.3L71.47 116.23L71.5 110.49L82.97 110.46C83.47 110.46 84.23 109.59 84.27 109.12C84.31 108.65 83.41 107.75 82.85 107.75L71.53 107.77L71.45 102L77.71 101.97C78.24 101.97 79.18 101.32 79.22 100.84C79.28 100.11 78.43 99.3 77.69 99.3H71.47L71.48 93.53H82.86C83.46 93.53 84.25 92.65 84.26 92.18C84.27 91.71 83.47 90.83 82.98 90.83L71.47 90.79V84.97L77.99 84.89C78.45 84.89 79.26 83.94 79.22 83.49C79.18 83.04 78.37 82.27 77.86 82.26L71.45 82.17L71.47 76.61L82.59 76.57C83.33 76.57 84.27 75.86 84.25 75.23C84.23 74.4 83.43 73.75 82.61 73.75H71.45L71.49 67.93L77.93 67.84C78.33 67.84 79.02 67.2 79.17 66.86C79.35 66.45 78.73 65.27 78.2 65.25L71.48 65.11L71.46 59.39H82.63C83.18 59.4 84.16 58.75 84.24 58.27C84.33 57.76 83.62 56.75 83.08 56.75L71.43 56.67L71.5 50.96L77.98 50.9C78.44 50.9 79.25 49.98 79.23 49.52C79.21 48.99 78.23 48.21 77.68 48.21H71.47V42.45L82.63 42.43C83.05 42.43 83.89 41.98 84.14 41.64C84.43 41.24 83.85 39.8 83.24 39.79L71.48 39.75L71.45 34.12L77.98 34.02C78.44 34.02 79.26 33.08 79.22 32.62C79.18 32.16 78.33 31.39 77.81 31.39L71.49 31.33L71.44 25.66L82.83 25.59C83.34 25.59 84.19 24.8 84.24 24.33C84.29 23.86 83.51 22.91 83.01 22.91L71.45 22.87L71.43 17.13L77.64 17.11C78.13 17.11 79.12 16.5 79.18 16.03C79.24 15.56 78.63 14.67 78.22 14.48L71.51 14.18L92.99 0.119995V161.94L87.53 162.22L87.49 155.91C87.49 155.42 86.88 154.52 86.41 154.42C85.94 154.31 84.84 155.06 84.84 155.67L84.79 162.13L79.03 162.17L79 151.02C79 150.49 78.52 149.63 78.11 149.43C77.7 149.23 76.35 149.79 76.35 150.3L76.27 162.13L70.52 162.18L70.48 156.01" fill="#038CFD"/>
					<path d="M197.77 170.46L154.78 165.62C130.41 162.87 106.18 162.34 81.64 162.88C63.52 163.28 46.13 165.37 28.22 167.22L0 170.14C10.92 167.08 23.81 164.63 33.87 159.7C32.97 158.94 32.59 158.56 32.6 157.79L33.01 126.12H44.5V123.63H32.97L33.05 96.77L62.83 96.86L62.76 104.74L52.45 104.77C52.09 104.77 51.59 105.55 51.67 105.8C51.76 106.06 52.39 106.59 52.74 106.59H62.75L62.82 117.91H52.21V120.4H62.77L62.84 134.94H50.49V137.44H62.76L62.78 147.28H50.49V149.77H62.77L62.87 159.45C64.93 159.49 66.68 159.4 68.78 158.95L93.65 158.14C95.25 158.45 96.57 158.46 98.28 158.12L98.77 79.09L99.02 59.14L122.22 59.16L122.19 74L111.7 74.09C111.35 74.09 110.7 74.25 110.42 74.37C110.06 74.52 110.53 75.96 111 75.96L122.04 76.11L122.07 92.3L108.67 92.22C108.39 93.47 108.39 95.16 108.67 96.51L121.99 96.6L121.97 111.33L111.12 111.42C110.7 111.42 110.15 112.35 110.26 112.64C110.4 113.02 111.16 113.38 111.68 113.39L122.04 113.56L121.97 129.91H110.47C109.96 129.93 110 131.85 110.66 131.85L121.93 131.94L121.87 146.66L110.43 146.77C109.98 146.77 110.03 148.63 110.48 148.63L121.77 148.76L121.88 159.07L128.23 159.38L128.4 136.76L141.48 136.85V132.61L128.34 132.58L128.43 116.39L137.41 116.37L137.73 115.16C137.82 114.8 136.7 114.39 136.25 114.38L128.47 114.29L128.6 107.8L160.58 107.96L160.55 120.98H149.59C148.7 120.98 147.98 121.7 147.98 122.59C147.98 123.24 148.35 123.79 148.89 124.04H149.01L160.51 124.14V124.21L160.43 138.75H149.59C148.7 138.75 147.98 139.48 147.98 140.36C147.98 141.24 148.71 141.97 149.59 141.97H160.4L160.46 149.83H149.59C148.7 149.83 147.98 150.56 147.98 151.44C147.98 152.32 148.71 153.05 149.59 153.05H160.36L160.38 160.77L183.56 166.38L197.76 170.45L197.77 170.46Z" fill="#038CFD"/>
					<path d="M128.65 103.09V85.51L136.67 85.31C136.94 85.31 137.86 85.09 137.82 84.83L137.61 83.65L128.62 83.6L128.7 59.49L158.22 73.55C159.48 74.15 160.33 75.13 160.34 76.58L160.5 84.62L160.69 103.22L128.64 103.08L128.65 103.09Z" fill="#038CFD"/>
					<path d="M55.53 82.6V86.4H62.85L62.79 92.32L32.94 92.16L33.25 63.75C33.28 61.78 34.1 60.25 36.22 59.62L59.66 47.06C60.53 46.59 62.76 45.44 62.81 46.82L62.9 69.12L49.42 69.21C49.35 70.45 49.36 71.4 49.47 72.48L62.88 72.57L62.85 82.6H55.54H55.53Z" fill="#038CFD"/>
					<path d="M108.48 35.15L108.44 39.43L122.18 39.49L122.21 54.58L98.93 54.52L98.38 0L120.16 13.2C121.77 13.9 122.5 15.41 122.4 17.13L122.21 35.18L108.48 35.15Z" fill="#038CFD"/>
				</svg>
				<h2 class="brand-text">Swift <span>Takeoffs</span></h2>
			</a>

			<!-- Navigation -->
			<nav class="nav-menu" role="navigation" aria-label="<?php esc_attr_e( 'Main Navigation', 'swift-takeoffs' ); ?>">
				<ul>

					<!-- Home -->
					<li class="<?php echo is_front_page() ? 'current-menu-item' : ''; ?>">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" <?php echo is_front_page() ? 'class="active"' : ''; ?>>
							<?php esc_html_e( 'Home', 'swift-takeoffs' ); ?>
						</a>
					</li>

					<!-- About Us -->
					<li class="<?php echo is_page( 'about' ) ? 'current-menu-item' : ''; ?>">
						<a href="<?php echo esc_url( home_url( '/about/' ) ); ?>" <?php echo is_page( 'about' ) ? 'class="active"' : ''; ?>>
							<?php esc_html_e( 'About Us', 'swift-takeoffs' ); ?>
						</a>
					</li>

					<!-- Our Services — mega dropdown -->
					<?php $nav_services = function_exists( 'swift_takeoffs_get_all_services' ) ? swift_takeoffs_get_all_services( -1 ) : array(); ?>
					<li class="nav-has-dropdown <?php echo ( is_singular( 'service' ) || is_post_type_archive( 'service' ) ) ? 'current-menu-item' : ''; ?>">
						<a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="nav-dropdown-trigger <?php echo ( is_singular( 'service' ) || is_post_type_archive( 'service' ) ) ? 'active' : ''; ?>">
							<?php esc_html_e( 'Our Services', 'swift-takeoffs' ); ?>
							<i class="fa-solid fa-chevron-down nav-chevron" aria-hidden="true"></i>
						</a>
						<div class="nav-dropdown-panel">
							<div class="nav-dropdown-inner">
								<div class="nav-dropdown-trades">
									<p class="nav-dropdown-heading"><?php esc_html_e( 'Our Services', 'swift-takeoffs' ); ?></p>
									<?php if ( $nav_services ) : ?>
									<ul class="nav-dropdown-list">
										<?php foreach ( $nav_services as $svc ) : ?>
											<li>
												<a href="<?php echo esc_url( get_permalink( $svc->ID ) ); ?>" class="<?php echo ( is_singular( 'service' ) && get_the_ID() === $svc->ID ) ? 'nav-trade-active' : ''; ?>">
													<span class="nav-trade-icon"><i class="fa-solid fa-square-check" aria-hidden="true"></i></span>
													<span class="nav-trade-label"><?php echo esc_html( get_the_title( $svc->ID ) ); ?></span>
												</a>
											</li>
										<?php endforeach; ?>
									</ul>
									<?php endif; ?>
								</div>
								<div class="nav-dropdown-cta">
									<div class="nav-dropdown-cta-inner">
										<i class="fa-solid fa-clipboard-list nav-cta-icon" aria-hidden="true"></i>
										<h4><?php esc_html_e( 'Need a Service Estimate?', 'swift-takeoffs' ); ?></h4>
										<p><?php esc_html_e( 'Get accurate estimates delivered within 24/48 hours by our expert team.', 'swift-takeoffs' ); ?></p>
										<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="nav-cta-btn">
											<?php esc_html_e( 'Get a Free Quote', 'swift-takeoffs' ); ?>
											<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
										</a>
										<a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="nav-all-trades-link">
											<?php esc_html_e( 'View All Services', 'swift-takeoffs' ); ?>
											<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</li>

					<!-- Trades — mega dropdown -->
					<?php $nav_trades = function_exists( 'swift_takeoffs_get_all_trades' ) ? swift_takeoffs_get_all_trades( -1 ) : array(); ?>
					<?php if ( $nav_trades ) : ?>
					<li class="nav-has-dropdown <?php echo ( is_singular( 'trade' ) || is_post_type_archive( 'trade' ) ) ? 'current-menu-item' : ''; ?>">
						<a href="<?php echo esc_url( home_url( '/trades/' ) ); ?>" class="nav-dropdown-trigger <?php echo ( is_singular( 'trade' ) || is_post_type_archive( 'trade' ) ) ? 'active' : ''; ?>">
							<?php esc_html_e( 'Trades', 'swift-takeoffs' ); ?>
							<i class="fa-solid fa-chevron-down nav-chevron" aria-hidden="true"></i>
						</a>
						<div class="nav-dropdown-panel">
							<div class="nav-dropdown-inner">
								<div class="nav-dropdown-trades">
									<p class="nav-dropdown-heading"><?php esc_html_e( 'Our Trade Services', 'swift-takeoffs' ); ?></p>
									<ul class="nav-dropdown-list">
										<?php foreach ( $nav_trades as $nav_trade ) : ?>
											<li>
												<a href="<?php echo esc_url( get_permalink( $nav_trade->ID ) ); ?>" class="<?php echo ( is_singular( 'trade' ) && get_the_ID() === $nav_trade->ID ) ? 'nav-trade-active' : ''; ?>">
													<span class="nav-trade-icon"><i class="fa-solid fa-square-check" aria-hidden="true"></i></span>
													<span class="nav-trade-label"><?php echo esc_html( get_the_title( $nav_trade->ID ) ); ?></span>
												</a>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
								<div class="nav-dropdown-cta">
									<div class="nav-dropdown-cta-inner">
										<i class="fa-solid fa-hard-hat nav-cta-icon" aria-hidden="true"></i>
										<h4><?php esc_html_e( 'Need a Custom Estimate?', 'swift-takeoffs' ); ?></h4>
										<p><?php esc_html_e( 'Get accurate takeoffs delivered within 24/48 hours by our expert estimators.', 'swift-takeoffs' ); ?></p>
										<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="nav-cta-btn">
											<?php esc_html_e( 'Get a Free Quote', 'swift-takeoffs' ); ?>
											<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
										</a>
										<a href="<?php echo esc_url( home_url( '/trades/' ) ); ?>" class="nav-all-trades-link">
											<?php esc_html_e( 'View All Trade Services', 'swift-takeoffs' ); ?>
											<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</li>
					<?php endif; ?>

					<!-- Blog -->
					<?php
					$blog_page_id = get_option( 'page_for_posts' );
					$blog_url     = $blog_page_id ? get_permalink( $blog_page_id ) : home_url( '/blog/' );
					$is_blog      = is_home() || is_singular( 'post' ) || is_category() || is_tag();
					?>
					<li class="<?php echo $is_blog ? 'current-menu-item' : ''; ?>">
						<a href="<?php echo esc_url( $blog_url ); ?>" <?php echo $is_blog ? 'class="active"' : ''; ?>>
							<?php esc_html_e( 'Blog', 'swift-takeoffs' ); ?>
						</a>
					</li>

					<!-- Contact Us -->
					<li class="<?php echo is_page( 'contact' ) ? 'current-menu-item' : ''; ?>">
						<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" <?php echo is_page( 'contact' ) ? 'class="active"' : ''; ?>>
							<?php esc_html_e( 'Contact Us', 'swift-takeoffs' ); ?>
						</a>
					</li>

				</ul>
			</nav>

			<!-- CTA Button -->
			<div class="quote-area">
				<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-quote">
					<?php esc_html_e( 'Get a Free Quote', 'swift-takeoffs' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>

			<!-- Mobile Toggle -->
			<button class="mobile-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle navigation', 'swift-takeoffs' ); ?>" aria-expanded="false">
				<i class="fa-solid fa-bars" aria-hidden="true"></i>
			</button>

		</div>
	</div>

</header>

<main id="main-content">