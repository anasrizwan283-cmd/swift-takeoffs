# Swift Takeoffs — WordPress Custom Theme

A pixel-perfect conversion of the Swift Takeoffs HTML site into a standards-compliant WordPress custom theme.

---

## 📁 Theme File Map

```
swift-takeoffs-theme/
├── style.css                   ← WordPress theme identifier (required)
├── index.php                   ← Fallback template (required by WP)
├── front-page.php              ← Homepage (all sections + dynamic blog)
├── page.php                    ← Generic inner page (Privacy Policy, T&C, etc.)
├── page-about.php              ← About Us page template
├── page-contact.php            ← Contact Us page template
├── page-get-a-quote.php        ← Get A Quote page template
├── single.php                  ← Individual blog post
├── archive.php                 ← Blog listing / archive
├── 404.php                     ← 404 error page
├── header.php                  ← Sitewide header (top bar + main nav)
├── footer.php                  ← Sitewide footer (4-column + bottom bar)
├── functions.php               ← Theme setup, asset enqueue, helpers
├── inc/
│   └── customizer.php          ← WordPress Customizer settings
├── template-parts/
│   ├── card-blog.php           ← Reusable blog post card
│   └── form-quote-home.php     ← Homepage quote form (CF7 fallback)
└── assets/
    ├── css/
    │   └── style.css           ← Full theme stylesheet (original + WP additions)
    ├── js/
    │   └── main.js             ← Theme JavaScript (updated to use wp_localize_script)
    └── images/                 ← All SVG/PNG assets go here
```

---

## 🚀 Installation Steps

### 1. Upload the Theme
- Zip the entire `swift-takeoffs-theme/` folder.
- Go to **WordPress Admin → Appearance → Themes → Add New → Upload Theme**.
- Activate the theme.

### 2. Copy Your Image Assets
- Upload all `.svg` and `.png` image files from your original `assets/images/` folder into `swift-takeoffs-theme/assets/images/`.

### 3. Set Up Pages
Create the following Pages in **WordPress Admin → Pages → Add New**:

| Page Title       | Page Template to Assign  | Slug           |
|------------------|--------------------------|----------------|
| Home             | (set as front page)      | `/`            |
| About Us         | **About Us**             | `/about/`      |
| Contact Us       | **Contact Us**           | `/contact/`    |
| Get A Quote      | **Get A Quote**          | `/get-a-quote/`|
| Privacy Policy   | (Default)                | `/privacy-policy/` |
| Terms & Conditions | (Default)              | `/terms-and-conditions/` |
| Blog             | (set as posts page)      | `/blog/`       |

### 4. Configure Reading Settings
- Go to **Settings → Reading**.
- Set **"Your homepage displays"** to **"A static page"**.
- Set **Homepage** → `Home`.
- Set **Posts page** → `Blog`.

### 5. Set Up Navigation Menus
- Go to **Appearance → Menus → Create a new menu** named `Primary Navigation`.
- Add: Home, About Us, Our Services (dropdown), Trades (dropdown), Contact Us.
- Assign it to the **Primary Navigation** location.
- Create another menu named `Footer Quick Links` and assign to **Footer** location.

### 6. Configure Customizer Settings
- Go to **Appearance → Customize → Contact Information**.
- Set your phone number, email, address, business hours, and social media URLs.
- Go to **Footer Settings** to update footer about text and copyright line.

### 7. (Recommended) Install Contact Form 7
- Install and activate the **Contact Form 7** plugin.
- Create three forms with IDs:
  - `swift-homepage-quote` — Homepage quick quote form
  - `swift-contact` — Contact page form
  - `swift-full-quote` — Full quote page form
- Without CF7, the theme uses clean HTML fallback forms automatically.

---

## 🔄 What's Dynamic vs Static

| Section              | Behaviour    | Notes                                              |
|----------------------|--------------|----------------------------------------------------|
| Blog Posts (homepage)| **Dynamic**  | Pulls latest 3 posts via `WP_Query`                |
| Blog Archive         | **Dynamic**  | Full paginated listing of all posts                |
| Single Blog Post     | **Dynamic**  | Renders any post with featured image, meta, tags   |
| Contact Info         | **Dynamic**  | Editable via Appearance → Customize                |
| Social Links         | **Dynamic**  | Editable via Appearance → Customize                |
| Footer Text          | **Dynamic**  | Editable via Appearance → Customize                |
| Navigation Menus     | **Dynamic**  | Managed via Appearance → Menus                     |
| Trade tabs content   | **Dynamic**  | Data centralised in `functions.php`, passed to JS  |
| Hero, Services, FAQ  | **Static**   | Hardcoded in templates (by design requirement)     |
| Testimonials         | **Static**   | Hardcoded in page-about.php                        |

---

## 🎨 Theme Customizer Options

Located at **Appearance → Customize**:

- **Contact Information**
  - Phone Number
  - Email Address
  - Physical Address
  - Business Hours
  - Website Display Text
- **Social Media URLs**
  - Facebook, Instagram, LinkedIn
- **Footer Settings**
  - Footer About paragraph text
  - Copyright text (HTML allowed)

---

## 📌 WordPress Standards Followed

- All output properly escaped with `esc_html()`, `esc_url()`, `esc_attr()`, `wp_kses_post()`
- All inputs sanitized via `sanitize_text_field()`, `sanitize_email()`, `esc_url_raw()`
- `wp_head()` and `wp_footer()` hooks in place for plugin compatibility
- Scripts/styles enqueued via `wp_enqueue_scripts` action (no hardcoded `<link>` tags)
- Trades data centralised in PHP, passed to JS via `wp_localize_script()` (no hardcoded JS data)
- `text-domain` set for full translation/multilingual readiness
- Template hierarchy followed strictly (`front-page.php`, `page-{slug}.php`, etc.)
- `wp_nonce_field()` used on all HTML fallback forms for CSRF protection
- Custom nav walker for dropdown chevron icons (no plugin needed)
- Custom logo support via `add_theme_support('custom-logo')`
- Featured image support with custom size `swift-blog-thumb` (600×400)
- Accessible markup: `aria-label`, `aria-hidden`, `role` attributes throughout
