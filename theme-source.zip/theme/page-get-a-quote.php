<?php
/**
 * Template Name: Get A Quote
 * Template for the Get a Quote page.
 *
 * @package SwiftTakeoffs
 */

get_header();
swift_takeoffs_page_banner( __( 'Get A Quote', 'swift-takeoffs' ), 'get-quote-banner' );
?>

	<!-- ===== GET QUOTE FORM SECTION ===== -->
	<section class="get-quote-section">
		<div class="container container-column">
			<div class="quote-header">
				<h2><?php esc_html_e( 'Get Estimate Within', 'swift-takeoffs' ); ?> <span><?php esc_html_e( '24/48 Hours', 'swift-takeoffs' ); ?></span></h2>
				<p><?php esc_html_e( 'Have questions? Need a quote? Or just want to discuss your upcoming project? Get in touch with us! Our team is ready and eager to assist you every step of the way.', 'swift-takeoffs' ); ?></p>
			</div>

			<div class="form-card">
				<div class="form-header">
					<h3><?php esc_html_e( 'Get In Touch', 'swift-takeoffs' ); ?></h3>
					<p><?php esc_html_e( 'Fill the below form to resolve any queries or to ask for estimation.', 'swift-takeoffs' ); ?></p>
				</div>

				<?php if ( isset( $_GET['form_success'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['form_success'] ) ) ) : ?>
					<div class="form-success-message" style="background-color: #e6f7ea; color: #1e7e34; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #c3e6cb; font-weight: 600; text-align: center;">
						<?php esc_html_e( 'Thank you! Your submission has been successfully received. We will contact you shortly.', 'swift-takeoffs' ); ?>
					</div>
				<?php elseif ( isset( $_GET['form_error'] ) ) : ?>
					<div class="form-success-message" style="background-color: #fdecea; color: #b71c1c; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #f5c6cb; font-weight: 600; text-align: center;">
						<?php esc_html_e( 'Security check failed. Please try submitting the form again.', 'swift-takeoffs' ); ?>
					</div>
				<?php endif; ?>

				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="quote-form st-theme-lead-form" enctype="multipart/form-data">
					<?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
					<input type="hidden" name="action" value="swift_lead_submission">
					<input type="hidden" name="recaptcha_token" id="recaptcha_token_quote" value="">
					<input type="hidden" name="lead_funnel" value="get-a-quote">
					<input type="hidden" name="utm_source" value="">
					<input type="hidden" name="utm_medium" value="">
					<input type="hidden" name="utm_campaign" value="">
					<input type="hidden" name="utm_content" value="">
					<input type="hidden" name="utm_term" value="">
					<input type="hidden" name="gclid" value="">
					<input type="hidden" name="landing_page" value="">

					<div class="form-row">
						<div class="form-group">
							<label for="fq_name"><?php esc_html_e( 'Name', 'swift-takeoffs' ); ?></label>
							<input type="text" id="fq_name" name="fq_name" placeholder="Kane Williamson" required autocomplete="name">
						</div>
						<div class="form-group">
							<label for="fq_company"><?php esc_html_e( 'Your Company', 'swift-takeoffs' ); ?></label>
							<input type="text" id="fq_company" name="fq_company" placeholder="Your Company Here..." autocomplete="organization">
						</div>
					</div>

					<div class="form-row">
						<div class="form-group">
							<label for="fq_phone"><?php esc_html_e( 'Phone Number', 'swift-takeoffs' ); ?></label>
							<input type="tel" id="fq_phone" name="fq_phone" placeholder="+1 (678) 825-6967" required autocomplete="tel">
						</div>
						<div class="form-group">
							<label for="fq_email"><?php esc_html_e( 'Your Email', 'swift-takeoffs' ); ?></label>
							<input type="email" id="fq_email" name="fq_email" placeholder="you@example.com" required autocomplete="email">
						</div>
					</div>

					<div class="form-row">
						<div class="form-group">
							<label for="fq_file"><?php esc_html_e( 'Upload Your File Here', 'swift-takeoffs' ); ?></label>
							<div class="file-upload-wrapper">
								<label class="file-label" for="fq_file">
									<i class="fa-solid fa-upload" aria-hidden="true"></i>
									<?php esc_html_e( 'Choose File', 'swift-takeoffs' ); ?>
								</label>
								<input type="file" id="fq_file" name="fq_file" class="hidden-input">
								<span class="file-name"><?php esc_html_e( 'No File Chosen', 'swift-takeoffs' ); ?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="fq_scope"><?php esc_html_e( 'Type', 'swift-takeoffs' ); ?></label>
							<input type="text" id="fq_scope" name="fq_scope" placeholder="<?php esc_attr_e( 'Enter Project Type', 'swift-takeoffs' ); ?>" required>
						</div>
					</div>

					<div class="form-group">
						<label for="fq_message"><?php esc_html_e( 'Message', 'swift-takeoffs' ); ?></label>
						<textarea id="fq_message" name="fq_message" rows="6"></textarea>
					</div>

					<?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'quote' ) ); ?>

					<div class="form-submit">
						<button type="submit" class="btn-submit">
							<?php esc_html_e( 'Submit', 'swift-takeoffs' ); ?>
							<i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i>
						</button>
					</div>
				</form>
				<script>
				document.addEventListener('DOMContentLoaded', function() {
					const fileInput = document.getElementById('fq_file');
					const fileNameSpan = document.querySelector('.file-name');
					if (fileInput && fileNameSpan) {
						fileInput.addEventListener('change', function() {
							if (this.files && this.files.length > 0) {
								fileNameSpan.textContent = this.files[0].name;
								fileNameSpan.style.color = '#0163be';
								fileNameSpan.style.fontWeight = '600';
							} else {
								fileNameSpan.textContent = '<?php echo esc_js( __( 'No File Chosen', 'swift-takeoffs' ) ); ?>';
								fileNameSpan.style.color = '';
								fileNameSpan.style.fontWeight = '';
							}
						});
					}
				});
				</script>
			</div>
		</div>
	</section>

<?php get_footer(); ?>
