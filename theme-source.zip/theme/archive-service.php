<?php
/**
 * Service Archive Template
 *
 * 4-column card grid matching the design screenshot.
 * URL: yourdomain.com/services/
 *
 * SCF Fields used per service post:
 *   service_icon        Text  (Font Awesome class e.g. "fa-solid fa-wrench")
 *   service_banner_image Image (URL)
 *   service_main_image   Image (URL)
 *   service_intro_text   Wysiwyg
 *   service_cost_factors Repeater → cost_title, cost_desc
 *   service_takeoff_text Wysiwyg
 *   service_why_items    Repeater → why_title, why_desc
 *   service_why_image    Image (URL)
 *   service_cta_text     Text
 *
 * @package SwiftTakeoffs
 */

get_header();
?>

<!-- ===== PAGE BANNER ===== -->
<?php swift_takeoffs_page_banner( __( 'Our Services', 'swift-takeoffs' ), 'services-archive-banner' ); ?>

<!-- ===== ARCHIVE INTRO ===== -->
<section class="services-archive-sec">
	<div class="container container-column">

		<!-- Section Heading -->
		<div class="services-archive-heading">
			<h2>
				<?php esc_html_e( 'Expert Estimating ', 'swift-takeoffs' ); ?>
				<span><?php esc_html_e( 'Solutions', 'swift-takeoffs' ); ?></span>
			</h2>
			<p><?php esc_html_e( 'We provide comprehensive and accurate estimating services across various construction sectors, ensuring your projects are built on a solid financial foundation.', 'swift-takeoffs' ); ?></p>
		</div>

		<!-- Services Card Grid -->
		<?php if ( have_posts() ) : ?>
			<div class="services-archive-grid">
				<?php while ( have_posts() ) : the_post();
					$icon = get_field( 'service_icon' ) ?: 'fa-solid fa-screwdriver-wrench';
				?>
					<article id="service-<?php the_ID(); ?>" <?php post_class( 'service-archive-card' ); ?>>

						<!-- Icon -->
						<div class="service-card-icon">
							<i class="<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i>
						</div>

						<!-- Title -->
						<h3 class="service-card-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h3>

						<!-- Excerpt -->
						<?php if ( has_excerpt() ) : ?>
							<p class="service-card-desc"><?php the_excerpt(); ?></p>
						<?php endif; ?>

						<!-- CTA Link -->
						<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="service-card-link">
							<?php esc_html_e( 'Request Quote', 'swift-takeoffs' ); ?>
						</a>

					</article>
				<?php endwhile; ?>
			</div>

			<!-- Bottom note -->
			<p class="services-archive-note">
				<?php
				printf(
					wp_kses(
						__( 'Don\'t see the service you\'re looking for? <a href="%s">Contact Us</a> today to discuss your specific project needs.', 'swift-takeoffs' ),
						array( 'a' => array( 'href' => array() ) )
					),
					esc_url( home_url( '/contact/' ) )
				);
				?>
			</p>

		<?php else : ?>
			<div class="no-posts-message">
				<p><?php esc_html_e( 'No services found. Check back soon!', 'swift-takeoffs' ); ?></p>
			</div>
		<?php endif; ?>

	</div>
</section>

<!-- ===== BOTTOM CTA BANNER ===== -->
<section class="services-cta-banner">
	<div class="container">
		<div class="services-cta-content">
			<h2><?php esc_html_e( 'Ready to Streamline Your Bidding Process?', 'swift-takeoffs' ); ?></h2>
			<p><?php esc_html_e( 'Get accurate estimates and takeoffs that help you win more projects and manage costs efficiently.', 'swift-takeoffs' ); ?></p>
		</div>
		<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>" class="btn-primary services-cta-btn">
			<?php esc_html_e( 'Get A Free Quote', 'swift-takeoffs' ); ?>
			<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
		</a>
	</div>
</section>

<?php get_footer(); ?>
