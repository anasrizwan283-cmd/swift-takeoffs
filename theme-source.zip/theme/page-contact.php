<?php
/**
 * Template Name: Contact Us
 * Template for the Contact page.
 *
 * @package SwiftTakeoffs
 */

get_header();
swift_takeoffs_page_banner( __( 'Contact Us', 'swift-takeoffs' ), 'contact-page-banner' );
?>

	<!-- ===== CONTACT MAIN SECTION ===== -->
	<section class="contact-main-section">
		<div class="container container-column">
			<div class="section-header">
				<h2><?php esc_html_e( "We'd Love To Hear", 'swift-takeoffs' ); ?> <span><?php esc_html_e( 'From You!', 'swift-takeoffs' ); ?></span></h2>
				<p><?php esc_html_e( 'Have questions? Need a quote? Or just want to discuss your upcoming project? Get in touch with us! Our team is ready and eager to assist you every step of the way.', 'swift-takeoffs' ); ?></p>
			</div>

			<div class="contact-card">
				<!-- Left: Contact Form -->
				<div class="contact-side-form">
					<h3><?php esc_html_e( 'Contact Form', 'swift-takeoffs' ); ?></h3>
					<?php if ( isset( $_GET['form_success'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['form_success'] ) ) ) : ?>
						<div class="form-success-message" style="background-color: #e6f7ea; color: #1e7e34; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #c3e6cb; font-weight: 600; text-align: center;">
							<?php esc_html_e( 'Thank you! Your submission has been successfully received. We will contact you shortly.', 'swift-takeoffs' ); ?>
						</div>
					<?php elseif ( isset( $_GET['form_error'] ) ) : ?>
						<div class="form-success-message" style="background-color: #fdecea; color: #b71c1c; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #f5c6cb; font-weight: 600; text-align: center;">
							<?php esc_html_e( 'Security check failed. Please try submitting the form again.', 'swift-takeoffs' ); ?>
						</div>
					<?php endif; ?>

					<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="contact-form st-theme-lead-form">
						<?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
						<input type="hidden" name="action" value="swift_lead_submission">
						<input type="hidden" name="recaptcha_token" id="recaptcha_token_contact" value="">
						<input type="hidden" name="lead_funnel" value="contact-page">
						<input type="hidden" name="utm_source" value="">
						<input type="hidden" name="utm_medium" value="">
						<input type="hidden" name="utm_campaign" value="">
						<input type="hidden" name="utm_content" value="">
						<input type="hidden" name="utm_term" value="">
						<input type="hidden" name="gclid" value="">
						<input type="hidden" name="landing_page" value="">
						<div class="form-group">
							<label for="contact_name"><?php esc_html_e( 'Name', 'swift-takeoffs' ); ?></label>
							<input type="text" id="contact_name" name="contact_name" placeholder="Kane Williamson" required autocomplete="name">
						</div>
						<div class="form-group">
							<label for="contact_email"><?php esc_html_e( 'Enter Email', 'swift-takeoffs' ); ?></label>
							<input type="email" id="contact_email" name="contact_email" placeholder="kane789@gmail.com" required autocomplete="email">
						</div>
						<div class="form-group">
							<label for="contact_phone"><?php esc_html_e( 'Phone Number', 'swift-takeoffs' ); ?></label>
							<input type="tel" id="contact_phone" name="contact_phone" placeholder="+1 (678) 825-6967" autocomplete="tel">
						</div>
						<div class="form-group">
							<label for="contact_message"><?php esc_html_e( 'Message', 'swift-takeoffs' ); ?></label>
							<textarea id="contact_message" name="contact_message" rows="5"></textarea>
						</div>
						<?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'contact' ) ); ?>
						<button type="submit" class="btn-blue-pill">
							<?php esc_html_e( 'Submit', 'swift-takeoffs' ); ?>
							<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
						</button>
					</form>
				</div>

				<!-- Right: Map and Info -->
				<div class="contact-side-info">
					<div class="map-container">
						<iframe
							src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.9423846349664!2d-75.52706662342862!3d39.1558281314133!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c764aa7c225e51%3A0x30928ea950d287f4!2s8%20The%20Green%20%236092%2C%20Dover%2C%20DE%2019901%2C%20USA!5e1!3m2!1sen!2s!4v1772141285956!5m2!1sen!2s"
							width="600"
							height="450"
							style="border:0;"
							allowfullscreen=""
							loading="lazy"
							referrerpolicy="no-referrer-when-downgrade"
							title="<?php esc_attr_e( 'Swift Takeoffs Location', 'swift-takeoffs' ); ?>"
						></iframe>
					</div>
					<div class="info-details-panel">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/logoheader.png' ); ?>" alt="<?php esc_attr_e( 'Swift Takeoffs', 'swift-takeoffs' ); ?>" class="info-logo-watermark" width="150" height="60" loading="lazy">
						<div class="info-item">
							<i class="fa-solid fa-house" aria-hidden="true"></i>
							<span>
								<a href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode( get_theme_mod( 'swift_address', '8 The Green #6092, Dover, 19901' ) ); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo esc_html( get_theme_mod( 'swift_address', '8 The Green #6092, Dover, 19901' ) ); ?>
								</a>
							</span>
						</div>
						<div class="info-item">
							<i class="fa-solid fa-phone" aria-hidden="true"></i>
							<span>
								<a href="tel:<?php echo esc_attr( get_theme_mod( 'swift_phone', '678-825-6967' ) ); ?>">
									<?php echo esc_html( get_theme_mod( 'swift_phone', '678-825-6967' ) ); ?>
								</a>
							</span>
						</div>
						<div class="info-item">
							<i class="fa-solid fa-envelope" aria-hidden="true"></i>
							<span>
								<a href="mailto:<?php echo esc_attr( get_theme_mod( 'swift_email', 'info@swifttakeoffs.com' ) ); ?>">
									<?php echo esc_html( get_theme_mod( 'swift_email', 'info@swifttakeoffs.com' ) ); ?>
								</a>
							</span>
						</div>
						<div class="info-item">
							<i class="fa-solid fa-link" aria-hidden="true"></i>
							<span>
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo esc_html( get_theme_mod( 'swift_website', 'www.swifttakeoffs.com' ) ); ?>
								</a>
							</span>
						</div>
						<div class="info-item">
							<i class="fa-solid fa-clock" aria-hidden="true"></i>
							<span><?php echo esc_html( get_theme_mod( 'swift_hours', 'Monday To Friday 8:00 AM To 10:00 PM' ) ); ?></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php get_footer(); ?>
