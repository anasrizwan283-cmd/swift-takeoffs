<?php
/**
 * Template Name: Drywall Estimating Landing
 * Description: Drywall estimating campaign landing — theme header/footer + HTML kit design.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/landing/drywall', 'content' );
get_footer();
