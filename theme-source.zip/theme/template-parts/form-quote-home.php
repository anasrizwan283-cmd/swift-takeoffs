<?php
/**
 * Template Part: Homepage Quote Form
 * Posts to admin-post → Form Leads CPT + admin email.
 *
 * @package SwiftTakeoffs
 */
?>
<?php if ( isset( $_GET['form_success'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['form_success'] ) ) ) : ?>
	<div class="form-success-message" style="background-color: #e6f7ea; color: #1e7e34; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #c3e6cb; font-weight: 600; text-align: center;">
		<?php esc_html_e( 'Thank you! Your submission has been successfully received. We will contact you shortly.', 'swift-takeoffs' ); ?>
	</div>
<?php elseif ( isset( $_GET['form_error'] ) ) : ?>
	<div class="form-success-message" style="background-color: #fdecea; color: #b71c1c; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #f5c6cb; font-weight: 600; text-align: center;">
		<?php esc_html_e( 'Security check failed. Please try submitting the form again.', 'swift-takeoffs' ); ?>
	</div>
<?php endif; ?>

<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="quote-main-form st-theme-lead-form" enctype="multipart/form-data">
	<?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
	<input type="hidden" name="action" value="swift_lead_submission">
	<input type="hidden" name="recaptcha_token" id="recaptcha_token_home" value="">
	<input type="hidden" name="lead_funnel" value="homepage-quote">
	<input type="hidden" name="utm_source" value="">
	<input type="hidden" name="utm_medium" value="">
	<input type="hidden" name="utm_campaign" value="">
	<input type="hidden" name="utm_content" value="">
	<input type="hidden" name="utm_term" value="">
	<input type="hidden" name="gclid" value="">
	<input type="hidden" name="landing_page" value="">

	<div class="form-row">
		<div class="form-group">
			<label for="quote_name"><?php esc_html_e( 'Name', 'swift-takeoffs' ); ?></label>
			<input type="text" id="quote_name" name="quote_name" placeholder="Kane Williamson" required autocomplete="name">
		</div>
		<div class="form-group">
			<label for="quote_phone"><?php esc_html_e( 'Phone', 'swift-takeoffs' ); ?></label>
			<input type="tel" id="quote_phone" name="quote_phone" placeholder="Phone Number" required autocomplete="tel">
		</div>
	</div>

	<div class="form-row">
		<div class="form-group">
			<label for="quote_email"><?php esc_html_e( 'Email', 'swift-takeoffs' ); ?></label>
			<input type="email" id="quote_email" name="quote_email" placeholder="your@email.com" required autocomplete="email">
		</div>
		<div class="form-group">
			<label for="quote_company"><?php esc_html_e( 'Company', 'swift-takeoffs' ); ?></label>
			<input type="text" id="quote_company" name="quote_company" placeholder="Company Name" required autocomplete="organization">
		</div>
	</div>

	<div class="form-group full-width">
		<label for="quote_message"><?php esc_html_e( 'Message', 'swift-takeoffs' ); ?></label>
		<textarea id="quote_message" name="quote_message" placeholder=""></textarea>
	</div>

	<?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'home' ) ); ?>

	<button type="submit" class="btn-primary">
		<?php esc_html_e( 'Send Now', 'swift-takeoffs' ); ?>
		<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
	</button>
</form>
