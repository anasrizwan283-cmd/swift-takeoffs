<?php
/**
 * SMS content disclosure for phone-number forms (Zoom / A2P 10DLC).
 *
 * Optional checkbox plus required disclosure copy. Pass a unique `id`
 * when more than one form appears on the same page.
 *
 * @package SwiftTakeoffs
 *
 * @var array $args {
 *     @type string $id Unique suffix for the checkbox id. Default 'form'.
 * }
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$suffix      = isset( $args['id'] ) ? sanitize_html_class( $args['id'] ) : 'form';
$checkbox_id = 'sms_consent_' . ( $suffix ? $suffix : 'form' );
$privacy_url = function_exists( 'swift_takeoffs_privacy_policy_url' )
	? swift_takeoffs_privacy_policy_url()
	: home_url( '/privacy-policy/' );
?>
<div class="sms-consent">
	<label class="sms-consent__check" for="<?php echo esc_attr( $checkbox_id ); ?>">
		<input type="checkbox" id="<?php echo esc_attr( $checkbox_id ); ?>" name="sms_consent" value="1">
		<span><?php esc_html_e( 'I agree to receive SMS text messages from Swift Takeoffs. Message and data rates may apply.', 'swift-takeoffs' ); ?></span>
	</label>
	<p class="sms-consent__text">
		<?php
		echo wp_kses(
			sprintf(
				/* translators: 1: brand name, 2: privacy policy URL */
				__( 'By providing a telephone number and submitting this form you are consenting to be contacted by SMS text message and receive quote updates, reminders, and notifications from %1$s. Message &amp; data rates may apply. Message frequency may vary. Reply Help for more information. You can reply STOP to opt-out of further messaging. <a href="%2$s">Privacy Policy</a>', 'swift-takeoffs' ),
				'Swift Takeoffs',
				esc_url( $privacy_url )
			),
			array(
				'a' => array(
					'href' => true,
				),
			)
		);
		?>
	</p>
</div>
