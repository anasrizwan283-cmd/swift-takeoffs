<?php
/**
 * Drywall Estimating landing body — matches drywall estimating/index.html kit.
 * Theme header/footer are rendered by the page template.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$img_base    = get_template_directory_uri() . '/assets/landing-drywall/images';
$form_action = admin_url( 'admin-post.php' );
$success     = isset( $_GET['form_success'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['form_success'] ) );
?>
<div id="st-drywall-landing">
	<div id="top">
		<section class="hero" aria-labelledby="hero-title">
			<div class="dw-container hero-grid">
				<div class="hero-copy reveal">
					<p class="eyebrow"><?php esc_html_e( 'Drywall estimating for contractors', 'swift-takeoffs' ); ?></p>
					<h1 id="hero-title"><?php esc_html_e( 'Need Accurate Estimates, Fast?', 'swift-takeoffs' ); ?></h1>
					<p class="lead">
						<?php esc_html_e( 'Get from the team that has delivered cost estimates on over $250M+ in construction projects.', 'swift-takeoffs' ); ?>
					</p>
					<div class="hero-actions">
						<a class="button" href="#quote">
							<?php esc_html_e( 'Get My Free Quote', 'swift-takeoffs' ); ?>
							<span aria-hidden="true">→</span>
						</a>
					</div>
					<ul class="trust-list" aria-label="<?php esc_attr_e( 'Service highlights', 'swift-takeoffs' ); ?>">
						<li><span aria-hidden="true">✓</span> <?php esc_html_e( '24–48 hour delivery', 'swift-takeoffs' ); ?></li>
						<li><span aria-hidden="true">✓</span> <?php esc_html_e( '99% accurate quantities', 'swift-takeoffs' ); ?></li>
						<li><span aria-hidden="true">✓</span> <?php esc_html_e( 'Built for US contractors', 'swift-takeoffs' ); ?></li>
					</ul>
					<div class="review-badges" aria-label="<?php esc_attr_e( 'Customer review platforms', 'swift-takeoffs' ); ?>">
						<div class="review-badge google-review">
							<div class="review-platform">
								<span class="google-mark" aria-hidden="true">G</span>
								<strong><?php esc_html_e( 'Google', 'swift-takeoffs' ); ?></strong>
							</div>
							<div class="review-score">
								<span class="review-label"><i aria-hidden="true">✓</i> <?php esc_html_e( 'Customer Reviews', 'swift-takeoffs' ); ?></span>
								<span class="stars" aria-label="<?php esc_attr_e( 'Five stars', 'swift-takeoffs' ); ?>">★★★★★</span>
							</div>
						</div>
						<div class="review-badge trustpilot-review">
							<div class="review-platform">
								<span class="trustpilot-mark" aria-hidden="true">★</span>
								<strong><?php esc_html_e( 'Trustpilot', 'swift-takeoffs' ); ?></strong>
							</div>
							<div class="review-score">
								<span class="review-label"><?php esc_html_e( 'Excellent', 'swift-takeoffs' ); ?></span>
								<span class="stars" aria-label="<?php esc_attr_e( 'Five stars', 'swift-takeoffs' ); ?>">★★★★★</span>
							</div>
						</div>
					</div>
				</div>

				<aside class="quote-card reveal" id="quote" aria-labelledby="quote-title">
					<div class="quote-heading">
						<p class="eyebrow"><?php esc_html_e( 'Get started', 'swift-takeoffs' ); ?></p>
						<h2 id="quote-title"><?php esc_html_e( 'Get your free quote', 'swift-takeoffs' ); ?></h2>
						<p><?php esc_html_e( 'Tell us about the project. We’ll follow up quickly.', 'swift-takeoffs' ); ?></p>
					</div>

					<?php if ( $success ) : ?>
						<p class="form-message" role="status"><?php esc_html_e( 'Thank you! Your quote request was received.', 'swift-takeoffs' ); ?></p>
					<?php endif; ?>

					<form id="quoteForm" class="dw-lead-form" method="post" action="<?php echo esc_url( $form_action ); ?>" enctype="multipart/form-data" novalidate>
						<?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
						<input type="hidden" name="action" value="swift_lead_submission">
						<input type="hidden" name="recaptcha_token" value="">
						<input type="hidden" name="utm_source" value="">
						<input type="hidden" name="utm_medium" value="">
						<input type="hidden" name="utm_campaign" value="">
						<input type="hidden" name="utm_content" value="">
						<input type="hidden" name="utm_term" value="">
						<input type="hidden" name="gclid" value="">
						<input type="hidden" name="landing_page" value="">
						<input type="hidden" name="lead_funnel" value="drywall-estimating">
						<input type="hidden" name="fq_message" id="fq_message" value="">

						<div class="form-grid">
							<label>
								<?php esc_html_e( 'Name', 'swift-takeoffs' ); ?>
								<input id="name" name="fq_name" autocomplete="name" required>
							</label>
							<label>
								<?php esc_html_e( 'Company', 'swift-takeoffs' ); ?>
								<input id="company" name="fq_company" autocomplete="organization" required>
							</label>
							<label>
								<?php esc_html_e( 'Email', 'swift-takeoffs' ); ?>
								<input id="email" name="fq_email" type="email" autocomplete="email" required>
							</label>
							<label>
								<?php esc_html_e( 'Phone', 'swift-takeoffs' ); ?>
								<input id="phone" name="fq_phone" type="tel" autocomplete="tel" required>
							</label>
						</div>
						<label>
							<?php esc_html_e( 'Project type', 'swift-takeoffs' ); ?>
							<input
								id="projectType"
								name="fq_scope"
								type="text"
								list="tradeSuggestions"
								placeholder="<?php esc_attr_e( 'Enter trade (e.g. drywall, electrical)', 'swift-takeoffs' ); ?>"
								value="<?php esc_attr_e( 'Drywall', 'swift-takeoffs' ); ?>"
								required
							>
							<datalist id="tradeSuggestions">
								<option value="Drywall"></option>
								<option value="Electrical"></option>
								<option value="Plumbing"></option>
								<option value="HVAC"></option>
								<option value="Painting"></option>
								<option value="Framing"></option>
							</datalist>
						</label>
						<label class="file-field">
							<?php esc_html_e( 'Upload plans', 'swift-takeoffs' ); ?>
							<span>(<?php esc_html_e( 'PDF, DWG, or images', 'swift-takeoffs' ); ?>)</span>
							<input id="plans" name="fq_file" type="file" accept=".pdf,.dwg,.dxf,.jpg,.jpeg,.png">
							<span class="file-picker">
								<span aria-hidden="true">↑</span>
								<b id="fileName"><?php esc_html_e( 'Choose files', 'swift-takeoffs' ); ?></b>
							</span>
						</label>
						<?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'drywall' ) ); ?>
						<button class="button form-submit" type="submit">
							<?php esc_html_e( 'Get My Free Quote', 'swift-takeoffs' ); ?>
							<span aria-hidden="true">→</span>
						</button>
						<p class="form-note"><?php esc_html_e( 'Your plans and contact information stay private.', 'swift-takeoffs' ); ?></p>
						<p class="form-message" id="formMessage" role="status" aria-live="polite"></p>
					</form>
				</aside>
			</div>
		</section>

		<section class="logo-marquee" aria-label="<?php esc_attr_e( 'Companies we work with', 'swift-takeoffs' ); ?>">
			<p class="marquee-label"><?php esc_html_e( 'Trusted by construction teams nationwide', 'swift-takeoffs' ); ?></p>
			<div class="marquee-row marquee-row-left">
				<div class="marquee-track">
					<div class="logo-set">
						<?php for ( $i = 1; $i <= 13; $i++ ) : ?>
							<span class="logo-slide">
								<img src="<?php echo esc_url( $img_base . '/company-' . $i . '.svg' ); ?>" alt="<?php esc_attr_e( 'Company logo', 'swift-takeoffs' ); ?>">
							</span>
						<?php endfor; ?>
					</div>
				</div>
			</div>
		</section>

		<section class="section benefits" aria-labelledby="benefits-title">
			<div class="dw-container">
				<div class="section-intro reveal">
					<p class="eyebrow"><?php esc_html_e( 'Why Swift Takeoffs', 'swift-takeoffs' ); ?></p>
					<h2 id="benefits-title"><?php esc_html_e( 'More time to bid. Better numbers to build on.', 'swift-takeoffs' ); ?></h2>
				</div>
				<div class="card-grid">
					<article class="benefit-card reveal">
						<span class="icon" aria-hidden="true">01</span>
						<h3><?php esc_html_e( 'Fast Turnaround', 'swift-takeoffs' ); ?></h3>
						<p><?php esc_html_e( 'Receive a clear, bid-ready estimate in as little as 8–24 hours.', 'swift-takeoffs' ); ?></p>
					</article>
					<article class="benefit-card reveal">
						<span class="icon" aria-hidden="true">02</span>
						<h3><?php esc_html_e( '99% Accurate Quantities', 'swift-takeoffs' ); ?></h3>
						<p><?php esc_html_e( 'Detailed counts and measurements you can rely on when pricing work.', 'swift-takeoffs' ); ?></p>
					</article>
					<article class="benefit-card reveal">
						<span class="icon" aria-hidden="true">03</span>
						<h3><?php esc_html_e( 'Bid More Projects', 'swift-takeoffs' ); ?></h3>
						<p><?php esc_html_e( 'Free your team from takeoffs and keep more opportunities moving.', 'swift-takeoffs' ); ?></p>
					</article>
				</div>
			</div>
		</section>

		<section class="section process" id="sample" aria-labelledby="process-title">
			<div class="dw-container">
				<div class="section-intro centered reveal">
					<p class="eyebrow"><?php esc_html_e( 'A straightforward process', 'swift-takeoffs' ); ?></p>
					<h2 id="process-title"><?php esc_html_e( 'From plans to a confident bid.', 'swift-takeoffs' ); ?></h2>
				</div>
				<ol class="steps">
					<li class="reveal">
						<span>1</span>
						<div>
							<h3><?php esc_html_e( 'Upload Plans', 'swift-takeoffs' ); ?></h3>
							<p><?php esc_html_e( 'Send your drawings and project details.', 'swift-takeoffs' ); ?></p>
						</div>
					</li>
					<li class="reveal">
						<span>2</span>
						<div>
							<h3><?php esc_html_e( 'We Prepare Your Estimate', 'swift-takeoffs' ); ?></h3>
							<p><?php esc_html_e( 'Our team measures every scope item.', 'swift-takeoffs' ); ?></p>
						</div>
					</li>
					<li class="reveal">
						<span>3</span>
						<div>
							<h3><?php esc_html_e( 'Receive Your Report & Win More Jobs', 'swift-takeoffs' ); ?></h3>
							<p><?php esc_html_e( 'Use the finished takeoff to price faster.', 'swift-takeoffs' ); ?></p>
						</div>
					</li>
				</ol>
			</div>
		</section>

		<section class="section testimonials" aria-labelledby="testimonials-title">
			<div class="dw-container">
				<div class="testimonial-heading reveal">
					<div class="section-intro">
						<p class="eyebrow"><?php esc_html_e( 'Contractor feedback', 'swift-takeoffs' ); ?></p>
						<h2 id="testimonials-title"><?php esc_html_e( 'Reviews from contractors who bid to win.', 'swift-takeoffs' ); ?></h2>
					</div>
					<div class="google-review-summary" aria-label="<?php esc_attr_e( 'Google reviews', 'swift-takeoffs' ); ?>">
						<svg class="google-logo-svg" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true">
							<path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
							<path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
							<path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
							<path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
						</svg>
						<div>
							<strong><?php esc_html_e( 'Google Reviews', 'swift-takeoffs' ); ?></strong>
							<span class="g-stars" aria-label="<?php esc_attr_e( 'Five stars', 'swift-takeoffs' ); ?>">
								<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="#FABB05" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
								<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="#FABB05" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
								<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="#FABB05" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
								<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="#FABB05" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
								<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="#FABB05" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
							</span>
						</div>
					</div>
				</div>
				<div class="testimonial-grid">
					<?php
					$google_star = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="#FABB05" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
					$reviews     = array(
						array(
							'initials' => 'JD',
							'avatar'   => '',
							'name'     => 'James Delaney',
							'count'    => __( '7 reviews', 'swift-takeoffs' ),
							'when'     => __( '2 months ago', 'swift-takeoffs' ),
							'text'     => __( 'Saved us hours on our last bid. The quantities were detailed, clear, and ready to price. It gave our team the confidence to move quickly and submit a stronger number before the deadline.', 'swift-takeoffs' ),
						),
						array(
							'initials' => 'MR',
							'avatar'   => 'reviewer-avatar-blue',
							'name'     => 'Maria Rodriguez',
							'count'    => __( '12 reviews', 'swift-takeoffs' ),
							'when'     => __( '4 months ago', 'swift-takeoffs' ),
							'text'     => __( 'The report was more organized than what we had been doing in-house. The scope was easy to follow and everything was ready for pricing. We now use Swift Takeoffs for every serious bid.', 'swift-takeoffs' ),
						),
						array(
							'initials' => 'TW',
							'avatar'   => 'reviewer-avatar-green',
							'name'     => 'Tom Wallace',
							'count'    => __( '5 reviews', 'swift-takeoffs' ),
							'when'     => __( '6 months ago', 'swift-takeoffs' ),
							'text'     => __( 'They turned around a large job quickly and gave us the confidence to submit before the deadline. The takeoff was accurate, straightforward, and saved our estimating team a lot of time.', 'swift-takeoffs' ),
						),
					);
					foreach ( $reviews as $review ) :
						$avatar_class = 'reviewer-avatar' . ( $review['avatar'] ? ' ' . $review['avatar'] : '' );
						?>
					<article class="testimonial g-review-card reveal">
						<div class="reviewer-header">
							<span class="<?php echo esc_attr( $avatar_class ); ?>" aria-hidden="true"><?php echo esc_html( $review['initials'] ); ?></span>
							<div class="reviewer-meta">
								<strong class="reviewer-name"><?php echo esc_html( $review['name'] ); ?></strong>
								<span class="reviewer-count"><?php echo esc_html( $review['count'] ); ?></span>
							</div>
							<button type="button" class="review-menu" aria-label="<?php esc_attr_e( 'More review options', 'swift-takeoffs' ); ?>">
								<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="12" cy="5" r="1.6" fill="#5f6368"/><circle cx="12" cy="12" r="1.6" fill="#5f6368"/><circle cx="12" cy="19" r="1.6" fill="#5f6368"/></svg>
							</button>
						</div>
						<div class="review-rating">
							<span class="g-stars" aria-label="<?php esc_attr_e( 'Five stars', 'swift-takeoffs' ); ?>">
								<?php echo $google_star . $google_star . $google_star . $google_star . $google_star; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG markup ?>
							</span>
							<span class="review-when"><?php echo esc_html( $review['when'] ); ?></span>
						</div>
						<p class="review-body"><?php echo esc_html( $review['text'] ); ?></p>
						<div class="review-source">
							<svg class="google-logo-svg" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
								<path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
								<path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
								<path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
								<path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
							</svg>
							<span><?php esc_html_e( 'Posted on Google', 'swift-takeoffs' ); ?></span>
						</div>
					</article>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<section class="section faq" aria-labelledby="faq-title">
			<div class="dw-container faq-layout">
				<div class="section-intro reveal">
					<p class="eyebrow"><?php esc_html_e( 'FAQ', 'swift-takeoffs' ); ?></p>
					<h2 id="faq-title"><?php esc_html_e( 'Questions, answered.', 'swift-takeoffs' ); ?></h2>
				</div>
				<div class="faq-list reveal">
					<details open>
						<summary>
							<?php esc_html_e( 'How quickly can I receive my estimate?', 'swift-takeoffs' ); ?>
							<span aria-hidden="true">+</span>
						</summary>
						<p><?php esc_html_e( 'Most drywall takeoffs are delivered within 8–24 hours. Tell us if you have a deadline and we’ll confirm availability.', 'swift-takeoffs' ); ?></p>
					</details>
					<details>
						<summary>
							<?php esc_html_e( 'What file formats do you accept?', 'swift-takeoffs' ); ?>
							<span aria-hidden="true">+</span>
						</summary>
						<p><?php esc_html_e( 'We accept PDFs, DWG and DXF files, plus JPG and PNG plan images.', 'swift-takeoffs' ); ?></p>
					</details>
					<details>
						<summary>
							<?php esc_html_e( 'How accurate are your takeoffs?', 'swift-takeoffs' ); ?>
							<span aria-hidden="true">+</span>
						</summary>
						<p><?php esc_html_e( 'Every estimate is reviewed for scope and quantity accuracy, with a target of 99% accurate quantities.', 'swift-takeoffs' ); ?></p>
					</details>
				</div>
			</div>
		</section>

		<section class="final-cta" aria-labelledby="cta-title">
			<div class="dw-container reveal">
				<p class="eyebrow"><?php esc_html_e( 'Ready when you are', 'swift-takeoffs' ); ?></p>
				<h2 id="cta-title">
					<?php esc_html_e( 'Spend less time measuring.', 'swift-takeoffs' ); ?>
					<em><?php esc_html_e( 'Bid with confidence.', 'swift-takeoffs' ); ?></em>
				</h2>
				<p><?php esc_html_e( 'Send your plans today and get a free quote for your next drywall estimate.', 'swift-takeoffs' ); ?></p>
				<a class="button button-light" href="#quote">
					<?php esc_html_e( 'Get My Free Quote', 'swift-takeoffs' ); ?>
					<span aria-hidden="true">→</span>
				</a>
			</div>
		</section>
	</div>
</div>
