<?php
/**
 * Campaign landing footer — brand mark, Privacy Policy link, and click-to-call.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$st_phone = get_theme_mod( 'swift_phone', '678-825-6967' );
$st_tel   = preg_replace( '/[^0-9+]/', '', $st_phone );
?>
<footer class="st-landing-footer" role="contentinfo">
	<div class="st-landing-footer__inner container">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="st-landing-footer__brand">
			<?php get_template_part( 'template-parts/brand-svg', null, array( 'width' => 42, 'height' => 36 ) ); ?>
			<span class="st-landing-footer__name">Swift <em>Takeoffs</em></span>
		</a>

		<div class="st-landing-footer__actions">
			<a href="<?php echo esc_url( swift_takeoffs_privacy_policy_url() ); ?>" class="st-landing-footer__policy">
				<?php esc_html_e( 'Privacy Policy', 'swift-takeoffs' ); ?>
			</a>
			<a href="tel:<?php echo esc_attr( $st_tel ); ?>" class="st-landing-footer__phone" aria-label="<?php echo esc_attr( sprintf( __( 'Call Swift Takeoffs at %s', 'swift-takeoffs' ), $st_phone ) ); ?>">
				<i class="fa-solid fa-phone" aria-hidden="true"></i>
				<span><?php echo esc_html( $st_phone ); ?></span>
			</a>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
