<?php
/**
 * Reusable campaign lander body — client drywall HTML kit, content from SCF/defaults.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$img         = get_template_directory_uri() . '/assets/campaign-lander';
$form_action = admin_url( 'admin-post.php' );
$phone       = get_theme_mod( 'swift_phone', '678-825-6967' );
$tel         = preg_replace( '/[^0-9+]/', '', $phone );
$privacy_url = function_exists( 'swift_takeoffs_privacy_policy_url' ) ? swift_takeoffs_privacy_policy_url() : home_url( '/privacy-policy/' );
$funnel      = st_lander_funnel();
$service     = st_lander_text( 'st_cl_service_type' );
$hero_bg     = st_lander_image_url( 'st_cl_hero_bg', '/assets/campaign-lander/hero-bg.png' );
$cta_bg      = st_lander_image_url( 'st_cl_cta_bg', '/assets/campaign-lander/cta-bg.png' );
$deliv_img   = st_lander_image_url( 'st_cl_deliv_image', '/assets/campaign-lander/deliverables-sample.png' );
$hero_cta    = st_lander_text( 'st_cl_hero_cta' );
$process_cta = st_lander_text( 'st_cl_process_cta' );
$cta_btn     = st_lander_text( 'st_cl_cta_button' );

$logos = array(
	array( 'logo-1.jpg', 'Harmoudi' ),
	array( 'logo-2.jpg', 'SMEC' ),
	array( 'logo-3.jpg', 'UNEC' ),
	array( 'logo-4.png', 'Hutchinson Builders' ),
	array( 'logo-5.png', 'Optimar Consulting' ),
	array( 'logo-6.png', 'ASGC' ),
	array( 'logo-7.png', 'Tecmark Contracting' ),
	array( 'logo-8.png', 'Arcade Star Construction' ),
	array( 'logo-9.png', 'Beaver Gulf' ),
	array( 'logo-10.jpg', 'Dutco Construction' ),
	array( 'logo-11.jpg', 'Al Sahel Contracting' ),
);

$software = array(
	array( 'bluebeam.svg', 'Bluebeam' ),
	array( 'active-takeoff.png', 'Active Takeoff' ),
	array( 'applicad.png', 'AppliCad' ),
	array( 'constructconnect.svg', 'ConstructConnect' ),
	array( 'stack.png', 'STACK' ),
	array( 'on-center.png', 'On Center Software' ),
	array( 'measuresquare.png', 'MeasureSquare' ),
	array( 'viewpoint.png', 'Viewpoint' ),
	array( 'planswift.png', 'PlanSwift' ),
);

$google_icon = '<svg class="google-icon" viewBox="0 0 48 48" aria-hidden="true"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24s.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/></svg>';
?>
<div id="st-campaign-lander">

	<header class="site-header st-landing-header">
		<div class="header-container">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo-link">
				<img src="<?php echo esc_url( $img . '/logo.svg' ); ?>" alt="<?php esc_attr_e( 'Swift Takeoffs', 'swift-takeoffs' ); ?>" class="logo-icon" width="45" height="39">
				<h2 class="logo-heading">Swift <span>Takeoffs</span></h2>
			</a>
			<a href="tel:<?php echo esc_attr( $tel ); ?>" class="call-link" aria-label="<?php echo esc_attr( sprintf( __( 'Call Swift Takeoffs at %s', 'swift-takeoffs' ), $phone ) ); ?>">
				<i class="fa-solid fa-phone" aria-hidden="true"></i>
				<span><?php echo esc_html( $phone ); ?></span>
			</a>
		</div>
	</header>

	<section class="hero" style="background-image: linear-gradient(180deg, rgba(6, 26, 51, 0.15) 0%, rgba(6, 26, 51, 0.35) 100%), url('<?php echo esc_url( $hero_bg ); ?>');">
		<div class="hero-inner">
			<div class="hero-content">
				<div class="hero-main">
					<p class="eyebrow eyebrow--light"><?php echo esc_html( st_lander_text( 'st_cl_hero_eyebrow' ) ); ?></p>
					<h1 class="hero-heading"><?php echo esc_html( st_lander_text( 'st_cl_hero_heading' ) ); ?></h1>
					<p class="hero-subtext"><?php echo esc_html( st_lander_text( 'st_cl_hero_subtext' ) ); ?></p>
					<div class="hero-cta">
						<a href="#quote-form" class="btn btn-primary">
							<?php echo esc_html( $hero_cta ); ?>
							<span class="btn-arrow" aria-hidden="true">&rarr;</span>
						</a>
					</div>
					<ul class="hero-highlights">
						<?php foreach ( st_lander_rows( 'st_cl_highlights' ) as $row ) : ?>
							<li>
								<span class="check-icon"><i class="fa-solid fa-check"></i></span>
								<?php echo esc_html( isset( $row['text'] ) ? $row['text'] : '' ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
					<div class="hero-reviews">
						<div class="review-card">
							<div class="review-card__brand">
								<?php echo $google_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span class="review-card__name"><?php esc_html_e( 'Google', 'swift-takeoffs' ); ?></span>
							</div>
							<div class="review-card__meta">
								<span class="review-card__label"><?php esc_html_e( 'Customer Reviews', 'swift-takeoffs' ); ?></span>
								<span class="review-card__stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
							</div>
						</div>
						<div class="review-card">
							<div class="review-card__brand">
								<span class="trustpilot-icon"><i class="fa-solid fa-star"></i></span>
								<span class="review-card__name"><?php esc_html_e( 'Trustpilot', 'swift-takeoffs' ); ?></span>
							</div>
							<div class="review-card__meta">
								<span class="review-card__label"><?php esc_html_e( 'Excellent', 'swift-takeoffs' ); ?></span>
								<span class="review-card__stars review-card__stars--trustpilot">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
							</div>
						</div>
					</div>
				</div>

				<aside class="quote-form" id="quote-form">
					<div class="quote-form__header">
						<p class="eyebrow eyebrow--dark"><?php echo esc_html( st_lander_text( 'st_cl_form_eyebrow' ) ); ?></p>
						<h2 class="quote-form__title"><?php echo esc_html( st_lander_text( 'st_cl_form_title' ) ); ?></h2>
						<p class="quote-form__subtitle"><?php echo esc_html( st_lander_text( 'st_cl_form_subtitle' ) ); ?></p>
					</div>

					<form class="quote-form__form" id="quote-form-el" method="post" action="<?php echo esc_url( $form_action ); ?>" enctype="multipart/form-data">
						<?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
						<input type="hidden" name="action" value="swift_lead_submission">
						<input type="hidden" name="recaptcha_token" value="">
						<input type="hidden" name="utm_source" value="">
						<input type="hidden" name="utm_medium" value="">
						<input type="hidden" name="utm_campaign" value="">
						<input type="hidden" name="utm_content" value="">
						<input type="hidden" name="utm_term" value="">
						<input type="hidden" name="gclid" value="">
						<input type="hidden" name="landing_page" value="">
						<input type="hidden" name="lead_funnel" value="<?php echo esc_attr( $funnel ); ?>">
						<input type="hidden" name="service_type" value="<?php echo esc_attr( $service ); ?>">

						<div class="form-row">
							<div class="form-field">
								<label for="cl-full-name"><?php esc_html_e( 'Full name *', 'swift-takeoffs' ); ?></label>
								<input type="text" id="cl-full-name" name="fq_name" placeholder="<?php esc_attr_e( 'Jane Contractor', 'swift-takeoffs' ); ?>" required autocomplete="name">
							</div>
							<div class="form-field">
								<label for="cl-company"><?php esc_html_e( 'Company', 'swift-takeoffs' ); ?></label>
								<input type="text" id="cl-company" name="fq_company" placeholder="<?php esc_attr_e( 'Acme Construction', 'swift-takeoffs' ); ?>" autocomplete="organization">
							</div>
						</div>

						<div class="form-row">
							<div class="form-field">
								<label for="cl-email"><?php esc_html_e( 'Email *', 'swift-takeoffs' ); ?></label>
								<input type="email" id="cl-email" name="fq_email" placeholder="<?php esc_attr_e( 'you@company.com', 'swift-takeoffs' ); ?>" required autocomplete="email">
							</div>
							<div class="form-field">
								<label for="cl-phone"><?php esc_html_e( 'Phone *', 'swift-takeoffs' ); ?></label>
								<input type="tel" id="cl-phone" name="fq_phone" placeholder="<?php esc_attr_e( '(555) 123-4567', 'swift-takeoffs' ); ?>" required autocomplete="tel">
							</div>
						</div>

						<div class="form-field">
							<label for="cl-project-name"><?php esc_html_e( 'Project name *', 'swift-takeoffs' ); ?></label>
							<input type="text" id="cl-project-name" name="project_name" placeholder="<?php esc_attr_e( 'e.g. Maple Street Apartments', 'swift-takeoffs' ); ?>" required>
						</div>

						<div class="form-row">
							<div class="form-field">
								<label for="cl-takeoff-level"><?php esc_html_e( 'Takeoff level', 'swift-takeoffs' ); ?></label>
								<select id="cl-takeoff-level" name="takeoff_level">
									<option value="basic"><?php esc_html_e( 'Basic', 'swift-takeoffs' ); ?></option>
									<option value="standard"><?php esc_html_e( 'Standard', 'swift-takeoffs' ); ?></option>
									<option value="detailed"><?php esc_html_e( 'Detailed', 'swift-takeoffs' ); ?></option>
								</select>
							</div>
							<div class="form-field">
								<label for="cl-project-type"><?php esc_html_e( 'Project type', 'swift-takeoffs' ); ?></label>
								<select id="cl-project-type" name="project_type">
									<option value="residential"><?php esc_html_e( 'Residential', 'swift-takeoffs' ); ?></option>
									<option value="commercial"><?php esc_html_e( 'Commercial', 'swift-takeoffs' ); ?></option>
									<option value="industrial"><?php esc_html_e( 'Industrial', 'swift-takeoffs' ); ?></option>
								</select>
							</div>
						</div>

						<div class="form-field">
							<label for="cl-scope"><?php esc_html_e( 'Scope of work / trades needed *', 'swift-takeoffs' ); ?></label>
							<textarea id="cl-scope" name="fq_scope" placeholder="<?php echo esc_attr( sprintf( __( 'e.g. Concrete, framing, %s, electrical…', 'swift-takeoffs' ), strtolower( $service ) ) ); ?>" required></textarea>
						</div>

						<div class="form-field">
							<label for="cl-plan-link"><?php esc_html_e( 'Plan link (Google Drive, Dropbox, WeTransfer…)', 'swift-takeoffs' ); ?></label>
							<input type="url" id="cl-plan-link" name="plan_link" placeholder="https://drive.google.com/…">
							<p class="form-hint"><?php esc_html_e( 'Paste a shareable link to your plans — make sure it’s viewable by anyone with the link.', 'swift-takeoffs' ); ?></p>
						</div>

						<div class="form-field">
							<label for="cl-file-upload"><?php esc_html_e( 'Attach plans / drawings', 'swift-takeoffs' ); ?></label>
							<label for="cl-file-upload" class="upload-box" id="upload-box">
								<i class="fa-solid fa-cloud-arrow-up upload-icon" aria-hidden="true"></i>
								<span class="upload-title"><?php esc_html_e( 'Click to upload or drag & drop', 'swift-takeoffs' ); ?></span>
								<span class="upload-subtitle"><?php esc_html_e( 'PDF, DWG, ZIP — up to 200 MB', 'swift-takeoffs' ); ?></span>
							</label>
							<input type="file" id="cl-file-upload" name="fq_file" hidden accept=".pdf,.dwg,.dxf,.zip,.jpg,.jpeg,.png">
						</div>

						<?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'lander' ) ); ?>

						<div class="form-submit">
							<button type="submit" class="btn btn-primary btn-block">
								<?php echo esc_html( $hero_cta ); ?>
								<span class="btn-arrow" aria-hidden="true">&rarr;</span>
							</button>
							<p class="form-privacy"><?php esc_html_e( 'Your plans and contact information stay private.', 'swift-takeoffs' ); ?></p>
							<p class="form-status" id="cl-form-status" role="status" aria-live="polite" hidden></p>
						</div>
					</form>
				</aside>
			</div>
		</div>
	</section>

	<section class="logos-section">
		<div class="logos-heading-wrap">
			<p class="logos-heading"><?php echo esc_html( st_lander_text( 'st_cl_logos_heading' ) ); ?></p>
		</div>
		<div class="logos-marquee">
			<div class="logos-track">
				<?php for ( $loop = 0; $loop < 2; $loop++ ) : ?>
					<?php foreach ( $logos as $logo ) : ?>
						<img src="<?php echo esc_url( $img . '/logos/' . $logo[0] ); ?>" alt="<?php echo $loop ? '' : esc_attr( $logo[1] ); ?>" <?php echo $loop ? 'aria-hidden="true"' : ''; ?> width="150" height="58" loading="lazy">
					<?php endforeach; ?>
				<?php endfor; ?>
			</div>
		</div>
	</section>

	<section class="why-us">
		<div class="why-us-inner">
			<div class="why-us-heading-block">
				<p class="eyebrow eyebrow--dark"><?php echo esc_html( st_lander_text( 'st_cl_why_eyebrow' ) ); ?></p>
				<h2 class="why-us-title"><?php echo esc_html( st_lander_text( 'st_cl_why_title' ) ); ?></h2>
			</div>
			<div class="feature-grid">
				<?php foreach ( st_lander_rows( 'st_cl_features' ) as $fi => $feature ) : ?>
					<article class="feature-card">
						<div class="feature-icon">
							<?php if ( ! empty( $feature['icon'] ) ) : ?>
								<img src="<?php echo esc_url( $feature['icon'] ); ?>" alt="<?php echo esc_attr( 0 === $fi ? ucfirst( st_lander_focus_keyword() ) : ( isset( $feature['title'] ) ? $feature['title'] : '' ) ); ?>" width="58" height="58" loading="lazy">
							<?php endif; ?>
						</div>
						<h3 class="feature-title"><?php echo esc_html( isset( $feature['title'] ) ? $feature['title'] : '' ); ?></h3>
						<p class="feature-text"><?php echo esc_html( isset( $feature['text'] ) ? $feature['text'] : '' ); ?></p>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="process">
		<div class="process-inner">
			<div class="process-heading-block">
				<p class="eyebrow eyebrow--dark process-eyebrow"><?php echo esc_html( st_lander_text( 'st_cl_process_eyebrow' ) ); ?></p>
				<h2 class="process-title"><?php echo esc_html( st_lander_text( 'st_cl_process_title' ) ); ?></h2>
			</div>
			<div class="process-steps">
				<?php foreach ( st_lander_rows( 'st_cl_steps' ) as $index => $step ) : ?>
					<div class="process-step">
						<div class="process-badge"><span><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span></div>
						<h3 class="process-step-title"><?php echo esc_html( isset( $step['title'] ) ? $step['title'] : '' ); ?></h3>
						<p class="process-step-text"><?php echo esc_html( isset( $step['text'] ) ? $step['text'] : '' ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="process-cta">
				<a href="#quote-form" class="btn btn-primary">
					<?php echo esc_html( $process_cta ); ?>
					<span class="btn-arrow" aria-hidden="true">&rarr;</span>
				</a>
			</div>
		</div>
	</section>

	<section class="expertise">
		<div class="expertise-inner">
			<div class="expertise-heading-block">
				<p class="eyebrow eyebrow--dark"><?php echo esc_html( st_lander_text( 'st_cl_expertise_eyebrow' ) ); ?></p>
				<h2 class="expertise-title"><?php echo esc_html( st_lander_text( 'st_cl_expertise_title' ) ); ?></h2>
			</div>
			<div class="expertise-marquee">
				<div class="expertise-track">
					<?php for ( $loop = 0; $loop < 2; $loop++ ) : ?>
						<?php foreach ( $software as $item ) : ?>
							<img src="<?php echo esc_url( $img . '/software-logos/' . $item[0] ); ?>" alt="<?php echo $loop ? '' : esc_attr( $item[1] ); ?>" <?php echo $loop ? 'aria-hidden="true"' : ''; ?> width="150" height="58" loading="lazy" decoding="async">
						<?php endforeach; ?>
					<?php endfor; ?>
				</div>
			</div>
		</div>
	</section>

	<section class="deliverables">
		<div class="deliverables-inner">
			<div class="deliverables-content">
				<p class="eyebrow eyebrow--dark"><?php echo esc_html( st_lander_text( 'st_cl_deliv_eyebrow' ) ); ?></p>
				<h2 class="deliverables-title"><?php echo esc_html( st_lander_text( 'st_cl_deliv_title' ) ); ?></h2>
				<p class="deliverables-text"><?php echo esc_html( st_lander_text( 'st_cl_deliv_text' ) ); ?></p>
				<ul class="deliverables-list">
					<?php foreach ( st_lander_rows( 'st_cl_deliverables' ) as $item ) : ?>
						<li class="deliverables-item">
							<span class="deliverables-icon" aria-hidden="true"><i class="fa-regular fa-file-lines"></i></span>
							<div class="deliverables-item-body">
								<h3><?php echo esc_html( isset( $item['title'] ) ? $item['title'] : '' ); ?></h3>
								<p><?php echo esc_html( isset( $item['text'] ) ? $item['text'] : '' ); ?></p>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
				<div class="deliverables-compat">
					<span class="deliverables-compat-label"><?php esc_html_e( 'Compatible with', 'swift-takeoffs' ); ?></span>
					<span class="deliverables-badge"><i class="fa-solid fa-file-excel"></i> Excel</span>
					<span class="deliverables-badge"><i class="fa-solid fa-file-pdf"></i> PDF</span>
				</div>
			</div>
			<div class="deliverables-media">
				<div class="deliverables-media-glow" aria-hidden="true"></div>
				<div class="deliverables-media-card">
					<img src="<?php echo esc_url( $deliv_img ); ?>" alt="<?php echo esc_attr( ucfirst( st_lander_focus_keyword() ) . ' marked-up takeoff sample' ); ?>" width="1200" height="800" loading="lazy" decoding="async">
				</div>
			</div>
		</div>
	</section>

	<section class="reviews">
		<div class="reviews-inner">
			<div class="reviews-header">
				<div class="reviews-heading-block">
					<p class="eyebrow eyebrow--dark"><?php echo esc_html( st_lander_text( 'st_cl_reviews_eyebrow' ) ); ?></p>
					<h2 class="reviews-title"><?php echo esc_html( st_lander_text( 'st_cl_reviews_title' ) ); ?></h2>
				</div>
				<div class="google-badge">
					<?php echo $google_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<div class="google-badge-text">
						<span class="google-badge-name"><?php esc_html_e( 'Google Reviews', 'swift-takeoffs' ); ?></span>
						<span class="google-badge-stars" aria-hidden="true">
							<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
						</span>
					</div>
				</div>
			</div>
			<div class="reviews-grid">
				<?php foreach ( st_lander_rows( 'st_cl_reviews' ) as $review ) : ?>
					<?php
					$color = isset( $review['color'] ) ? $review['color'] : 'blue';
					if ( ! in_array( $color, array( 'red', 'blue', 'green' ), true ) ) {
						$color = 'blue';
					}
					?>
					<article class="review-tile">
						<div class="review-tile-head">
							<span class="review-avatar review-avatar--<?php echo esc_attr( $color ); ?>"><?php echo esc_html( isset( $review['initials'] ) ? $review['initials'] : '' ); ?></span>
							<div class="review-tile-person">
								<span class="review-tile-name"><?php echo esc_html( isset( $review['name'] ) ? $review['name'] : '' ); ?></span>
								<span class="review-tile-count"><?php echo esc_html( isset( $review['count'] ) ? $review['count'] : '' ); ?></span>
							</div>
							<span class="review-tile-menu" aria-hidden="true"><i class="fa-solid fa-ellipsis-vertical"></i></span>
						</div>
						<div class="review-tile-rating">
							<span class="review-tile-stars" aria-hidden="true">
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
							</span>
							<span class="review-tile-time"><?php echo esc_html( isset( $review['time'] ) ? $review['time'] : '' ); ?></span>
						</div>
						<p class="review-tile-text"><?php echo esc_html( isset( $review['quote'] ) ? $review['quote'] : '' ); ?></p>
						<div class="review-tile-footer">
							<?php echo str_replace( 'google-icon', 'google-icon google-icon--sm', $google_icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span><?php esc_html_e( 'Posted on Google', 'swift-takeoffs' ); ?></span>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="faq">
		<div class="faq-inner">
			<div class="faq-heading-block">
				<p class="eyebrow eyebrow--dark"><?php echo esc_html( st_lander_text( 'st_cl_faq_eyebrow' ) ); ?></p>
				<h2 class="faq-title"><?php echo esc_html( st_lander_text( 'st_cl_faq_title' ) ); ?></h2>
			</div>
			<div class="faq-list">
				<?php
				$faq_defaults = st_lander_defaults();
				$faq_defaults = isset( $faq_defaults['st_cl_faqs'] ) ? $faq_defaults['st_cl_faqs'] : array();
				foreach ( st_lander_rows( 'st_cl_faqs' ) as $i => $faq ) :
					$question = isset( $faq['question'] ) ? $faq['question'] : '';
					$answer   = isset( $faq['answer'] ) ? trim( (string) $faq['answer'] ) : '';
					if ( '' === $answer && isset( $faq_defaults[ $i ]['answer'] ) ) {
						$answer = $faq_defaults[ $i ]['answer'];
					}
					$panel_id = 'cl-faq-panel-' . ( $i + 1 );
					$is_open  = ( 0 === $i );
					?>
					<div class="faq-item<?php echo $is_open ? ' is-open' : ''; ?>">
						<button
							type="button"
							class="faq-summary"
							aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
							aria-controls="<?php echo esc_attr( $panel_id ); ?>"
						>
							<span class="faq-question"><?php echo esc_html( $question ); ?></span>
							<span class="faq-icon" aria-hidden="true"></span>
						</button>
						<div class="faq-panel" id="<?php echo esc_attr( $panel_id ); ?>">
							<div class="faq-panel-inner">
								<p class="faq-answer"><?php echo esc_html( $answer ); ?></p>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="cta">
		<div class="cta-media" aria-hidden="true" style="background-image: linear-gradient(90deg, #061a33 0%, rgba(6, 26, 51, 0.35) 100%), url('<?php echo esc_url( $cta_bg ); ?>');"></div>
		<div class="cta-content-wrap">
			<div class="cta-content">
				<p class="cta-eyebrow"><?php echo esc_html( st_lander_text( 'st_cl_cta_eyebrow' ) ); ?></p>
				<h2 class="cta-heading"><?php echo esc_html( st_lander_text( 'st_cl_cta_heading' ) ); ?></h2>
				<p class="cta-text"><?php echo esc_html( st_lander_text( 'st_cl_cta_text' ) ); ?></p>
				<div class="cta-actions">
					<a href="#quote-form" class="btn cta-btn">
						<?php echo esc_html( $cta_btn ); ?>
						<span class="btn-arrow" aria-hidden="true">&rarr;</span>
					</a>
				</div>
				<ul class="cta-checklist">
					<?php foreach ( st_lander_rows( 'st_cl_cta_checks' ) as $check ) : ?>
						<li><i class="fa-regular fa-circle-check"></i><?php echo esc_html( isset( $check['text'] ) ? $check['text'] : '' ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</section>

	<footer class="site-footer">
		<div class="footer-container">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo-link">
				<img src="<?php echo esc_url( $img . '/logo.svg' ); ?>" alt="<?php esc_attr_e( 'Swift Takeoffs', 'swift-takeoffs' ); ?>" class="footer-logo-icon">
				<h2 class="footer-logo-heading"><?php esc_html_e( 'Swift Takeoffs', 'swift-takeoffs' ); ?></h2>
			</a>
			<a class="footer-policy-link" href="<?php echo esc_url( $privacy_url ); ?>"><?php esc_html_e( 'Privacy Policy', 'swift-takeoffs' ); ?></a>
			<nav class="footer-seo-links" aria-label="<?php esc_attr_e( 'Related pages', 'swift-takeoffs' ); ?>">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'swift-takeoffs' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Estimating Services', 'swift-takeoffs' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/get-a-quote/' ) ); ?>"><?php esc_html_e( 'Get a Quote', 'swift-takeoffs' ); ?></a>
			</nav>
			<a href="tel:<?php echo esc_attr( $tel ); ?>" class="footer-call-link" aria-label="<?php echo esc_attr( sprintf( __( 'Call Swift Takeoffs at %s', 'swift-takeoffs' ), $phone ) ); ?>">
				<i class="fa-solid fa-phone"></i>
				<span><?php echo esc_html( $phone ); ?></span>
			</a>
		</div>
	</footer>

</div>
