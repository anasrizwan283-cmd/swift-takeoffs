<?php
/**
 * Campaign landing header — theme navbar look, no top bar / menu / quote button.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$st_phone = get_theme_mod( 'swift_phone', '678-825-6967' );
$st_tel   = preg_replace( '/[^0-9+]/', '', $st_phone );
?>
<header id="site-header" class="st-landing-header" role="banner">
	<div class="main-navbar">
		<div class="container">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand">
				<?php get_template_part( 'template-parts/brand-svg' ); ?>
				<h2 class="brand-text">Swift <span>Takeoffs</span></h2>
			</a>

			<a href="tel:<?php echo esc_attr( $st_tel ); ?>" class="btn-quote st-landing-phone" aria-label="<?php echo esc_attr( sprintf( __( 'Call Swift Takeoffs at %s', 'swift-takeoffs' ), $st_phone ) ); ?>">
				<i class="fa-solid fa-phone" aria-hidden="true"></i>
				<span class="phone-number"><?php echo esc_html( $st_phone ); ?></span>
			</a>
		</div>
	</div>
</header>
<main id="main-content">
