<?php
/**
 * Swift Takeoffs landing page body content.
 *
 * @package portfolio-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$landing_uri = get_template_directory_uri() . '/assets/landing';
?>
<div id="st-landing-main" class="st-landing-main bg-slate-50 text-slate-900 antialiased">
      <section
        class="relative bg-cover bg-center bg-no-repeat py-10 sm:py-24"
        style="background-image: url(&quot;<?php echo esc_url( $landing_uri ); ?>/images/hero-bg.svg&quot;)"
      >
        <div class="absolute inset-0 bg-sky-950/85"></div>
        <div class="relative mx-auto max-w-7xl px-5">
          <div class="grid gap-16 lg:grid-cols-2 lg:items-center">
            <div class="space-y-8 text-white lg:max-w-xl">
              <h1
                class="text-4xl font-bold leading-tight tracking-tight sm:text-5xl"
              >
                Construction Estimating Services for Smarter Bids
              </h1>
              <p class="max-w-xl text-lg leading-8 text-slate-200 sm:text-xl">
                Construction estimating services that cut overheads and remove
                hidden surprises — precise estimates that save money, reduce
                risk, and keep every project on budget.
              </p>
              <div
                style="
                  display: flex;
                  gap: 12px;
                  padding: 1.5rem 0;
                  align-items: stretch;
                  flex-wrap: wrap;
                "
              >
                <div class="badge-card">
                  <div
                    style="
                      display: flex;
                      align-items: center;
                      gap: 1px;
                      flex-shrink: 0;
                    "
                  >
                    <svg
                      width="28"
                      height="28"
                      viewBox="0 0 48 48"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M43.6 20H24v8h11.3C33.5 33.3 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.7 1.1 7.8 2.9l5.7-5.7C33.9 6.6 29.2 4.5 24 4.5 12.7 4.5 3.5 13.7 3.5 25S12.7 45.5 24 45.5c11 0 20.5-8 20.5-20.5 0-1.4-0.1-2.7-0.4-4z"
                        fill="#FFC107"
                      />
                      <path
                        d="M6.3 14.7l6.6 4.8C14.5 15.1 18.9 12 24 12c3 0 5.7 1.1 7.8 2.9l5.7-5.7C33.9 6.6 29.2 4.5 24 4.5c-7.6 0-14.2 4.3-17.7 10.2z"
                        fill="#FF3D00"
                      />
                      <path
                        d="M24 45.5c5.1 0 9.8-1.9 13.4-5.1l-6.2-5.2C29.3 36.8 26.8 37.5 24 37.5c-5.2 0-9.6-3.5-11.2-8.3l-6.5 5C9.6 41.1 16.3 45.5 24 45.5z"
                        fill="#4CAF50"
                      />
                      <path
                        d="M43.6 20H24v8h11.3c-0.9 2.4-2.5 4.4-4.5 5.8l6.2 5.2C40.8 35.4 44.5 29.8 44.5 24c0-1.4-0.1-2.7-0.4-4h-0.5z"
                        fill="#1976D2"
                      />
                    </svg>
                    <span
                      style="font-size: 16px; font-weight: 500; color: #0f172a"
                      >oogle</span
                    >
                  </div>

                  <div class="divider-v"></div>

                  <div>
                    <div
                      style="
                        display: flex;
                        align-items: center;
                        gap: 5px;
                        margin-bottom: 2px;
                      "
                    >
                      <div
                        style="
                          width: 14px;
                          height: 14px;
                          background: #1a73e8;
                          border-radius: 50%;
                          display: flex;
                          align-items: center;
                          justify-content: center;
                          flex-shrink: 0;
                        "
                      >
                        <svg
                          width="8"
                          height="8"
                          viewBox="0 0 10 10"
                          fill="none"
                        >
                          <path
                            d="M2 5l2.5 2.5L8 3"
                            stroke="white"
                            stroke-width="1.6"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          />
                        </svg>
                      </div>
                      <span class="sublabel" style="margin: 0"
                        >Customer Reviews</span
                      >
                    </div>
                    <div class="stars-row">
                      <span class="star-g">★</span>
                      <span class="star-g">★</span>
                      <span class="star-g">★</span>
                      <span class="star-g">★</span>
                      <span class="star-g">★</span>
                    </div>
                  </div>
                </div>
                <div class="badge-card">
                  <div
                    style="
                      display: flex;
                      align-items: center;
                      gap: 6px;
                      flex-shrink: 0;
                    "
                  >
                    <div
                      style="
                        width: 28px;
                        height: 28px;
                        background: #00b67a;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        border-radius: 4px;
                      "
                    >
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 18 18"
                        fill="none"
                      >
                        <polygon
                          points="9,1.5 11,7 17,7.5 12.5,11.5 14,17.5 9,14.5 4,17.5 5.5,11.5 1,7.5 7,7"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <span
                      style="font-size: 16px; font-weight: 500; color: #0f172a"
                      >Trustpilot</span
                    >
                  </div>

                  <div class="divider-v"></div>

                  <div>
                    <div class="sublabel">Excellent</div>
                    <div class="stars-row">
                      <span class="star-tp">★</span>
                      <span class="star-tp">★</span>
                      <span class="star-tp">★</span>
                      <span class="star-tp">★</span>
                      <span class="star-tp">★</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div
              class="st-hero-form-card mx-auto w-full max-w-md rounded-[32px] bg-white p-8 shadow-2xl shadow-slate-900/10 ring-1 ring-slate-200"
            >
              <div class="mb-6 text-center">
                <h3 class="text-3xl font-semibold text-slate-900">
                  Get a Free Quote
                </h3>
              </div>
              <form id="heroForm" class="space-y-5 st-lead-form" novalidate>
                <?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
                <input type="hidden" name="action" value="swift_lead_submission">
                <input type="hidden" name="recaptcha_token" value="">
                <input type="hidden" name="lead_funnel" value="swift-takeoffs-landing">
                <input type="hidden" name="utm_source" value="">
                <input type="hidden" name="utm_medium" value="">
                <input type="hidden" name="utm_campaign" value="">
                <input type="hidden" name="utm_content" value="">
                <input type="hidden" name="utm_term" value="">
                <input type="hidden" name="gclid" value="">
                <input type="hidden" name="landing_page" value="">
                <input type="hidden" name="fq_scope" id="hero_fq_scope" value="">
                <input type="hidden" name="fq_message" id="hero_fq_message" value="">
                <div class="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label for="nameInput" class="screen-reader-text">Your Name</label>
                    <input
                      type="text"
                      id="nameInput"
                      name="fq_name"
                      autocomplete="name"
                      placeholder="Your Name"
                      required
                      class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                    />
                  </div>
                  <div>
                    <label for="emailInput" class="screen-reader-text">Your Email</label>
                    <input
                      type="email"
                      id="emailInput"
                      name="fq_email"
                      autocomplete="email"
                      placeholder="Your Email"
                      required
                      class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                    />
                  </div>
                </div>
                <div class="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label for="companyInput" class="screen-reader-text">Company Name</label>
                    <input
                      type="text"
                      id="companyInput"
                      name="fq_company"
                      autocomplete="organization"
                      placeholder="Company Name"
                      class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                    />
                  </div>
                  <div>
                    <label for="phoneInput" class="screen-reader-text">Your Phone</label>
                    <input
                      type="tel"
                      id="phoneInput"
                      name="fq_phone"
                      autocomplete="tel"
                      placeholder="Your Phone"
                      class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                    />
                  </div>
                </div>
                <label for="tradesInput" class="screen-reader-text">Trades</label>
                <input
                  type="text"
                  id="tradesInput"
                  name="trades"
                  placeholder="Enter Trades (e.g., Electrical, Plumbing)"
                  required
                  class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                />
                <div class="st-custom-select" data-st-select>
                  <label for="levelSelect" class="screen-reader-text">Level Type</label>
                  <select
                    id="levelSelect"
                    name="level_type"
                    required
                    tabindex="-1"
                    aria-hidden="true"
                    class="st-native-select-sr"
                  >
                    <option value="" disabled selected>Select Level Type</option>
                    <option value="basic">Basic — SQ FT or LF materials</option>
                    <option value="detailed">Plus — Piece count &amp; assemblies breakdown</option>
                  </select>
                  <button
                    type="button"
                    class="st-custom-select-trigger"
                    id="levelSelectTrigger"
                    aria-haspopup="listbox"
                    aria-expanded="false"
                    aria-controls="levelSelectMenu"
                  >
                    <span class="st-custom-select-label">Select Level Type</span>
                    <span class="st-custom-select-chevron" aria-hidden="true">▾</span>
                  </button>
                  <ul
                    id="levelSelectMenu"
                    class="st-custom-select-menu"
                    role="listbox"
                    aria-labelledby="levelSelectTrigger"
                    hidden
                  >
                    <li role="option" tabindex="-1" data-value="basic" aria-selected="false">
                      <span class="st-option-title">Basic</span>
                      <span class="st-option-desc">SQ FT or LF materials description</span>
                    </li>
                    <li role="option" tabindex="-1" data-value="detailed" aria-selected="false">
                      <span class="st-option-title">Plus</span>
                      <span class="st-option-desc">Piece count, assemblies breakdown &amp; condensed materials</span>
                    </li>
                  </ul>
                </div>
                <?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'landing-hero' ) ); ?>
                <button
                  type="submit"
                  class="inline-flex w-full items-center justify-center gap-3 rounded-3xl bg-sky-600 px-6 py-4 text-base font-semibold text-white shadow-lg transition hover:bg-sky-700 active:scale-[0.98]"
                >
                  <span class="btn-text">Submit Request</span>
                  <span class="btn-spinner hidden h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"
                  ></span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <section class="bg-slate-50 py-20">
        <div class="mx-auto max-w-7xl px-5 text-center">
          <h2 class="text-3xl font-semibold text-slate-900">
            Trusted by Leading Construction Companies
          </h2>
          <div class="mt-12 space-y-8">
            <div class="overflow-hidden">
              <div class="flex items-center gap-12 scroll-ltr">
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-1.svg"
                  alt="Construction estimating services client"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-2.svg"
                  alt="Company 2"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-3.svg"
                  alt="Company 3"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-4.svg"
                  alt="Company 4"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-5.svg"
                  alt="Company 5"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-6.svg"
                  alt="Company 6"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-7.svg"
                  alt="Company 7"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-8.svg"
                  alt="Company 8"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-1.svg"
                  alt="Construction estimating services client"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-2.svg"
                  alt="Company 2"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-3.svg"
                  alt="Company 3"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-4.svg"
                  alt="Company 4"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-5.svg"
                  alt="Company 5"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-6.svg"
                  alt="Company 6"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-7.svg"
                  alt="Company 7"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-8.svg"
                  alt="Company 8"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
              </div>
            </div>
            <div class="overflow-hidden">
              <div class="flex items-center gap-12 scroll-rtl">
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-9.svg"
                  alt="Company 9"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-10.svg"
                  alt="Company 10"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-11.svg"
                  alt="Company 11"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-12.svg"
                  alt="Company 12"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-13.svg"
                  alt="Company 13"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-14.svg"
                  alt="Company 14"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-9.svg"
                  alt="Company 9"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-10.svg"
                  alt="Company 10"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-11.svg"
                  alt="Company 11"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-12.svg"
                  alt="Company 12"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-13.svg"
                  alt="Company 13"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
                <img
                  src="<?php echo esc_url( $landing_uri ); ?>/images/company-14.svg"
                  alt="Company 14"
                  class="h-12 w-auto object-contain" loading="lazy" width="120" height="48"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        class="bg-gradient-to-br from-sky-50 via-slate-50 to-white py-20"
      >
        <div class="mx-auto max-w-7xl px-5 text-center">
          <h2 class="text-3xl font-semibold text-slate-900">
            Our Takeoff Software Expertise
          </h2>
          <p class="mx-auto mt-3 max-w-2xl text-base text-slate-600 sm:text-lg">
            We're proficient in all major estimating software platforms
          </p>
          <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-6">
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-1.svg"
                alt="Construction estimating services software"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-4.svg"
                alt="Software 4"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-7.svg"
                alt="Software 7"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-12.svg"
                alt="Software 12"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-2.svg"
                alt="Software 2"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-3.svg"
                alt="Software 3"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-5.svg"
                alt="Software 5"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-6.svg"
                alt="Software 6"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-8.svg"
                alt="Software 8"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-9.svg"
                alt="Software 9"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-10.svg"
                alt="Software 10"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
            <div
              class="flex h-32 items-center justify-center rounded-3xl bg-white p-5 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <img
                src="<?php echo esc_url( $landing_uri ); ?>/images/software-11.svg"
                alt="Software 11"
                class="h-20 w-auto object-contain" loading="lazy" width="160" height="80"
              />
            </div>
          </div>
        </div>
      </section>

      <section class="bg-white py-20">
        <div class="mx-auto max-w-7xl px-5">
          <div class="grid gap-16 lg:grid-cols-[1fr_1.5fr] lg:items-start">
            <div>
              <p
                class="text-xs font-semibold uppercase tracking-[0.32em] text-slate-500 mb-4"
              >
                Coverage
              </p>
              <h2
                class="text-4xl font-semibold tracking-tight text-slate-900 sm:text-5xl"
              >
                Construction
                <span class="italic text-sky-700">divisions</span> we cover
              </h2>
              <div class="mt-6 h-px w-16 bg-slate-200"></div>
              <p class="mt-6 max-w-xl text-base text-slate-600">
                Comprehensive estimating across all CSI divisions with precision
                and expertise.
              </p>
            </div>
            <div class="grid gap-4 md:grid-cols-3">
              <div class="flex flex-col gap-4">
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 01
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    General Requirements
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 02
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Existing Conditions
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 03
                  </p>
                  <p class="text-base font-semibold text-slate-900">Concrete</p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 04
                  </p>
                  <p class="text-base font-semibold text-slate-900">Masonry</p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 05
                  </p>
                  <p class="text-base font-semibold text-slate-900">Metals</p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 06
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Wood & Composites
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 07
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Thermal & Moisture
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 08
                  </p>
                  <p class="text-base font-semibold text-slate-900">Openings</p>
                </div>
              </div>
              <div class="flex flex-col gap-4">
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 09
                  </p>
                  <p class="text-base font-semibold text-slate-900">Finishes</p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 10
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Specialties
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 11
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Equipment
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 12
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Furnishings
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 13
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Special Construction
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 14
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Conveying Equipment
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 20
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Mechanical Support
                  </p>
                </div>
              </div>
              <div class="flex flex-col gap-4">
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 21
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Fire Suppression
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 22
                  </p>
                  <p class="text-base font-semibold text-slate-900">Plumbing</p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 23
                  </p>
                  <p class="text-base font-semibold text-slate-900">HVAC</p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 26
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Electrical
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 31
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Earthwork
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 32
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Exterior Improvements
                  </p>
                </div>
                <div
                  class="rounded-[28px] border border-slate-200 bg-white px-5 py-2 text-sm font-semibold text-slate-900 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50"
                >
                  <p
                    class="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"
                  >
                    Div 33
                  </p>
                  <p class="text-base font-semibold text-slate-900">
                    Utilities
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        class="relative overflow-hidden bg-gradient-to-br from-sky-50 via-slate-50 to-white py-20"
      >
        <div
          class="absolute -right-24 top-0 h-72 w-72 rounded-full bg-sky-100 opacity-40 blur-3xl"
        ></div>
        <div
          class="absolute -left-24 bottom-0 h-64 w-64 rounded-full bg-sky-100 opacity-30 blur-3xl"
        ></div>
        <div class="relative mx-auto max-w-7xl px-5">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-semibold text-sky-700">
              Why choose our construction estimating services?
            </h2>
            <p
              class="mx-auto mt-4 max-w-2xl text-base text-slate-600 sm:text-lg"
            >
              Delivering exceptional value through our specialized estimating
              services
            </p>
          </div>
          <div class="grid gap-6 xl:grid-cols-3">
            <div
              class="group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div
                class="transition-transform duration-500 group-hover:-translate-y-10"
              >
                <div
                  class="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700"
                >
                  <i
                    class="fa-solid fa-money-bill-wave text-2xl"
                    aria-hidden="true"
                  ></i>
                </div>
                <h3 class="mb-3 text-xl font-semibold text-sky-700">
                  60% Cost Savings
                </h3>
                <p class="text-sm leading-6 text-slate-600">
                  Save significantly on salary costs while maintaining quality
                  with our expert takeoff specialists.
                </p>
              </div>
              <div
                class="absolute inset-x-0 bottom-0 translate-y-full rounded-b-[28px] bg-sky-700 px-8 py-6 text-white transition duration-500 group-hover:translate-y-0"
              >
                <p class="text-sm leading-6">
                  Construction companies save up to 60% on operational costs
                  while improving accuracy.
                </p>
              </div>
            </div>
            <div
              class="group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div
                class="transition-transform duration-500 group-hover:-translate-y-10"
              >
                <div
                  class="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700"
                >
                  <i
                    class="fa-solid fa-tachometer-alt text-2xl"
                    aria-hidden="true"
                  ></i>
                </div>
                <h3 class="mb-3 text-xl font-semibold text-sky-700">
                  Fast & Accurate
                </h3>
                <p class="text-sm leading-6 text-slate-600">
                  Precision takeoffs delivered quickly by our professional team
                  with unmatched thoroughness.
                </p>
              </div>
              <div
                class="absolute inset-x-0 bottom-0 translate-y-full rounded-b-[28px] bg-sky-700 px-8 py-6 text-white transition duration-500 group-hover:translate-y-0"
              >
                <p class="text-sm leading-6">
                  Clients consistently report our takeoffs are more accurate
                  than in-house teams.
                </p>
              </div>
            </div>
            <div
              class="group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div
                class="transition-transform duration-500 group-hover:-translate-y-10"
              >
                <div
                  class="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700"
                >
                  <i
                    class="fa-solid fa-stopwatch text-2xl"
                    aria-hidden="true"
                  ></i>
                </div>
                <h3 class="mb-3 text-xl font-semibold text-sky-700">
                  Quick Turnaround
                </h3>
                <p class="text-sm leading-6 text-slate-600">
                  Impress clients with speedy responses and be first to submit
                  bids with our rapid service.
                </p>
              </div>
              <div
                class="absolute inset-x-0 bottom-0 translate-y-full rounded-b-[28px] bg-sky-700 px-8 py-6 text-white transition duration-500 group-hover:translate-y-0"
              >
                <p class="text-sm leading-6">
                  Overnight turnaround available for urgent projects to give you
                  a competitive edge.
                </p>
              </div>
            </div>
            <div
              class="group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div
                class="transition-transform duration-500 group-hover:-translate-y-10"
              >
                <div
                  class="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700"
                >
                  <i class="fa-solid fa-city text-2xl" aria-hidden="true"></i>
                </div>
                <h3 class="mb-3 text-xl font-semibold text-sky-700">
                  Diverse Expertise
                </h3>
                <p class="text-sm leading-6 text-slate-600">
                  Experienced in all construction structures and areas for
                  comprehensive takeoff services.
                </p>
              </div>
              <div
                class="absolute inset-x-0 bottom-0 translate-y-full rounded-b-[28px] bg-sky-700 px-8 py-6 text-white transition duration-500 group-hover:translate-y-0"
              >
                <p class="text-sm leading-6">
                  From residential to commercial projects, we handle all
                  construction types with expertise.
                </p>
              </div>
            </div>
            <div
              class="group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div
                class="transition-transform duration-500 group-hover:-translate-y-10"
              >
                <div
                  class="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700"
                >
                  <i
                    class="fa-solid fa-handshake text-2xl"
                    aria-hidden="true"
                  ></i>
                </div>
                <h3 class="mb-3 text-xl font-semibold text-sky-700">
                  Flexible Terms
                </h3>
                <p class="text-sm leading-6 text-slate-600">
                  No long-term contracts - work with us on your terms with
                  complete flexibility.
                </p>
              </div>
              <div
                class="absolute inset-x-0 bottom-0 translate-y-full rounded-b-[28px] bg-sky-700 px-8 py-6 text-white transition duration-500 group-hover:translate-y-0"
              >
                <p class="text-sm leading-6">
                  Month-to-month engagements with no lock-in periods or hidden
                  commitments.
                </p>
              </div>
            </div>
            <div
              class="group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div
                class="transition-transform duration-500 group-hover:-translate-y-10"
              >
                <div
                  class="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700"
                >
                  <i
                    class="fa-solid fa-comments text-2xl"
                    aria-hidden="true"
                  ></i>
                </div>
                <h3 class="mb-3 text-xl font-semibold text-sky-700">
                  Clear Communication
                </h3>
                <p class="text-sm leading-6 text-slate-600">
                  Stay informed with regular updates on job progress and
                  delivery timelines.
                </p>
              </div>
              <div
                class="absolute inset-x-0 bottom-0 translate-y-full rounded-b-[28px] bg-sky-700 px-8 py-6 text-white transition duration-500 group-hover:translate-y-0"
              >
                <p class="text-sm leading-6">
                  Proactive communication ensures no surprises and complete
                  project transparency.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="bg-sky-900 py-24 text-white">
        <div class="mx-auto max-w-7xl px-5">
          <div class="grid gap-8 md:grid-cols-3 text-center">
            <div
              class="rounded-[32px] bg-white/10 p-10 shadow-2xl shadow-slate-950/30"
            >
              <div
                class="text-5xl font-extrabold text-transparent bg-gradient-to-r from-white to-slate-300 bg-clip-text"
              >
                10+
              </div>
              <p class="mt-4 text-lg font-medium text-slate-200">
                Software expertise
              </p>
            </div>
            <div
              class="rounded-[32px] bg-white/10 p-10 shadow-2xl shadow-slate-950/30"
            >
              <div
                class="text-5xl font-extrabold text-transparent bg-gradient-to-r from-white to-slate-300 bg-clip-text"
              >
                75+
              </div>
              <p class="mt-4 text-lg font-medium text-slate-200">
                Employees working
              </p>
            </div>
            <div
              class="rounded-[32px] bg-white/10 p-10 shadow-2xl shadow-slate-950/30"
            >
              <div
                class="text-5xl font-extrabold text-transparent bg-gradient-to-r from-white to-slate-300 bg-clip-text"
              >
                60+
              </div>
              <p class="mt-4 text-lg font-medium text-slate-200">
                Cost savings (%)
              </p>
            </div>
          </div>
        </div>
      </section>

      <section class="bg-slate-50 py-20">
        <div class="mx-auto max-w-7xl px-5 text-center">
          <h2 class="text-3xl font-semibold text-slate-900">
            Trusted by Construction Industry Leaders
          </h2>
          <p class="mx-auto mt-3 max-w-2xl text-base text-slate-600 sm:text-lg">
            Our accurate pre-construction estimating services help companies win
            more bids and maximize profitability.
          </p>
          <div class="mt-12 grid gap-6 lg:grid-cols-3">
            <div
              class="rounded-[28px] bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <p class="text-slate-700">
                “Working with this team has transformed the way we bid on
                projects. Their detailed estimates helped us secure contracts we
                never thought possible.”
              </p>
              <div class="mt-8 flex items-center justify-center gap-4">
                <div class="text-left">
                  <h4 class="font-semibold text-slate-900">John Miller</h4>
                  <span class="text-sm text-slate-500"
                    >CEO, Miller Construction</span
                  >
                </div>
              </div>
            </div>
            <div
              class="rounded-[28px] bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <p class="text-slate-700">
                “Their precision and fast turnaround gave us the confidence to
                submit aggressive bids. We’ve seen over 30% more bid wins since
                partnering with them.”
              </p>
              <div class="mt-8 flex items-center justify-center gap-4">
                <div class="text-left">
                  <h4 class="font-semibold text-slate-900">Sarah Thompson</h4>
                  <span class="text-sm text-slate-500"
                    >Director, Skyline Builders</span
                  >
                </div>
              </div>
            </div>
            <div
              class="rounded-[28px] bg-white p-8 shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <p class="text-slate-700">
                “Reliable, professional, and accurate. Their estimates save us
                time and money while keeping our clients happy.”
              </p>
              <div class="mt-8 flex items-center justify-center gap-4">
                <div class="text-left">
                  <h4 class="font-semibold text-slate-900">Michael Davis</h4>
                  <span class="text-sm text-slate-500"
                    >VP, Davis & Sons Contractors</span
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        class="bg-gradient-to-br from-sky-100 via-slate-100 to-white py-20"
        id="faq"
      >
        <div class="mx-auto max-w-7xl px-5">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-semibold text-sky-700">
              Frequently Asked Questions
            </h2>
            <p
              class="mx-auto mt-4 max-w-2xl text-base text-slate-600 sm:text-lg"
            >
              Everything you need to know about our construction plan quantity
              takeoff services
            </p>
          </div>
          <div class="grid gap-6 lg:grid-cols-2">
            <div class="space-y-4">
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >01</span
                    >How does the takeoff process work at your company?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  All you have to do is to send your blue prints or plans, our
                  team of takeoff experts would complete the takeoff within your
                  required time frame and send it back to you. You will receive
                  the takeoff items in an Excel along with the marked plans to
                  you. You can use it to submit your bid. It is simple and easy.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >02</span
                    >Can I get a team of takeoff specialists from you to work on
                    my project?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  Yes absolutely. Based on your requirement, we can recruit and
                  hire a team to work on your project. Your offshore takeoff
                  team will work solely on your takeoff projects and you will be
                  in absolute control of your team including what work your team
                  does and who they report to.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >03</span
                    >I am a small business. Will you do takeoff for my
                    company?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  Absolutely. We work with dozens of small businesses and
                  start-up companies across the USA, UK, Australia and Canada.
                  Our takeoff staffs are experts in working with small
                  businesses. We are happy to work with you too.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >04</span
                    >What file formats do you accept for takeoffs?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  We accept all common file formats including PDF, DWG, DXF, and
                  more. Our team is equipped to work with both digital and
                  scanned blueprints.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >05</span
                    >How accurate are your takeoff estimates?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  Our takeoffs have a 99% accuracy rate. We use advanced
                  software and double-check all measurements to ensure precision
                  in every project.
                </p>
              </details>
            </div>
            <div class="space-y-4">
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >06</span
                    >What is your typical turnaround time?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  Standard projects are completed within 2-3 business days. We
                  also offer expedited services for urgent projects with 24-hour
                  turnaround options.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >07</span
                    >Do you work with international clients?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  Yes, we serve clients worldwide with special expertise in US,
                  UK, Australian, and Canadian building standards and
                  regulations.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >08</span
                    >What industries do you specialize in?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  We specialize in residential, commercial, industrial, and
                  infrastructure projects with expertise across all construction
                  sectors.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >09</span
                    >How do you ensure data security?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  We use encrypted file transfer, secure servers, and strict
                  confidentiality agreements to protect all client data and
                  project information.
                </p>
              </details>
              <details
                class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
              >
                <summary
                  class="flex cursor-pointer items-center justify-between gap-4 text-slate-900 text-base font-semibold"
                >
                  <span class="flex items-center gap-3"
                    ><span
                      class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-100 text-sm font-semibold text-sky-700"
                      >10</span
                    >What makes your service different from competitors?</span
                  >
                  <i class="fas fa-chevron-down text-sky-600"></i>
                </summary>
                <p class="mt-4 text-slate-600 leading-7">
                  Our combination of cutting-edge technology, highly specialized
                  experts, and commitment to accuracy and customer service sets
                  us apart in the industry.
                </p>
              </details>
            </div>
          </div>
        </div>
      </section>

      <section class="bg-slate-50 py-20" id="contact">
        <div class="mx-auto max-w-7xl px-5">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-semibold text-slate-900">
              Ready to discuss your construction plan takeoff project?
            </h2>
          </div>
          <div class="grid gap-12 lg:grid-cols-2">
            <div class="space-y-8 rounded-[32px] bg-white p-10 shadow-xl">
              <h3 class="text-2xl font-semibold text-slate-900">
                Get In Touch
              </h3>
              <div class="space-y-6">
                <div class="flex items-start gap-4">
                  <div
                    class="flex h-14 w-14 items-center justify-center rounded-3xl bg-gradient-to-br from-sky-600 to-sky-700 text-white"
                  >
                    <i
                      class="fa-solid fa-envelope text-2xl"
                      aria-hidden="true"
                    ></i>
                  </div>
                  <div>
                    <h4 class="font-semibold text-slate-900">Email</h4>
                    <p class="text-slate-600">info@swifttakeoffs.com</p>
                  </div>
                </div>
                <div class="flex items-start gap-4">
                  <div
                    class="flex h-14 w-14 items-center justify-center rounded-3xl bg-gradient-to-br from-sky-600 to-sky-700 text-white"
                  >
                    <i
                      class="fa-solid fa-phone text-2xl"
                      aria-hidden="true"
                    ></i>
                  </div>
                  <div>
                    <h4 class="font-semibold text-slate-900">Phone</h4>
                    <p class="text-slate-600">US: +1 (678) 825-6967</p>
                  </div>
                </div>
                <div class="flex items-start gap-4">
                  <div
                    class="flex h-14 w-14 items-center justify-center rounded-3xl bg-gradient-to-br from-sky-600 to-sky-700 text-white"
                  >
                    <i
                      class="fa-solid fa-clock text-2xl"
                      aria-hidden="true"
                    ></i>
                  </div>
                  <div>
                    <h4 class="font-semibold text-slate-900">Office Hours</h4>
                    <p class="text-slate-600">Mon-Fri: 8am-6pm (EST)</p>
                    <p class="text-slate-600">Mon-Fri: 9am-5pm (CET)</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="rounded-[32px] bg-white p-10 shadow-xl">
              <form id="contactForm" class="space-y-5 st-lead-form" novalidate>
                <?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
                <input type="hidden" name="action" value="swift_lead_submission">
                <input type="hidden" name="recaptcha_token" value="">
                <input type="hidden" name="lead_funnel" value="swift-takeoffs-landing-contact">
                <input type="hidden" name="utm_source" value="">
                <input type="hidden" name="utm_medium" value="">
                <input type="hidden" name="utm_campaign" value="">
                <input type="hidden" name="utm_content" value="">
                <input type="hidden" name="utm_term" value="">
                <input type="hidden" name="gclid" value="">
                <input type="hidden" name="landing_page" value="">
                <input type="hidden" name="fq_message" value="Landing contact / request quote">
                <label for="contactNameInput" class="screen-reader-text">Your Name</label>
                <input
                  type="text"
                  id="contactNameInput"
                  name="fq_name"
                  autocomplete="name"
                  placeholder="Your Name"
                  required
                  class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                />
                <label for="contactEmailInput" class="screen-reader-text">Your Email</label>
                <input
                  type="email"
                  id="contactEmailInput"
                  name="fq_email"
                  autocomplete="email"
                  placeholder="Your Email"
                  required
                  class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                />
                <label for="contactPhoneInput" class="screen-reader-text">Your Phone</label>
                <input
                  type="tel"
                  id="contactPhoneInput"
                  name="fq_phone"
                  autocomplete="tel"
                  placeholder="Your Phone"
                  class="w-full rounded-3xl border border-slate-300 bg-slate-50 px-5 py-4 text-base text-slate-900 outline-none transition focus:border-sky-600 focus:ring-4 focus:ring-sky-100"
                />
                <?php get_template_part( 'template-parts/sms-consent', null, array( 'id' => 'landing-contact' ) ); ?>
                <button
                  type="submit"
                  class="inline-flex w-full items-center justify-center gap-3 rounded-3xl bg-sky-600 px-6 py-4 text-base font-semibold text-white shadow-lg transition hover:bg-sky-700 active:scale-[0.98]"
                >
                  <span class="btn-text">Request Quote</span>
                  <span class="btn-spinner hidden h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>

<!-- Thank-you modal -->
<div id="stLeadThanksModal" class="st-thanks-modal" hidden aria-hidden="true">
  <div class="st-thanks-backdrop" data-st-thanks-close></div>
  <div class="st-thanks-dialog" role="dialog" aria-modal="true" aria-labelledby="stThanksTitle">
    <button type="button" class="st-thanks-close" data-st-thanks-close aria-label="<?php esc_attr_e( 'Close', 'swift-takeoffs' ); ?>">&times;</button>
    <div class="st-thanks-icon" aria-hidden="true">
      <svg viewBox="0 0 52 52" width="64" height="64">
        <circle class="st-thanks-circle" cx="26" cy="26" r="24" fill="none"/>
        <path class="st-thanks-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
      </svg>
    </div>
    <h2 id="stThanksTitle"><?php esc_html_e( 'Request received', 'swift-takeoffs' ); ?></h2>
    <p><?php esc_html_e( 'Thanks — our estimating team will follow up shortly. Keep your plans handy so we can move fast.', 'swift-takeoffs' ); ?></p>
    <button type="button" class="st-thanks-btn" data-st-thanks-close><?php esc_html_e( 'Continue browsing', 'swift-takeoffs' ); ?></button>
  </div>
</div>
