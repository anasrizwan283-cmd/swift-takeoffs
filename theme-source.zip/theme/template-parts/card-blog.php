<?php
/**
 * Template Part: Blog Card
 * Used in front-page.php (latest posts) and archive.php (blog listing).
 *
 * @package SwiftTakeoffs
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-card' ); ?>>

	<div class="blog-img">
		<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'swift-blog-thumb', array( 'alt' => get_the_title() ) ); ?>
			<?php else : ?>
				<!-- Fallback placeholder image -->
				<img
					src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/blog-placeholder.svg' ); ?>"
					alt="<?php echo esc_attr( get_the_title() ); ?>"
					loading="lazy"
					width="600"
					height="400"
				>
			<?php endif; ?>
		</a>
	</div>

	<div class="blog-content">
		<span class="blog-date">
			<?php echo esc_html( get_the_date( 'd M Y' ) ); ?>
		</span>

		<h3>
			<a href="<?php the_permalink(); ?>">
				<?php the_title(); ?>
			</a>
		</h3>

		<p><?php echo wp_kses_post( get_the_excerpt() ); ?></p>

		<a href="<?php the_permalink(); ?>" class="learn-more">
			<?php esc_html_e( 'Learn More', 'swift-takeoffs' ); ?>
			<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
		</a>
	</div>

</article><!-- .blog-card -->
