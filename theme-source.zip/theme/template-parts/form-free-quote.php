<?php
/**
 * Standalone full-width “Get a Free Quote” form (no image column).
 *
 * WordPress template part — not React/Next.js. Pass overrides via
 * get_template_part( ..., null, $args ). Styles: `.st-free-quote` in style.css.
 *
 * @package SwiftTakeoffs
 *
 * @var array $args {
 *     @type string   $business_name      Consent / legal brand name.
 *     @type string   $privacy_policy_url Privacy Policy href.
 *     @type string[] $services           Service Needed dropdown options.
 *     @type string   $id                 Unique suffix when multiple forms exist.
 *     @type string   $funnel             lead_funnel value stored with the lead.
 * }
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Reusable config — override per page via $args, do not hardcode brand/URL in markup.
 * $services: leave empty to pull published Service CPT titles, then append “Other”.
 */
$config = wp_parse_args(
	is_array( $args ) ? $args : array(),
	array(
		'business_name'      => 'Swift Takeoffs',
		'privacy_policy_url' => function_exists( 'swift_takeoffs_privacy_policy_url' )
			? swift_takeoffs_privacy_policy_url()
			: home_url( '/privacy-policy/' ),
		'services'           => array(),
		'id'                 => 'home',
		'funnel'             => 'homepage-quote',
	)
);

$services = $config['services'];
if ( empty( $services ) && function_exists( 'swift_takeoffs_get_all_services' ) ) {
	foreach ( swift_takeoffs_get_all_services( -1 ) as $svc ) {
		$title = get_the_title( $svc );
		if ( $title ) {
			$services[] = $title;
		}
	}
}
if ( empty( $services ) ) {
	$services = array( 'Estimating', 'Consulting', 'Other' );
}
if ( ! in_array( 'Other', $services, true ) ) {
	$services[] = 'Other';
}

$suffix      = sanitize_html_class( $config['id'] );
$form_id     = 'st-free-quote-form-' . $suffix;
$consent_id  = 'st_fq_sms_' . $suffix;
$business    = $config['business_name'];
$privacy_url = $config['privacy_policy_url'];

if ( function_exists( 'swift_takeoffs_enqueue_free_quote_form' ) ) {
	swift_takeoffs_enqueue_free_quote_form();
}
?>
<section class="st-free-quote" aria-labelledby="<?php echo esc_attr( $form_id ); ?>-heading">
	<div class="st-free-quote__inner">
		<header class="st-free-quote__header">
			<h2 id="<?php echo esc_attr( $form_id ); ?>-heading" class="st-free-quote__title">
				<?php esc_html_e( 'Get A', 'swift-takeoffs' ); ?>
				<span><?php esc_html_e( 'Free Quote', 'swift-takeoffs' ); ?></span>
				<?php esc_html_e( 'Now', 'swift-takeoffs' ); ?>
			</h2>
			<p class="st-free-quote__sub">
				<?php esc_html_e( 'Ready to take your projects to the next level? Request a free quote today and let our expert estimators deliver reliability you can trust!', 'swift-takeoffs' ); ?>
			</p>
		</header>

		<div class="st-free-quote__banner st-free-quote__banner--success" data-fq-banner="success" hidden role="status">
			<?php esc_html_e( "Thanks! We'll be in touch shortly.", 'swift-takeoffs' ); ?>
		</div>
		<div class="st-free-quote__banner st-free-quote__banner--error" data-fq-banner="error" hidden role="alert">
			<?php esc_html_e( 'Something went wrong. Please try again.', 'swift-takeoffs' ); ?>
		</div>

		<form
			id="<?php echo esc_attr( $form_id ); ?>"
			class="st-free-quote-form st-lead-form"
			method="post"
			action="<?php echo esc_url( rest_url( 'swift/v1/quote-request' ) ); ?>"
			novalidate
			data-fq-form
		>
			<?php wp_nonce_field( 'swifttakeoffs_form', 'form_nonce' ); ?>
			<input type="hidden" name="lead_funnel" value="<?php echo esc_attr( $config['funnel'] ); ?>">
			<input type="hidden" name="utm_source" value="">
			<input type="hidden" name="utm_medium" value="">
			<input type="hidden" name="utm_campaign" value="">
			<input type="hidden" name="utm_content" value="">
			<input type="hidden" name="utm_term" value="">
			<input type="hidden" name="gclid" value="">
			<input type="hidden" name="landing_page" value="">
			<input type="hidden" name="recaptcha_token" value="">

			<?php // Honeypot: off-screen, not display:none — bots that skip CSS still fill it. ?>
			<div class="st-free-quote__hp" aria-hidden="true">
				<label for="<?php echo esc_attr( $form_id ); ?>-website"><?php esc_html_e( 'Website', 'swift-takeoffs' ); ?></label>
				<input
					type="text"
					id="<?php echo esc_attr( $form_id ); ?>-website"
					name="website"
					tabindex="-1"
					autocomplete="off"
					aria-hidden="true"
				>
			</div>

			<div class="st-free-quote__grid">
				<div class="st-free-quote__field" data-fq-field="name">
					<label for="<?php echo esc_attr( $form_id ); ?>-name">
						<?php esc_html_e( 'Name', 'swift-takeoffs' ); ?>
						<span class="st-free-quote__req" aria-hidden="true">*</span>
					</label>
					<input
						type="text"
						id="<?php echo esc_attr( $form_id ); ?>-name"
						name="name"
						placeholder="<?php esc_attr_e( 'Kane Williamson', 'swift-takeoffs' ); ?>"
						autocomplete="name"
						required
					>
					<p class="st-free-quote__error" data-fq-error="name" hidden></p>
				</div>

				<div class="st-free-quote__field" data-fq-field="phone">
					<label for="<?php echo esc_attr( $form_id ); ?>-phone">
						<?php esc_html_e( 'Phone', 'swift-takeoffs' ); ?>
						<span class="st-free-quote__req" aria-hidden="true">*</span>
					</label>
					<input
						type="tel"
						id="<?php echo esc_attr( $form_id ); ?>-phone"
						name="phone"
						placeholder="<?php esc_attr_e( 'Phone Number', 'swift-takeoffs' ); ?>"
						autocomplete="tel"
						required
					>
					<p class="st-free-quote__error" data-fq-error="phone" hidden></p>
				</div>

				<div class="st-free-quote__field" data-fq-field="email">
					<label for="<?php echo esc_attr( $form_id ); ?>-email">
						<?php esc_html_e( 'Email', 'swift-takeoffs' ); ?>
						<span class="st-free-quote__req" aria-hidden="true">*</span>
					</label>
					<input
						type="email"
						id="<?php echo esc_attr( $form_id ); ?>-email"
						name="email"
						placeholder="<?php esc_attr_e( 'your@email.com', 'swift-takeoffs' ); ?>"
						autocomplete="email"
						required
					>
					<p class="st-free-quote__error" data-fq-error="email" hidden></p>
				</div>

				<div class="st-free-quote__field" data-fq-field="service">
					<label id="<?php echo esc_attr( $form_id ); ?>-service-label" for="<?php echo esc_attr( $form_id ); ?>-service-trigger">
						<?php esc_html_e( 'Service Needed', 'swift-takeoffs' ); ?>
						<span class="st-free-quote__req" aria-hidden="true">*</span>
					</label>
					<div class="st-custom-select st-free-quote__select" data-st-select data-placeholder="<?php echo esc_attr__( 'Select a service', 'swift-takeoffs' ); ?>">
						<select
							id="<?php echo esc_attr( $form_id ); ?>-service"
							name="service"
							required
							tabindex="-1"
							aria-hidden="true"
							class="st-native-select-sr"
						>
							<option value="" disabled selected><?php esc_html_e( 'Select a service', 'swift-takeoffs' ); ?></option>
							<?php foreach ( $services as $service ) : ?>
								<option value="<?php echo esc_attr( $service ); ?>"><?php echo esc_html( $service ); ?></option>
							<?php endforeach; ?>
						</select>
						<button
							type="button"
							class="st-custom-select-trigger"
							id="<?php echo esc_attr( $form_id ); ?>-service-trigger"
							aria-haspopup="listbox"
							aria-expanded="false"
							aria-labelledby="<?php echo esc_attr( $form_id ); ?>-service-label <?php echo esc_attr( $form_id ); ?>-service-trigger"
							aria-controls="<?php echo esc_attr( $form_id ); ?>-service-menu"
						>
							<span class="st-custom-select-label"><?php esc_html_e( 'Select a service', 'swift-takeoffs' ); ?></span>
							<span class="st-custom-select-chevron" aria-hidden="true">
								<svg width="16" height="16" viewBox="0 0 24 24" fill="none">
									<path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
							</span>
						</button>
						<ul
							id="<?php echo esc_attr( $form_id ); ?>-service-menu"
							class="st-custom-select-menu"
							role="listbox"
							hidden
						>
							<?php foreach ( $services as $service ) : ?>
								<li role="option" tabindex="-1" data-value="<?php echo esc_attr( $service ); ?>" aria-selected="false">
									<?php echo esc_html( $service ); ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					<p class="st-free-quote__error" data-fq-error="service" hidden></p>
				</div>
			</div>

			<div class="st-free-quote__field st-free-quote__field--full" data-fq-field="message">
				<label for="<?php echo esc_attr( $form_id ); ?>-message"><?php esc_html_e( 'Message', 'swift-takeoffs' ); ?></label>
				<textarea
					id="<?php echo esc_attr( $form_id ); ?>-message"
					name="message"
					rows="5"
					placeholder="<?php esc_attr_e( 'Tell us about your project (optional)', 'swift-takeoffs' ); ?>"
				></textarea>
			</div>

			<div class="st-free-quote__consent" data-fq-field="sms_consent">
				<label class="st-free-quote__consent-check" for="<?php echo esc_attr( $consent_id ); ?>">
					<input type="checkbox" id="<?php echo esc_attr( $consent_id ); ?>" name="sms_consent" value="1" required>
					<span>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: business name */
								__( 'I agree to receive SMS text messages from %s. Message and data rates may apply.', 'swift-takeoffs' ),
								$business
							)
						);
						?>
					</span>
				</label>
				<p class="st-free-quote__consent-legal">
					<?php
					echo wp_kses(
						sprintf(
							/* translators: 1: business name, 2: privacy policy URL */
							__( 'By providing a telephone number and submitting this form you are consenting to be contacted by SMS text message and receive quote updates, reminders, and notifications from %1$s. Message &amp; data rates may vary. Message frequency may vary. Reply Help for more information. Reply STOP to opt-out of further messaging. <a href="%2$s">Privacy Policy</a>', 'swift-takeoffs' ),
							esc_html( $business ),
							esc_url( $privacy_url )
						),
						array(
							'a' => array(
								'href'   => true,
								'target' => true,
								'rel'    => true,
							),
						)
					);
					?>
				</p>
				<p class="st-free-quote__error" data-fq-error="sms_consent" hidden></p>
			</div>

			<button type="submit" class="st-free-quote__submit" data-fq-submit>
				<span class="st-free-quote__submit-label">
					<?php esc_html_e( 'Send Now', 'swift-takeoffs' ); ?>
					<svg class="st-free-quote__arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
						<path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</span>
				<span class="st-free-quote__spinner" hidden aria-hidden="true"></span>
			</button>
		</form>
	</div>
</section>
