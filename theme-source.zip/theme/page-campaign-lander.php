<?php
/**
 * Template Name: Campaign Lander
 * Description: Reusable campaign landing page. Edit copy in Campaign Lander fields (SCF). Layout stays the same.
 *
 * @package SwiftTakeoffs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/landing/campaign', 'content' );
get_footer();
